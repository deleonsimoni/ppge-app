export interface Snackbar {
  message: string;
  type: 'error' | 'info' | 'success';
}
