export interface AporteSaqueRecurso {
  numControleStr: string;
  tipoOperacao: string;
  dataOperacaoBacen: string;
  horaOperacaoBacen: string;
  tipoMensagem: number;
  valorOperacao: number;
}

export interface ControleSaldo extends ValorSaldo {
  subcontas: ValorSaldo[];
}

export interface ConsultaSaldo {
  saldoAporte: ControleSaldo;
	saldoTransferencia: ControleSaldo;
  data: Date;
  saldoInicial: number;
  saldoRealizado: number;
  saldoAtual: number;
  saldoBloqueado: number;
}

export interface TipoMensagem {
  id: number;
  descricao: string;
}

export interface ValorSaldo {
  descricao: string;
  sigla: string;
  valorEntrada: number;
  valorSaida: number;
  valorAtual: number;
  valorBloqueado: number;
}

export interface ConsultaLancamento{
	tipoMensagem: string;
  tipoLancamento: string;
  numControleStr: string;
	dataLancamento: Date;
  valorLancamento: number;
  codigoInstrucaoOriginal: string;
}

export interface DetalheAporteSaque {
  numControleStr: string;
  dataOperacaoBacen: Date;
  valorOperacao: number;
  tipoOperacao: string;
  tipoMensagem: string;
}
