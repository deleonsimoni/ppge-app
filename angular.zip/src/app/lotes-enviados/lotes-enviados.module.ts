import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LotesEnviadosComponent } from './lotes-enviados.component';
import { LotesEnviadosRoutingModule } from './lotes-enviados-routing.module';

import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgxCurrencyModule } from 'ngx-currency';
import { NgxMaskModule } from 'ngx-mask';
import { MatButtonModule } from '@angular/material/button';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';
import { StatusDs200Pipe } from './status-ds200.pipe';
import { SolicitarDs200DialogComponent } from './solicitar-ds200-dialog/solicitar-ds200-dialog.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ConfirmationDialogModule } from '@app/shared/components/confirmation-dialog/confirmation-dialog.module';
import { DetalheDs200DialogComponent } from './detalhe-ds200-dialog/detalhe-ds200-dialog.component';

@NgModule({
    declarations: [LotesEnviadosComponent, StatusDs200Pipe, DetalheDs200DialogComponent, SolicitarDs200DialogComponent],
    imports: [
      CommonModule,
      LotesEnviadosRoutingModule,
      ReactiveFormsModule,
      MatCardModule,
      MatDatepickerModule,
      MatDialogModule,
      MatGridListModule,
      MatInputModule,
      MatListModule,
      MatRadioModule,
      MatSelectModule,
      MatSnackBarModule,
      MatTooltipModule,
      NgxCurrencyModule,
      NgxMaskModule.forRoot(),
      MatButtonModule,
      MatPaginatorModule,
      MatTableModule,
      MatSlideToggleModule,
      ConfirmationDialogModule,
    ]
    })
    export class LotesEnviadosModule { }