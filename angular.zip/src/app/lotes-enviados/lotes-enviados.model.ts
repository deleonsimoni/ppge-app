export interface ConsultaLotesEnviados {
    dados: LotesEnviados[];
    pagina: number;
    paginas: number;
    tamanhoPagina: number;
    totalRegistros: number;
    valorTotalGeral: number;
  }

  export interface LotesEnviados {
    id: number;
    dataGeracao: string;
    nomeArquivo: string;
    descricaoDetalhado: string;
    situacaoProcessamento: number;
    totalRegistro: number;
    totalValorRegistro: number;
  }

export interface DetalheDS200 {
  tipoMensagem: string;
  evento: number;
  situacaoLancamento: string;
  dataEfetiva: Date;
  qtdLancamento: number;
  valor: number;
}
