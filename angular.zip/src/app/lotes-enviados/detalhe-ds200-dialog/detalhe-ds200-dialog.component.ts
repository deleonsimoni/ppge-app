import { Component, OnInit, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-detalhe-ds200-dialog',
  templateUrl: './detalhe-ds200-dialog.component.html',
  styleUrls: ['./detalhe-ds200-dialog.component.scss']
})
export class DetalheDs200DialogComponent {

  readonly displayedColumns: string[] = [
    'tipoMensagem',
    'evento',
    'dataEfetiva',
    'qtdLancamento',
    'valor',
  ];

  constructor(
    @Inject(MAT_DIALOG_DATA) public data,
  ) { }


}
