import { DatePipe } from '@angular/common';
import { Component, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';
import { LotesEnviadosService } from './lotes-enviados.service';
import { take } from 'rxjs/operators';
import { SnackbarService } from '@core/services';
import { PageEvent } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { SolicitarDs200DialogComponent } from './solicitar-ds200-dialog/solicitar-ds200-dialog.component';
import { DetalheDs200DialogComponent } from './detalhe-ds200-dialog/detalhe-ds200-dialog.component';

@Component({
    selector: 'app-lotes-enviados',
    templateUrl: './lotes-enviados.component.html',
    styleUrls: ['./lotes-enviados.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
  })
  export class LotesEnviadosComponent {

    readonly date = new Date(new Date().setDate(new Date().getDate()));
    readonly data$ = new BehaviorSubject<any>(null);

    readonly form = this.fb.group({
        dataInicial: [
          moment([
            this.date.getFullYear(),
            this.date.getMonth(),
            this.date.getDate(),
          ]),
          Validators.required,
        ],
        dataFinal: [
          moment([
            this.date.getFullYear(),
            this.date.getMonth(),
            this.date.getDate(),
          ]),
          Validators.required,
        ],
        status: ['0']
      });

    header = ['id', 'nomeArquivo', 'dataGeracao', 'totalRegistro', 'totalValorRegistro', 'situacaoProcessamento'];
    footer = ['total'];
    constructor(
        private fb: FormBuilder,
        public datepipe: DatePipe,
        private snackbarService: SnackbarService,
        private lotesEnviadosService: LotesEnviadosService,
        public dialog: MatDialog,
    ) {}

    getData(date: Date) {
        return this.datepipe.transform(date, 'dd/MM/yyyy');
      }

    onSubmit(): void {
        this.lotesEnviadosService
        .getLotesEnviados(
          this.getData(this.form.value.dataInicial),
          this.getData(this.form.value.dataFinal),
          this.form.value.status
        )
        .pipe(take(1))
        .subscribe((consulta) => {
          if (consulta.dados.length == 0) {
            this.snackbarService.open(
              'Nenhum Registro Encontrado.',
              'error',
            );
          }
          this.data$.next(consulta);
        });
      }

      onPagination(event: PageEvent): void {
        this.lotesEnviadosService
          .getLotesEnviados(
            this.getData(this.form.value.dataInicial),
            this.getData(this.form.value.dataFinal),
            this.form.value.status,
            event.pageIndex + 1,
            event.pageSize,
          )
          .pipe(take(1))
          .subscribe((dados) => {
            this.data$.next(dados);
          });
      }


    openDialogSolicitarGeracaoDs200() {
      this.dialog.open(SolicitarDs200DialogComponent);
      
    }
    getDetalheDS200(id, nomeArquivo): void {
      this.lotesEnviadosService
        .getDetalheDS200By(id)
        .pipe(take(1))
        .subscribe((data) => {
          if(data.length == 0) {
            this.snackbarService.open(
              'Nenhum Registro Encontrado.',
              'error',
            );
          } else {
            this.dialog.open(DetalheDs200DialogComponent, {
              data: {listDetalheDs200: data, nomeArquivo},
              maxHeight: '800px',
              width: '1000px',
            });
          }
        });
    }
  }