import { Pipe, PipeTransform } from '@angular/core';
/**
 * EM_PROCESSAMENTO(1L,"Em processamento")
 * CONCLUIDO(2L,"Concluído")
 * ENVIADO(3L,"Enviado")
 * ERRO(4L,"Erro no processamento do arquivo")
 **/

 @Pipe({name: 'statusDs200'})
 export class StatusDs200Pipe implements PipeTransform {
   transform(value: number): string {
     switch (value) {
      case 1:
        return 'Em processamento';
      case 2:
        return 'Concluído';
      case 3:
        return 'Enviado';
      case 4:
        return 'Erro no processamento do arquivo';
      default:
        return '-';
     }
   }
 }