import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { Observable } from 'rxjs';
import { ConsultaLotesEnviados, DetalheDS200 } from './lotes-enviados.model';

@Injectable({
    providedIn: 'root',
  })
  export class LotesEnviadosService {
    private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
    private readonly URL_LOTES_ENVIADOS = `${this.URL_PIX_GESTAO}/contabil/lotes-enviados`;
    private readonly URL_DETALHE_LOTES_ENVIADOS = `${this.URL_LOTES_ENVIADOS}/detalhe`;

    constructor(private http: HttpClient) {}

    public getLotesEnviados(
        dataInicio: string,
        dataFim: string,
        status: string,
        page: number = 1,
        tamanhoPagina: number = 15,
      ): Observable<ConsultaLotesEnviados> {
         return this.http.get<ConsultaLotesEnviados>(
           this.URL_LOTES_ENVIADOS,
           {
             params: {
               dataInicio,
               dataFim,
               status,
               pagina: page.toString(),
               tamanhoPagina: tamanhoPagina.toString(),
             },
           },
         );
      }

    public getDetalheDS200By(id): Observable<DetalheDS200[]> {
      return this.http.get<DetalheDS200[]>(`${this.URL_DETALHE_LOTES_ENVIADOS}/${id}`)
    }
  }