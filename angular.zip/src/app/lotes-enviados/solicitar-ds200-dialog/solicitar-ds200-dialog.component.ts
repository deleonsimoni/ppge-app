import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { SolicitarDs200DialogService } from './solicitar-ds200-dialog.service';
import * as moment from 'moment';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { DatePipe } from '@angular/common';
import DataUtils from '@app/shared/data-utils';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ConfirmationDialogComponent } from '@app/shared/components/confirmation-dialog/confirmation-dialog.component';
import { SnackbarService } from '@core/services';

@Component({
  selector: 'app-solicitar-ds200-dialog',
  templateUrl: './solicitar-ds200-dialog.component.html',
  styleUrls: ['./solicitar-ds200-dialog.component.scss']
})
export class SolicitarDs200DialogComponent implements OnInit {
  private readonly PRE_NOME_ARQUIVO = 'NAF.MZ.BBD2.IMPID200.D';
  private readonly PRE_ARQ_REP = '.REP';

  isCompleteArq = false;
  isRepFile = false;
  dateFormattedToDs200 = '26122023';
  sequencialRep = '';

  checked = false;
  readonly date = new Date(new Date().setDate(new Date().getDate() - 1));

  readonly formSettings = this.fb.group({
    nomeArquivo: [''],
    seqRep: [''],
    dataGeracao: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
  })

  constructor(
    private fb: FormBuilder,
    private solicitarDs200DialogService: SolicitarDs200DialogService,
    private datePipe: DatePipe,
    public dialog: MatDialog,
    private snackbarService: SnackbarService,
    private dialogRef: MatDialogRef<SolicitarDs200DialogComponent>
  ) { }


  ngOnInit(): void {
    this.dateFormattedToDs200 = this.formSettings.get('dataGeracao').value.format('DDMMYYYY');
    this.comporNomeArquivo();

    this.formSettings.get('dataGeracao').valueChanges.subscribe(dataAlterada => {
      if(dataAlterada) {
        this.dateFormattedToDs200 = dataAlterada.format('DDMMYYYY');
        this.comporNomeArquivo();
      }
    });

    this.formSettings.get('seqRep').valueChanges.subscribe(numberSeqRep => {
      this.sequencialRep = numberSeqRep;
      this.comporNomeArquivo();
    })
  }

  changeIsRepFile(event: MatSlideToggleChange) {
    this.isRepFile = event.checked;
    this.comporNomeArquivo();
  }

  changeIsCompleteArq(event: MatSlideToggleChange) {
    this.isCompleteArq = event.checked;
  }

  comporNomeArquivo() {
    const nome = this.PRE_NOME_ARQUIVO + this.dateFormattedToDs200 + (this.isRepFile ? this.PRE_ARQ_REP : '') + (this.sequencialRep != null && this.isRepFile ? this.sequencialRep : '');
    this.formSettings.get("nomeArquivo").setValue(nome);
  }

  onSubmit() {
    const dataGeracaoFormatada = this.formSettings.get('dataGeracao').value.format('DD/MM/YYYY');
    

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      width: '600px',
      data: {
        title: "Atenção!",
        text: `Tem certeza que deseja gerar um DS200 ${this.isCompleteArq ? "com Complemento " : ""}para o dia ${dataGeracaoFormatada}?`
      }
    })

    dialogRef.afterClosed().subscribe(flagAccept => {
      if (flagAccept) {
        if(this.isCompleteArq) {

          const dataG = this.somarSubtrairDias(dataGeracaoFormatada, 1);
          
          this.solicitarDs200DialogService
            .gerarDs200(dataG)
            .subscribe(() => {
              this.snackbarService.open('Geração do DS200 com Complemento iniciado com sucesso', 'success');
              this.dialogRef.close();
            });
        } else {
          const nomeArquivoMontado = this.formSettings.get('nomeArquivo').value;
          const dataParticaoIgnorada = this.somarSubtrairDias(dataGeracaoFormatada, -4);
          
          this.solicitarDs200DialogService
            .gerarDs200Parametrizado(dataGeracaoFormatada, nomeArquivoMontado, dataParticaoIgnorada)
            .subscribe(() => {
              this.snackbarService.open('Geração do DS200 iniciado com sucesso', 'success');
              this.dialogRef.close();
            });
        }
      }
    })

    

    
  }

  somarSubtrairDias(dataStr: string, qtdDias: number) {
    const dateParts = dataStr.split("/");
    let dataObjeto = new Date(+dateParts[2], parseInt(dateParts[1]) - 1, +dateParts[0]);

    dataObjeto.setDate(dataObjeto.getDate() + qtdDias);

    

    let dataSubtraida = this.datePipe.transform(dataObjeto, DataUtils.DATE_FORMAT);
    return dataSubtraida;
  }


}
