import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '@env/environment';
import { catchError, take } from 'rxjs/operators';
import { getServerErrorMessage } from '@app/shared/functions-utils';
import { SnackbarService } from '@core/services';

@Injectable({
  providedIn: 'root',
})
export class SolicitarDs200DialogService {

  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_GERAR_DS200 = `${this.URL_PIX_GESTAO}/contabil/gerar-ds200`;
  private readonly URL_GERAR_DS200_PARAMETRIZADO = `${this.URL_PIX_GESTAO}/contabil/gerar-ds200-parametrizado`;
  private readonly EXTENSAO_ARQUIVO = ".txt";

  constructor(
    private http: HttpClient, 
    private snackbarService: SnackbarService
  ) {}

  public gerarDs200Parametrizado(dataGeracao, nomeArquivo, dataParticaoIgnorada) {

    let params = new HttpParams()
      .set("datas", dataGeracao)
      .set("dataGeracao", dataGeracao)
      .set("dataParticaoIgnorada", dataParticaoIgnorada);

    if(nomeArquivo != null && nomeArquivo != "") {
      params = params.set("nomeArquivo", nomeArquivo+this.EXTENSAO_ARQUIVO);
    }

    return this.http.get(this.URL_GERAR_DS200_PARAMETRIZADO, {params})
    .pipe(
      take(1),
      catchError((error) => {
        let errorMsg: string;
        errorMsg = getServerErrorMessage(error);
        this.snackbarService.open(errorMsg,'error');
        throw errorMsg;
      })
    );
  }
  public gerarDs200(dataGeracao) {

    let params = new HttpParams()
      .set("data", dataGeracao)
      .set("isPendente", "true")
      .set("isGenerateName", "true");

    return this.http.get(this.URL_GERAR_DS200, {params})
    .pipe(
      take(1),
      catchError((error) => {
        let errorMsg: string;
        errorMsg = getServerErrorMessage(error);
        this.snackbarService.open(errorMsg,'error');
        throw errorMsg;
      })
    );
  }
}