import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { Observable } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { LogUsuario, Modulo } from './log-usuario.model';

@Injectable({
  providedIn: 'root',
})
export class LogUsuarioService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;

  private readonly URL_MENSAGERIA = `${this.URL_PIX_GESTAO}/log-usuario`;
  private readonly URL_MODULOS = `${this.URL_MENSAGERIA}/modulos`;
  private readonly URL_FUNCIONALIDADES_MENSAGERIA = `${this.URL_MENSAGERIA}/funcionalidades`;
  private readonly URL_MENSAGERIA_CONSULTA = `${this.URL_MENSAGERIA}/log-usuario`;

  constructor(private http: HttpClient, public datepipe: DatePipe) {}

  getModulos(): Observable<Modulo> {
    return this.http.get<Modulo>(
      `${this.URL_MODULOS}`,
    );
  }

  getFuncionalidades(modulo: string): Observable<Modulo> {
    return this.http.get<Modulo>(
      `${this.URL_FUNCIONALIDADES_MENSAGERIA}?modulo=${modulo}`,
    );
  }



  public getLogUsuario(
    dataInicio: string,
    dataFim: string,
    matricula: string,
    modulo: string,
    funcionalidade: string,
    page: number = 1,
    tamanhoPagina: number = 15,
  ): Observable<LogUsuario> {
    let params = new HttpParams();

    if (matricula) {
      params = params.set('matricula', matricula);
    }
    if (dataInicio) {
      params = params.set('dataInicio', dataInicio);
    }
    if (dataFim) {
      params = params.set('dataFim', dataFim);
    }
    if (funcionalidade) {
      params = params.set('funcionalidade', funcionalidade.toString());
    }
    if (modulo) {
      params = params.set('modulo', modulo.toString());
    }

    params = params
    .set('pagina', page.toString())
    .set('tamanhoPagina', tamanhoPagina.toString());

    return this.http.get<LogUsuario>(this.URL_MENSAGERIA_CONSULTA, { params });
  }
}
