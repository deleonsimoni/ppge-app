import { Component, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { PageEvent } from '@angular/material/paginator';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';
import { take, tap } from 'rxjs/operators';
import { LogUsuarioService } from './log-usuario.service';
import { Modulo } from './log-usuario.model';

@Component({
  selector: 'app-log-usuario',
  templateUrl: './log-usuario.component.html',
  styleUrls: ['./log-usuario.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LogUsuarioComponent {
  readonly date = new Date(new Date().setDate(new Date().getDate()));
  readonly data$ = new BehaviorSubject<any>(null);

  readonly funcionalidade$ = new BehaviorSubject<any>(null);

  readonly modulos$ = new BehaviorSubject<Modulo>(null);

  readonly form = this.fb.group({
    matricula: [''],
    dataInicio: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
    ],
    dataFim: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
    ],
    horaInicio: ['00:00:00'],
    horaFim: ['23:59:59'],
    modulo: [1],
    funcionalidade: [''],
  });

  readonly obsModulo$ = this.form.get('modulo').valueChanges.pipe(
    tap(() => {
      this.logUsuarioService
        .getFuncionalidades(this.form.get('modulo').value)
        .pipe(take(1))
        .subscribe((dados) => {
          this.funcionalidade$.next(dados);
        });
      this.form.get('funcionalidade').setValue('');
    }),
  );

  header = ['matricula', 'data', 'hora', 'acao'];
  paginaAtual = 1;
  tamanhoPagina: number;

  constructor(
    private fb: FormBuilder,
    private logUsuarioService: LogUsuarioService,
  ) {
    this.logUsuarioService
      .getModulos()
      .pipe(take(1))
      .subscribe((dados) => {
        this.modulos$.next(dados);
      });
    this.logUsuarioService
      .getFuncionalidades(this.form.get('modulo').value)
      .subscribe((dados) => {
        this.funcionalidade$.next(dados);
      });
  }

  onSubmit() {
    if (!this.form.invalid) {
      console.log(this.form);

      this.paginaAtual = 1;
      this.logUsuarioService
        .getLogUsuario(
          this.de(),
          this.ate(),
          `${this.form.value.matricula}`,
          `${this.form.value.modulo}`,
          `${this.form.value.funcionalidade}`,
          this.paginaAtual,
          15,
        )
        .pipe(take(1))
        .subscribe((logUsuario) => this.data$.next(logUsuario));
    }
  }

  get horaInicio() {
    return this.form.get('horaInicio');
  }

  get horaFim() {
    return this.form.get('horaFim');
  }

  onPagination(event: PageEvent): void {
    this.logUsuarioService
      .getLogUsuario(
        this.de(),
        this.ate(),
        `${this.form.value.matricula}`,
        `${this.form.value.modulo}`,
        `${this.form.value.funcionalidade}`,
        event.pageIndex + 1,
        event.pageSize,
      )
      .pipe(take(1))
      .subscribe((logUsuario) => this.data$.next(logUsuario));
  }

  private de(): string {
    if (this.form.get('dataInicio').value && this.horaInicio.value) {
      const date: moment.Moment = this.form.get('dataInicio').value;
      const horario = this.horaInicio.value.split(':');
      return new Date(
        date.year(),
        date.month(),
        date.date(),
        horario[0],
        horario[1],
        horario[2],
      ).toString();
    } else {
      return '';
    }
  }

  private ate(): string {
    if (this.form.get('dataFim').value && this.horaFim.value) {
      const date: moment.Moment = this.form.get('dataFim').value;
      const horario = this.horaFim.value.split(':');
      return new Date(
        date.year(),
        date.month(),
        date.date(),
        horario[0],
        horario[1],
        horario[2],
      ).toString();
    } else {
      return '';
    }
  }
}
