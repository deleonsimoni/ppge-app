export interface Modulo {
  id: number;
  nome: string;
  indice: string;
}


export interface LogUsuario {
  coUsuario: string;
  deAcaoUsuario: string;
  tsLogAcaoUsuario: string;
}