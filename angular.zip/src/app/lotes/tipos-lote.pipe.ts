import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'tiposLote'
})
export class TiposLotePipe implements PipeTransform {

  transform(value: number): string {
    switch (value) {
     case 1:
        return 'PACS008';
     case 2:
        return 'PACS002';
     default:
        return '-';
    }
  }

}
