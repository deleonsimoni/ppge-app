import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { PageEvent } from '@angular/material/paginator';
import { SnackbarService } from '@core/services';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import { LotesService } from './lotes.service';

@Component({
  selector: 'app-lotes',
  templateUrl: './lotes.component.html',
  styleUrls: ['./lotes.component.scss']
})
export class LotesComponent {

    readonly date = new Date(new Date().setDate(new Date().getDate()));
    readonly data$ = new BehaviorSubject<any>(null);

    readonly form = this.fb.group({
        data: [
          moment([
            this.date.getFullYear(),
            this.date.getMonth(),
            this.date.getDate(),
          ])
        ],
        status: [''],
        endToEnd: ['']
      });
    header = ['id', 'status', 'dataGeracao', 'tipoDoLote'];

    readonly isConsultaEndToEnd$ = this.form.get('endToEnd').valueChanges.subscribe(() => {
      if(this.form.get('endToEnd').value != "") {
        this.form.get('data').setValue("");
        this.form.get('status').setValue("");
      } else {
        this.form.get('data').setValue(moment([
          this.date.getFullYear(),
          this.date.getMonth(),
          this.date.getDate(),
        ]));
      }
    });
    constructor(
        private fb: FormBuilder,
        public datepipe: DatePipe,
        private snackbarService: SnackbarService,
        private lotesService: LotesService,
    ) {
      this.form.get('endToEnd').valueChanges.subscribe()
    }

    getData(date: Date) {
      return this.datepipe.transform(date, 'dd/MM/yyyy');
    }

    onSubmit(): void {
      if(this.form.value.endToEnd){
        this.lotesService.getLotesCanalSecundarioPorId(this.form.value.endToEnd).pipe(take(1))
        .subscribe((consulta) => {
          this.data$.next(consulta);
        });
      } else {
        this.lotesService.getLotesCanalSecundario(
          this.getData(this.form.value.data),
          this.form.value.status,
        )
        .pipe(take(1))
        .subscribe((consulta) => {
          if (consulta.dados.length == 0) {
            this.snackbarService.open(
              'Nenhum Registro Encontrado.',
              'error',
            );
            this.data$.next(null);
          } else {
            this.data$.next(consulta);
          }
        });
      }
    }

    onPagination(event: PageEvent): void {
      this.lotesService.getLotesCanalSecundario(
          this.getData(this.form.value.data),
          this.form.value.status,
          event.pageIndex + 1,
          event.pageSize,
        )
        .pipe(take(1))
        .subscribe((dados) => {
          this.data$.next(dados);
        });
    }

}
