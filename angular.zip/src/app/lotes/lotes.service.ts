import { Observable } from 'rxjs';
import { environment } from '@env/environment';
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { ConsultaLotesCanalSecundario, LotesCanalSecundario } from './lotes.model';
import { map, catchError } from 'rxjs/operators';
import { SnackbarService } from '../core/services/snackbar.service';
import { getServerErrorMessage } from '../shared/functions-utils';

@Injectable({
  providedIn: 'root'
})
export class LotesService {

  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
    private readonly URL_LOTES_ENVIADOS = `${this.URL_PIX_GESTAO}/lote-pagamentos`;

    constructor(
      private http: HttpClient,
      private snackbarService: SnackbarService
      ) {}

    public getLotesCanalSecundario(
        data: string,
        situacao: string,
        page: number = 1,
        tamanhoPagina: number = 15,
      ): Observable<ConsultaLotesCanalSecundario> {
        let params = new HttpParams()
          .set("data", data)
          .set("pagina", page.toString())
          .set("tamanhoPagina", tamanhoPagina.toString());

          if(situacao) {
            params = params.set('situacao', situacao);
          }

        return this.http.get<ConsultaLotesCanalSecundario>(
          this.URL_LOTES_ENVIADOS, { params });
    }

    getLotesCanalSecundarioPorId(endToEnd: string): Observable<ConsultaLotesCanalSecundario>{
      return this.http.get<ConsultaLotesCanalSecundario>(`${this.URL_LOTES_ENVIADOS}/${endToEnd}`).pipe(
        map((response) => {
          if (response.totalRegistros <= 0) {
            this.snackbarService.open("Nenhum Registro Encontrado.",'error');
          } else {
            return response;
          }
        }),
        catchError((error) => {
          let errorMsg: string;
          errorMsg = this.getServerErrorMessage(error);
          this.snackbarService.open(errorMsg,'error');
          throw errorMsg;
        })
      );
    }
    private getServerErrorMessage(error: HttpErrorResponse): string {
      switch (error.status) {
        case 404: {
          return `Not Found.`;
        }
        case 403: {
          return `Access Denied.`;
        }
        case 500: {
          return `Internal Server Error.`;
        }
        default: {
          return `Unknown Server Error.`;
        }
      }
    }
}
