import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LotesComponent } from './lotes.component';
import { LotesRoutingModule } from './lotes-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgxCurrencyModule } from 'ngx-currency';
import { NgxMaskModule } from 'ngx-mask';
import { StatusLotesPipe } from './status-lotes.pipe';
import { TiposLotePipe } from './tipos-lote.pipe';



@NgModule({
  declarations: [
    LotesComponent,
    StatusLotesPipe,
    TiposLotePipe,
  ],
  imports: [
    CommonModule,
    LotesRoutingModule,
    ReactiveFormsModule,
      MatCardModule,
      MatDatepickerModule,
      MatDialogModule,
      MatGridListModule,
      MatInputModule,
      MatListModule,
      MatRadioModule,
      MatSelectModule,
      MatSnackBarModule,
      MatTooltipModule,
      NgxCurrencyModule,
      NgxMaskModule.forRoot(),
      MatButtonModule,
      MatPaginatorModule,
      MatTableModule
  ]
})
export class LotesModule { }
