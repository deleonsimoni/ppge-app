import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'statusLotes'
})
export class StatusLotesPipe implements PipeTransform {

  transform(value: number): string {
    switch (value) {
     case 1:
       return 'Aberto';
     case 2:
       return 'Não Processado';
     case 3:
       return 'Em Processamento';
     case 4:
       return 'Processado';
     default:
       return '-';
    }
  }

}
