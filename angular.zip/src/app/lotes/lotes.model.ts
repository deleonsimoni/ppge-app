export interface ConsultaLotesCanalSecundario {
  dados: LotesCanalSecundario[];
  pagina: number;
  paginas: number;
  tamanhoPagina: number;
  totalRegistros: number;
}

export interface LotesCanalSecundario {
  coMensagemPgmno: string;
  tsLotePagamento: string;
  tipoSituacaoLote: number;
  nuTipomensagem: number;
}
