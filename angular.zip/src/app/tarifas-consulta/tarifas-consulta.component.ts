import { Component } from '@angular/core';
import { ChangeDetectionStrategy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';
import { TarifasConsultaService } from './tarifas-consulta.service';
import { PageEvent } from '@angular/material/paginator';
import { Aprovacao, Processamento } from './tarifas-consulta.model';
import { DatePipe } from '@angular/common';
import { take, tap } from 'rxjs/operators';

@Component({
  selector: 'app-tarifas-consulta',
  templateUrl: './tarifas-consulta.component.html',
  styleUrls: ['./tarifas-consulta.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TarifasConsultaComponent {
  readonly processamento = Processamento;
  readonly aprovacao = Aprovacao;
  readonly date = new Date(new Date().setDate(new Date().getDate() - 1));
  readonly data$ = new BehaviorSubject<any>(null);

  readonly form = this.fb.group({
    dataInicial: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
    dataFinal: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
    tipoServico: 'Mensagem',
  });

  paginaAtual = 1;
  tipoServicoPesquisado = '';
  constructor(
    public dialog: MatDialog,
    private fb: FormBuilder,
    private tarifasConsultaService: TarifasConsultaService,
    public datepipe: DatePipe,
  ) {}

  getData(date: Date) {
    return this.datepipe.transform(date, 'dd/MM/yyyy');
  }

  onSubmit(): void {
    this.tipoServicoPesquisado = this.form.value.tipoServico;
    this.paginaAtual = 1;
    this.tarifasConsultaService
      .getControleTarifas(
        this.getData(this.form.value.dataInicial),
        this.getData(this.form.value.dataFinal),
        this.form.value.tipoServico,
        this.paginaAtual,
        15
      )
      .pipe(take(1))
      .subscribe((consulta) => {
        this.data$.next(consulta);
    });
  }


  onPagination(event: PageEvent): void {
    this.tarifasConsultaService
      .getControleTarifas(
        this.getData(this.form.value.dataInicial),
        this.getData(this.form.value.dataFinal),
        this.form.value.tipoServico,
        event.pageIndex + 1,
        event.pageSize
      )
      .pipe(take(1))
      .subscribe((dados) => {
        this.data$.next(dados);
      });
  }
}
