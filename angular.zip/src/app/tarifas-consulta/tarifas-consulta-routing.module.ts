import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TarifasConsultaComponent } from './tarifas-consulta.component';



const routes: Routes = [
  {
    path: '',
    component: TarifasConsultaComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TarifasConsultaRoutingModule { }
