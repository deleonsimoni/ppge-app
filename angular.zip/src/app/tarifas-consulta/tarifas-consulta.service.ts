import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { Observable } from 'rxjs';
import { ValidaMovimento, ConsultaProcessamento, ParametroPesquisa, ProcessamentoPendente, ClassificacaoManual } from './tarifas-consulta.model';
import { HttpClient, HttpParams } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class TarifasConsultaService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_CONTROLE_TARIFAS = `${this.URL_PIX_GESTAO}/controle-tarifas`;
  constructor(private http: HttpClient, public datepipe: DatePipe) {}

  public getControleTarifas(
    dataInicio: string,
    dataFim: string,
    tipoServico: string,
    page: number = 1,
    tamanhoPagina: number = 15,
  ): Observable<ConsultaProcessamento> {
    return this.http.get<ConsultaProcessamento>(
      this.URL_CONTROLE_TARIFAS,
      {
        params: {
          dataInicio: dataInicio,
          dataFim: dataFim,
          tipoServico: tipoServico,
          pagina: page.toString(),
          tamanhoPagina: tamanhoPagina.toString(),
        },
      },
    );
  }
}
