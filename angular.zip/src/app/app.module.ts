import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, LOCALE_ID } from '@angular/core';
import { DatePipe, registerLocaleData } from '@angular/common';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { MAT_DATE_LOCALE } from '@angular/material/core';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { NgxCurrencyModule } from 'ngx-currency';
import { HIGHLIGHT_OPTIONS, HighlightModule } from 'ngx-highlightjs';
import { LoadingInterceptor, SSOInterceptor } from '@core/interceptors';
import { AppStoreModule } from '@store/store.module';
import { LoginService } from '@store/login';
import { HeaderModule } from './header/header.module';
import { NavModule } from './nav/nav.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FooterComponent } from './footer/footer.component';
import { SnackbarModule } from '@core/components';

import locale from '@angular/common/locales/pt';
import { MatPaginatorIntl } from '@angular/material/paginator';
registerLocaleData(locale);

export const currencyMaskConfig = {
  align: 'left',
  allowNegative: false,
  allowZero: true,
  decimal: ',',
  precision: 2,
  prefix: '',
  suffix: '',
  thousands: '.',
  nullable: true,
};

export function getHighlightLanguages() {
  return {
    xml: () => import('highlight.js/lib/languages/xml'),
  };
}

export function getDutchPaginatorIntl() {
  const paginatorIntl = new MatPaginatorIntl();

  paginatorIntl.itemsPerPageLabel = 'Itens por Página:';
  paginatorIntl.nextPageLabel = 'Próxima Página';
  paginatorIntl.lastPageLabel = 'Última Página';
  paginatorIntl.firstPageLabel = 'Primeira Página';
  paginatorIntl.previousPageLabel = 'Página Anterior';

  return paginatorIntl;
}

@NgModule({
  declarations: [AppComponent, FooterComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    AppRoutingModule,
    AppStoreModule,
    MatMomentDateModule,
    MatProgressBarModule,
    NgxCurrencyModule.forRoot(currencyMaskConfig),
    HighlightModule,
    MatSidenavModule,
    HeaderModule,
    NavModule,
    SnackbarModule,
  ],
  providers: [
    DatePipe,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: SSOInterceptor,
      multi: true,
      deps: [LoginService],
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: LoadingInterceptor,
      multi: true,
    },
    { provide: MAT_DATE_LOCALE, useValue: 'pt-BR' },
    { provide: LOCALE_ID, useValue: 'pt' },
    { provide: MatPaginatorIntl, useValue: getDutchPaginatorIntl()},
    {
      provide: HIGHLIGHT_OPTIONS,
      useValue: {
        languages: getHighlightLanguages(),
        tabReplace: '  ',
      },
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
