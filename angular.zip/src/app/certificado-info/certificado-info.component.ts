import { Component, OnInit } from '@angular/core';
import { SnackbarService } from '@core/services';
import { CertificadoInfoService } from './certificado-info.service';

@Component({
  selector: 'app-certificado-info',
  templateUrl: './certificado-info.component.html',
  styleUrls: ['./certificado-info.component.scss']
})
export class CertificadoInfoComponent implements OnInit {

  certificadosInfo = [];

  header = ['alias', 'name', 'thumbprint', 'dataExpiracao', 'dias'];

  constructor(
    private certificadoInfoService: CertificadoInfoService) { }

  ngOnInit(): void {

    this.certificadoInfoService
    .getDetalheCertificados()
    .subscribe((data) => {
      this.certificadosInfo = data.filter((a) => a.expiresIn > 0).sort((a, b) => new Date(b.certExpiryDate).getTime() - new Date(a.certExpiryDate).getTime());
    });


  }

}
