import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificadoInfoComponent } from './certificado-info.component';

describe('CertificadoInfoComponent', () => {
  let component: CertificadoInfoComponent;
  let fixture: ComponentFixture<CertificadoInfoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CertificadoInfoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CertificadoInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
