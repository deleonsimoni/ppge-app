import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CertificadoInfoComponent } from './certificado-info.component';
import { CertificadoInfoRoutingModule } from './certificado-info-routing.module';
import { MatTableModule } from '@angular/material/table';



@NgModule({
  declarations: [CertificadoInfoComponent],
  imports: [
    CommonModule,
    CertificadoInfoRoutingModule,
    MatTableModule
  ]
})
export class CertificadoInfoModule { }
