import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SolucaoDiferencaComponent } from './solucao-diferenca.component';

const routes: Routes = [ {
  path: '',
  component: SolucaoDiferencaComponent,
},];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SolucaoDiferencaRoutingModule { }
