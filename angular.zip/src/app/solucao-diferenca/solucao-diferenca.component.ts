import { DatePipe } from '@angular/common';
import { ChangeDetectionStrategy, Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { SnackbarService } from '@core/services';
import { BehaviorSubject } from 'rxjs';
import * as moment from 'moment';
import { PageEvent } from '@angular/material/paginator';
import { SolucaoDiferenca } from './solucao-diferenca.model';
import { SolucaoDiferencaService } from './solucao-diferenca.service';
import { MatDialog } from '@angular/material/dialog';
import { UploadArquivoDialogComponent } from './upload-arquivo-dialog/upload-arquivo-dialog.component';
import { take, tap } from 'rxjs/operators';
import { LoginService } from '@store/login';

@Component({
  selector: 'app-solucao-diferenca',
  templateUrl: './solucao-diferenca.component.html',
  styleUrls: ['./solucao-diferenca.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SolucaoDiferencaComponent implements OnDestroy {
  readonly date = new Date(new Date().setDate(new Date().getDate()));
  readonly data$ = new BehaviorSubject<SolucaoDiferenca>(null);
  readonly statusProcessamento$ = new BehaviorSubject<object>(null);
  idTimeout;

  readonly form = this.fb.group({
    data: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
    file: [''],
  });

  header = ['codigoInstrucao', 'data', 'valor', 'ocorrencia'];

  constructor(
    private fb: FormBuilder,
    public datepipe: DatePipe,
    private snackbarService: SnackbarService,
    private solucaoDiferencaService: SolucaoDiferencaService,
    public dialog: MatDialog,
    public loginService: LoginService
  ) {
    this.getStatus();
    this.idTimeout = setInterval(() => {
      console.log("Atualizando processamento arquivo");
      this.getStatus();
    }, 5000);
  }

  getStatus(){
    this.solucaoDiferencaService
    .getStatusProcessamento()
    .pipe(take(1))
    .subscribe((status) => this.statusProcessamento$.next(status));
  }

  ngOnDestroy() {
    console.log("limpando timeopu");
    clearInterval(this.idTimeout);
  }

  onSubmit(): void {
    this.solucaoDiferencaService
      .getSolucaoDiferenca(this.form.value.data)
      .pipe(take(1))
      .subscribe((consulta) => {
        this.data$.next(consulta);
      });
  }

  onPagination(event: PageEvent): void {
    this.solucaoDiferencaService
      .getSolucaoDiferenca(
        this.form.value.data,
        event.pageIndex + 1,
        event.pageSize,
      )
      .pipe(take(1))
      .subscribe((consulta) => {
        this.data$.next(consulta);
      });
  }

  openDialogArquivo() {
   const dialogRef = this.dialog.open(UploadArquivoDialogComponent, {
      width: '600px',
    });
    dialogRef
    .afterClosed()
    .pipe(take(1))
    .subscribe();
  }
}
