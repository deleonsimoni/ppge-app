export interface SolucaoDiferenca {
  dados: RelacaoLancamento[];
	pagina: number;
	paginas: number;
	tamanhoPagina: number;
	totalRegistros: number;
}

export interface RelacaoLancamento {
  mensagem: string;
	codigoInstrucao: string;
	valor: number;
	dataLancamento: Date;
	ocorrencia: number;
	dataProcessamento: Date;
}
