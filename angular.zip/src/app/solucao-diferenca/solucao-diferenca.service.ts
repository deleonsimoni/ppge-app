import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { environment } from '@env/environment';
import { SolucaoDiferenca } from './solucao-diferenca.model';
import { catchError, map, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class SolucaoDiferencaService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_CONSULTA = `${this.URL_PIX_GESTAO}/lancamentos/consultar-relacao-lancamento`;
  private readonly URL_UPLOAD = `${this.URL_PIX_GESTAO}/lancamentos/upload`;
  private readonly URL_STATUS = `${this.URL_PIX_GESTAO}/lancamentos/status-processamento`;

  constructor(private http: HttpClient, public datepipe: DatePipe) {}

  getSolucaoDiferenca(data: Date, page: number = 1, tamanhoPagina: number = 15,): Observable<SolucaoDiferenca> {
    let params = new HttpParams();
    params = params
      .set('pagina', page.toString())
      .set('tamanhoPagina', tamanhoPagina.toString())
      .set('dataProcessamento', data.toString());
    return this.http.get<SolucaoDiferenca>(this.URL_CONSULTA, { params });
  }

  getStatusProcessamento(): Observable<object> {
    return this.http.get<SolucaoDiferenca>(this.URL_STATUS);
  }

  postArquvivoProcessametno(arquivo: File): Observable<boolean> {
    const formData: FormData = new FormData();
    formData.append('file', arquivo);
    return this.http
    .post(this.URL_UPLOAD, formData, { observe: 'response' })
    .pipe(
      map((response) => response.status === 202),
      catchError((err) => {
        throw err.error.errorMessage;
      }),
    );
  }

}
