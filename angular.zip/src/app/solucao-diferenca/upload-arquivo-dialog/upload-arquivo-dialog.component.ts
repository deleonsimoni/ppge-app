import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { SnackbarService } from '@core/services';
import { SolucaoDiferencaService } from '../solucao-diferenca.service';

@Component({
  selector: 'app-upload-arquivo-dialog',
  templateUrl: './upload-arquivo-dialog.component.html',
  styleUrls: [
    './upload-arquivo-dialog.component.scss',
    '../solucao-diferenca.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class UploadArquivoDialogComponent {
  readonly form = this.fb.group({
    file: ['', Validators.required],
  });

  constructor(
    private fb: FormBuilder,
    private snackbarService: SnackbarService,
    private solucaoDiferencaService: SolucaoDiferencaService,
    private dialogRef: MatDialogRef<UploadArquivoDialogComponent>,
  ) {}

  processarArquivo() {
    this.solucaoDiferencaService
      .postArquvivoProcessametno(this.form.value.file)
      .subscribe(
        (response) => {
          if (response) {
            this.snackbarService.open(
              'Arquivo enviado com sucesso! Aguarde o processamento.',
              'success',
            );
          } else {
            this.snackbarService.open(
              'Ocorreu um erro ao processar o arquvo.',
              'error',
            );
          }
          this.dialogRef.close();
        },
        (error) => {
          this.snackbarService.open('Erro ao processar arquivo: ' + error, 'error');
        },
      );
  }
}
