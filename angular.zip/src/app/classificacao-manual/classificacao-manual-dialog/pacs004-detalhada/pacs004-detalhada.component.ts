import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { DetalhePacs004 } from '@app/consulta/por-servico/por-servico.model';

@Component({
  selector: 'app-pacs004-detalhada',
  templateUrl: './pacs004-detalhada.component.html',
  styleUrls: [
    './pacs004-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Pacs004DetalhadaComponent {
  @Input() detalhe: DetalhePacs004;
}
