import {
  Component,
  ChangeDetectionStrategy,
  ViewChild,
  Inject,
} from '@angular/core';
import { MatStepper } from '@angular/material/stepper';
import { SnackbarService } from '@core/services';
import { ValidaMovimentoService } from '@app/valida-movimento/valida-movimento.service';
import { FormBuilder, Validators, NgForm } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { take } from 'rxjs/operators';
import { LoginService } from '@store/login';

@Component({
  selector: 'app-classificacao-manual-dialog',
  templateUrl: './classificacao-manual-dialog.component.html',
  styleUrls: ['./classificacao-manual-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ClassificacaoManualDialogComponent {
  @ViewChild('stepper') stepper: MatStepper;

  @ViewChild('myForm') myForm: NgForm;

  readonly form = this.fb.group({
    situacaoLancamento: ['', [Validators.required, Validators.maxLength(1)]],
    codigoEventoContabil: ['', [Validators.required, Validators.maxLength(6)]],
  });

  constructor(
    private snackbarService: SnackbarService,
    private validaMovimentoService: ValidaMovimentoService,
    private fb: FormBuilder,
    public dialog: MatDialogRef<ClassificacaoManualDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    public loginService: LoginService
  ) {}

  getTipoMensagem() {
    if (this.data.codInstrucaoOriginal) {
      return this.data.codInstrucaoOriginal.startsWith('E')
        ? 'PACS008'
        : this.data.codInstrucaoOriginal.startsWith('D')
        ? 'PACS004'
        : 'APORTE';
    } else {
      return null;
    }
  }

  avancarClassificacaoMensagem() {
    this.stepper.next();
  }

  salvarClassificacaoManual() {
    this.validaMovimentoService
      .postClassificacaoManual(this.form.getRawValue(), this.data.idLancamento)
      .pipe(take(1))
      .subscribe(
        (response) => {
          if (response) {
            this.stepper.reset();
            this.form.reset();
            this.snackbarService.open('Salvo com sucesso', 'success');
            this.dialog.close();
          }
        },
        (error) => {
          this.snackbarService.open('Erro ao salvar: ' + error, 'error');
        },
      );
  }

  resetForm() {
    this.myForm.resetForm();
    this.stepper.reset();
  }

  getData(timestamp: number) {
    return new Date(timestamp);
  }
}
