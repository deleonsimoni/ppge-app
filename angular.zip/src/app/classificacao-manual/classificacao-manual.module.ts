import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClassificacaoManualRoutingModule } from './classificacao-manual-routing.module';
import { ClassificacaoManualComponent } from './classificacao-manual.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgxCurrencyModule } from 'ngx-currency';
import { NgxMaskModule } from 'ngx-mask';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { ClassificacaoManualDialogComponent } from './classificacao-manual-dialog/classificacao-manual-dialog.component';
import { MatPaginatorModule } from '@angular/material/paginator';
import {MatStepperModule} from '@angular/material/stepper';
import { Pacs004DetalhadaComponent } from './classificacao-manual-dialog/pacs004-detalhada/pacs004-detalhada.component';
import { Pacs008DetalhadaComponent } from './classificacao-manual-dialog/pacs008-detalhada/pacs008-detalhada.component';


@NgModule({
  declarations: [ClassificacaoManualComponent, ClassificacaoManualDialogComponent, Pacs004DetalhadaComponent, Pacs008DetalhadaComponent],
  imports: [
    CommonModule,
    ClassificacaoManualRoutingModule,
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatDatepickerModule,
    MatDialogModule,
    MatGridListModule,
    MatInputModule,
    MatListModule,
    MatRadioModule,
    MatSelectModule,
    MatSnackBarModule,
    MatTooltipModule,
    NgxCurrencyModule,
    NgxMaskModule.forRoot(),
    MatButtonModule,
    MatTableModule,
    MatPaginatorModule,
    MatStepperModule
  ]
})
export class ClassificacaoManualModule { }
