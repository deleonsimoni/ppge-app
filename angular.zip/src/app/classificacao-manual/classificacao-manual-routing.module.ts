import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClassificacaoManualComponent } from './classificacao-manual.component';


const routes: Routes = [
  {
    path: '',
    component: ClassificacaoManualComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ClassificacaoManualRoutingModule { }
