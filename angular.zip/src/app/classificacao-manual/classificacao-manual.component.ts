import { Component, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { BehaviorSubject } from 'rxjs';
import { ProcessamentoPendente } from '@app/valida-movimento/valida-movimento.model';
import { PageEvent } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { ClassificacaoManualDialogComponent } from './classificacao-manual-dialog/classificacao-manual-dialog.component';
import { ValidaMovimentoService } from '@app/valida-movimento/valida-movimento.service';
import { SaldoService } from '@app/saldo/saldo.service';
import * as moment from 'moment';
import { take } from 'rxjs/operators';
import { ChaveSinafService } from '@app/chave-sinaf/chave-sinaf.service';

@Component({
  selector: 'app-classificacao-manual',
  templateUrl: './classificacao-manual.component.html',
  styleUrls: ['./classificacao-manual.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ClassificacaoManualComponent {
  msgPendente$ = new BehaviorSubject<ProcessamentoPendente>(null);
  header = [
    'tipoMensagem',
    'codInstrucaoOriginal',
    'situacaoProcessamento',
    'tipoSituacao',
    'valorLancamento',
    'acao',
  ];
  readonly date = new Date(new Date().setDate(new Date().getDate()));
  readonly form = this.fb.group({
    dataInicio: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
    dataFim: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
    valorInicio: ['0.00', Validators.required],
    valorFim: ['0.00', Validators.required],
    tipoMensagem: ['', Validators.required],
  });

  constructor(
    private fb: FormBuilder,
    public dialog: MatDialog,
    private validaMovimentoService: ValidaMovimentoService,
    private chaveSinafService: ChaveSinafService,
    private saldoService: SaldoService,
  ) {}

  onSubmit() {
    if (!this.form.invalid) {
      this.validaMovimentoService
        .getClassificacaoManualFiltro(this.form.getRawValue())
        .pipe(take(1))
        .subscribe((dados) => {
          this.msgPendente$.next(dados);
        });
    }
  }

  onPagination(event: PageEvent): void {
    this.validaMovimentoService
      .getClassificacaoManualFiltro(
        this.form.getRawValue(),
        event.pageIndex + 1,
        event.pageSize,
      ).pipe(take(1))
      .subscribe((dados) => {
        this.msgPendente$.next(dados);
      });
  }

  openDialog(
    idMensagem: string,
    codInstrucaoOriginal: string,
    idLancamento: string,
  ) {
    let dialog;
    if (
      !(
        codInstrucaoOriginal.startsWith('E') ||
        codInstrucaoOriginal.startsWith('D')
      )
    ) {
      this.saldoService
        .getDetalheAporteSaque(idMensagem).pipe(take(1))
        .subscribe((detalheAporteSaque) => {
          dialog = this.dialog.open(ClassificacaoManualDialogComponent, {
            data: { detalheAporteSaque, codInstrucaoOriginal, idLancamento },
            maxHeight: '800px',
            width: '1000px',
          });
          dialog.afterClosed().subscribe((result) => {
            this.onSubmit();
          });
        });
    } else {
      let data: string = codInstrucaoOriginal.substring(9, 17);

      data = moment(data).format('DD/MM/YYYY');
      
      this.chaveSinafService
        .getDetalheMensagem(Number(idMensagem), data).pipe(take(1))
        .subscribe((detalhe) => {
          dialog = this.dialog.open(ClassificacaoManualDialogComponent, {
            data: { detalhe, codInstrucaoOriginal, idLancamento },
            maxHeight: '800px',
            width: '1000px',
          });
          dialog.afterClosed().subscribe((result) => {
            this.onSubmit();
          });
        });
    }
  }
}
