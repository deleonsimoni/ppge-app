import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { environment } from '@env/environment';

@Injectable({
  providedIn: 'root',
})
export class ExtratoService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_EXTRATO = `${this.URL_PIX_GESTAO}/extrato-saldo`;
  private readonly URL_EXPORTAR = `${this.URL_EXTRATO}/exportar`;

  constructor(private http: HttpClient, public datepipe: DatePipe) {}

  getExtrato(data: string, page: number = 1, tamanhoPagina: number = 15,): Observable<any[]> {
    let params = new HttpParams();
    params = params
      .set('pagina', page.toString())
      .set('tamanhoPagina', tamanhoPagina.toString())
      .set('data', data);
    return this.http.get<any>(this.URL_EXTRATO, { params });
  }

  getDownloadPdf(data: string){
    let params = new HttpParams();
    if (data) {
      params = params.set('data', data);
    }
    return this.http.get<any>(this.URL_EXPORTAR, { params, responseType: 'blob' as 'json'});
  }

}
