import { Component, ChangeDetectionStrategy } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Validators, FormBuilder } from '@angular/forms';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';
import { ExtratoService } from './extrato.service';
import { PageEvent } from '@angular/material/paginator';
import { take, tap } from 'rxjs/operators';
import { SnackbarService } from '@core/services';

@Component({
  selector: 'app-extrato',
  templateUrl: './extrato.component.html',
  styleUrls: ['./extrato.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ExtratoComponent {
  readonly date = new Date(new Date().setDate(new Date().getDate()));
  readonly data$ = new BehaviorSubject<any>(null);

  readonly form = this.fb.group({
    data: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
  });

  header = [
    'horarioMPI',
    'saldoDisponivelMPI',
    'saldoBloqueadoMPI',
    'horarioBacen',
    'saldoDisponivelBacen',
    'saldoBloqueadoBacen',
    'diferencaDisponivelSPI',
    'diferencaBloqueadaSPI',
  ];

  dataExtrato;
  constructor(
    private fb: FormBuilder,
    private extratoService: ExtratoService,
    public datepipe: DatePipe,
    private snackbarService: SnackbarService,
  ) {}

  getData(date: Date) {
    return this.datepipe.transform(date, 'dd/MM/yyyy');
  }

  onSubmit(): void {
    this.dataExtrato = this.getData(this.form.value.data);
    this.extratoService
      .getExtrato(this.getData(this.form.value.data), 1, 15)
      .pipe(take(1))
      .subscribe((consulta) => {
        this.data$.next(consulta);
      });
  }

  onPagination(event: PageEvent): void {
    this.extratoService
      .getExtrato(
        this.getData(this.form.value.data),
        event.pageIndex + 1,
        event.pageSize,
      )
      .pipe(take(1))
      .subscribe((consulta) => {
        this.data$.next(consulta);
      });
  }

  onDownloadPdf() {
    this.extratoService
      .getDownloadPdf(this.dataExtrato)
      .pipe(take(1))
      .subscribe(
        (blob) => {
          const a = document.createElement('a');
          const objectUrl = URL.createObjectURL(blob);
          a.href = objectUrl;
          a.download = 'HistoricodeSaldo_' + this.dataExtrato + '.pdf';
          a.click();
          URL.revokeObjectURL(objectUrl);
        },
        (error) => {
          this.snackbarService.open(
            'Erro ao realizar download do PDF!',
            'error',
          );
        },
      );
  }
}
