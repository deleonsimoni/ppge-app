import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Output,
} from '@angular/core';
import { Store } from '@ngrx/store';
import { logout, selectLogin } from '@store/login';
import { environment } from '@env/environment';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class HeaderComponent {
  @Output() toggleSidenav = new EventEmitter();
  readonly loginState$ = this.store.pipe(selectLogin);

  constructor(private store: Store<{}>) {}

  isHomologacao(): boolean {
    if (environment.ambiente.toUpperCase() == 'DES' || (environment.ambiente.toUpperCase() == 'HMP')) {
      return true;
    } else {
      return false;
    }
  }

  logout(): void {
    this.store.dispatch(logout());
  }
}
