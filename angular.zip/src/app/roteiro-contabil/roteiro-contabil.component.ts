import { Component, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { RoteiroContabilService } from './roteiro-contabil.service';
import { MatDialog } from '@angular/material/dialog';
import { RoteiroOperacional } from './roteiro-contabil.model';
import { BehaviorSubject } from 'rxjs';
import { EventoDialogComponent } from './evento-dialog/evento-dialog.component';
import { take } from 'rxjs/operators';
import { LoginService } from '@store/login';

@Component({
  selector: 'app-roteiro-contabil',
  templateUrl: './roteiro-contabil.component.html',
  styleUrls: ['./roteiro-contabil.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RoteiroContabilComponent {
  readonly displayedColumnsPacs = [
    'dataAtivacao',
    'dataDesativacao',
    'mensagemComplementar',
    'tag',
    'valorTag',
    'lancamento',
    'sistemaLegado',
    'opcao',
  ];
  readonly displayedColumnsSelLpi = [
    'dataAtivacao',
    'dataDesativacao',
    'mensagem',
    'lancamento',
    'sistemaLegado',
    'opcao',
  ];
  readonly roteirosOperacionais$ = new BehaviorSubject<RoteiroOperacional[]>(
    null,
  );

  readonly form = this.fb.group({
    mensagem: ['', [Validators.required]],
  });

  constructor(
    private fb: FormBuilder,
    private roteiroContabilService: RoteiroContabilService,
    public dialog: MatDialog,
    public loginService: LoginService
  ) {}

  onSubmit() {
    this.roteiroContabilService
      .getRoteiroOperacionais(this.form.controls['mensagem'].value)
      .pipe(take(1))
      .subscribe((roteiro) => this.roteirosOperacionais$.next(roteiro));
  }

  openRoteiroContabil(id: number, codigoMensagem: string) {
    this.roteiroContabilService
      .getRoteirosContabeis(id)
      .pipe(take(1))
      .subscribe((roteiro) => {
        this.dialog.open(EventoDialogComponent, {
          width: '800px',
          data: { codigoMensagem, roteiro, id },
        });
      });
  }

  getDate(data: number) {
    if (data) {
      return new Date(data);
    }
    return null;
  }
}
