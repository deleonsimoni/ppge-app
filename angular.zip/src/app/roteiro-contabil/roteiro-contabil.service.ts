import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { Observable } from 'rxjs';
import { RoteiroOperacional, RoteiroContabil } from './roteiro-contabil.model';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class RoteiroContabilService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;

  private readonly URL_OPERACIONAL = `${this.URL_PIX_GESTAO}/contabil/roteiro-operacional`;
  private readonly URL_CONTABIL = `${this.URL_PIX_GESTAO}/contabil/roteiro-contabil`;

  constructor(private http: HttpClient, public datepipe: DatePipe) {}

  public getRoteiroOperacionais(
    tipoMensagem: string,
  ): Observable<RoteiroOperacional[]> {
    return this.http.get<RoteiroOperacional[]>(this.URL_OPERACIONAL, {
      params: { 'tipo-mensagem': tipoMensagem },
    });
  }

  public getRoteirosContabeis(
    idRoteiroOperacional: number,
  ): Observable<RoteiroContabil[]> {
    return this.http.get<RoteiroContabil[]>(this.URL_CONTABIL, {
      params: { 'id-roteiro-operacional': idRoteiroOperacional.toString() },
    });
  }

  public postRoteiroContabil(
    roteiroContabil: RoteiroContabil,
  ): Observable<boolean> {
    return this.http
      .post<boolean>(this.URL_CONTABIL, roteiroContabil, {
        observe: 'response',
      })
      .pipe(
        map((response) => response.status === 201),
        catchError((err) => {
          throw err.error.errorMessage;
        }),
      );
  }

  public putRoteiroContabil(
    roteiroContabil: RoteiroContabil,
  ): Observable<boolean> {
    return this.http
      .put<boolean>(
        `${this.URL_CONTABIL}/${roteiroContabil.id}`,
        roteiroContabil,
        { observe: 'response' },
      )
      .pipe(
        map((response) => response.status === 200),
        catchError((err) => {
          throw err.error.errorMessage;
        }),
      );
  }

  public postDuplicarRoteiroContabil(
    roteiroContabil: RoteiroContabil,
  ): Observable<boolean> {
    return this.http
      .post<boolean>(`${this.URL_CONTABIL}/duplicar`, roteiroContabil, {
        observe: 'response',
      })
      .pipe(
        map((response) => response.status === 201),
        catchError((err) => {
          throw err.error.errorMessage;
        }),
      );
  }
}
