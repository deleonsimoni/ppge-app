export interface RoteiroOperacional {
  id: number;
  origemLancamento: OrigemLancamento
  codigoMensagem: string;
  dataAtivacao: string;
  dataDesativacao: string;
  codMensagemComplementar: string;
  nomeTag: string;
  valorTag: string;
  tipoLancamento: string;
  codSistemaLegado: string;
}

export interface RoteiroContabil {
  id: number;
  idRoteiroOperacional: number;
  dataAtivacao: string;
  dataDesativacao: string;
  codigoEventoContabil: string;
  situacaoLancamento: string;
}

export interface  OrigemLancamento {
  id: number;
  sigla: string;
  nome: string;
}

export interface ErrorResponse {
  errorCode: number;
  errorMessage: string;
}


