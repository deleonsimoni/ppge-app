import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RoteiroContabilRoutingModule } from './roteiro-contabil-routing.module';
import { RoteiroContabilComponent } from './roteiro-contabil.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgxCurrencyModule } from 'ngx-currency';
import { NgxMaskModule } from 'ngx-mask';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { EventoDialogComponent } from './evento-dialog/evento-dialog.component';



@NgModule({
  declarations: [RoteiroContabilComponent, EventoDialogComponent],
  imports: [
    CommonModule,
    RoteiroContabilRoutingModule,
    ReactiveFormsModule,
    MatCardModule,
    MatDatepickerModule,
    MatDialogModule,
    MatGridListModule,
    MatInputModule,
    MatListModule,
    MatRadioModule,
    MatSelectModule,
    MatSnackBarModule,
    MatTooltipModule,
    NgxCurrencyModule,
    NgxMaskModule.forRoot(),
    MatButtonModule,
    MatTableModule
  ]
})
export class RoteiroContabilModule { }
