import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators, NgForm } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RoteiroContabilComponent } from '../roteiro-contabil.component';
import { RoteiroContabilService } from '../roteiro-contabil.service';
import { RoteiroContabil } from '../roteiro-contabil.model';
import DataUtils from '@app/shared/data-utils';
import { SnackbarService } from '@core/services';
import { tap } from 'rxjs/operators';
import { DatePipe } from '@angular/common';
import { LoginService } from '@store/login';

@Component({
  selector: 'app-evento-dialog',
  templateUrl: './evento-dialog.component.html',
  styleUrls: ['./evento-dialog.component.scss'],
})
export class EventoDialogComponent implements OnInit{

  @ViewChild('form', {static: false}) myForm: NgForm;

  readonly displayedColumns = ['evento', 'sl', 'dataAtivacao', 'dataDesativacao', 'opcoes'];
  readonly dataDisponivel = this.getDataDisponivel();
  public isCadastro= true;
  public showFormCadastro= false;

  readonly formEventoContabil = this.fb.group({
    id: [null],
    idRoteiroOperacional: [this.data.id, [Validators.required]],
    dataAtivacao: ['', [Validators.required]],
    dataDesativacao: [null],
    codigoEventoContabil: ['', [Validators.required, Validators.maxLength(6)]],
    situacaoLancamento: ['', [Validators.required, Validators.maxLength(1)]],
  });

  constructor(
    private fb: FormBuilder,
    private roteiroContabilService: RoteiroContabilService,
    private snackbarService: SnackbarService,
    public dialogRef: MatDialogRef<RoteiroContabilComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private datePipe: DatePipe,
    public loginService: LoginService
  ) {}

  ngOnInit(){
    console.log(this.data);
  }

  editar(roteiroContabil: RoteiroContabil){
    this.clearForm();
    this.formEventoContabil.controls['id'].setValue(roteiroContabil.id);
    this.formEventoContabil.controls['dataAtivacao'].setValue(DataUtils.stringToDate(roteiroContabil.dataAtivacao));
    this.formEventoContabil.controls['dataAtivacao'].setValidators(null);
    this.formEventoContabil.controls['dataAtivacao'].updateValueAndValidity();
    this.formEventoContabil.controls['dataDesativacao'].setValue(roteiroContabil.dataDesativacao ? DataUtils.stringToDate(roteiroContabil.dataDesativacao): null);
    this.formEventoContabil.controls['codigoEventoContabil'].setValue(roteiroContabil.codigoEventoContabil);
    this.formEventoContabil.controls['situacaoLancamento'].setValue(roteiroContabil.situacaoLancamento);
    this.isCadastro = false;
    this.showFormCadastro = true;
  }

  getRoteiroFromFrom(): RoteiroContabil{
    let roteiroContabil = this.formEventoContabil.getRawValue();
    roteiroContabil.dataAtivacao = this.datePipe.transform(roteiroContabil.dataAtivacao, 'dd/MM/yyyy').toString()
    if (roteiroContabil.dataDesativacao){
      roteiroContabil.dataDesativacao = this.datePipe.transform(roteiroContabil.dataDesativacao, 'dd/MM/yyyy').toString()
    }
    return roteiroContabil;
  }

  salvar(){
      this.roteiroContabilService.postRoteiroContabil(this.getRoteiroFromFrom())
      .subscribe(response =>{
        if (response) {
          this.snackbarService.open('Salvo com sucesso', 'success');
          this.getRoteirosAtualizados();
          this.showFormCadastro = false;
      }}, (error) => {
        this.snackbarService.open(error, 'error');
      });
  }

  atualizar(){
    let roteiroContabil = this.formEventoContabil.getRawValue();
      this.roteiroContabilService.putRoteiroContabil(this.getRoteiroFromFrom())
      .subscribe(response =>{
        if (response) {
          this.snackbarService.open('Salvo com sucesso', 'success');
          this.getRoteirosAtualizados();
          this.showFormCadastro = false;
      }}, (error) => {
        this.snackbarService.open(error, 'error');
      });
  }

  duplicar(){
    if(!this.formEventoContabil.controls['dataDesativacao'].value){
      this.snackbarService.open('Ao duplicar Data de desativação nao pode ser vazia!', 'error');
      return;
    }
      this.roteiroContabilService.postDuplicarRoteiroContabil(this.getRoteiroFromFrom())
      .subscribe(response =>{
        if (response) {
          this.snackbarService.open('Salvo com sucesso', 'success');
          this.getRoteirosAtualizados();
          this.showFormCadastro = false;
      }}, (error) => {
        this.snackbarService.open(error, 'error');
      });
  }

  cancelar(){
    this.clearForm();
    this.showFormCadastro = false;
  }

  alterarEvento(showCadstro: boolean) {
    this.clearForm();
    this.showFormCadastro = showCadstro;
    this.isCadastro = true;
  }

  getRoteirosAtualizados(){
    this.roteiroContabilService
    .getRoteirosContabeis(this.data.id)
    .pipe(
      tap((roteiro) => {
      this.data.roteiro = roteiro;
      }),
    )
    .subscribe();
  }

  getDataDisponivel(): Date{
    let data = new Date();
    data.setDate(data.getDate() + 1);
    return data;
  }

  clearForm(){
    this.formEventoContabil.controls['id'].patchValue('');
    this.formEventoContabil.controls['dataAtivacao'].patchValue('');
    this.formEventoContabil.controls['dataAtivacao'].setValidators([Validators.required]);
    this.formEventoContabil.controls['dataAtivacao'].updateValueAndValidity();
    this.formEventoContabil.controls['dataDesativacao'].patchValue(null);
    this.formEventoContabil.controls['codigoEventoContabil'].patchValue('');
    this.formEventoContabil.controls['situacaoLancamento'].patchValue('');
  }

}
