import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RoboSettingsDialogComponent } from './robo-settings-dialog.component';

describe('RoboSettingsDialogComponent', () => {
  let component: RoboSettingsDialogComponent;
  let fixture: ComponentFixture<RoboSettingsDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RoboSettingsDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RoboSettingsDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
