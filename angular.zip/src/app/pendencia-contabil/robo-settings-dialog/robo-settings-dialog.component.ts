import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { take } from 'rxjs/operators';
import { ParametroSistema, ParametroTipoDadoEnum } from './robo-settings-dialog.model';
import { RoboSettingsDialogService } from './robo-settings-dialog.service';

@Component({
  selector: 'app-robo-settings-dialog',
  templateUrl: './robo-settings-dialog.component.html',
  styleUrls: ['./robo-settings-dialog.component.scss']
})
export class RoboSettingsDialogComponent implements OnInit {
  arraySettings: ParametroSistema[] = [];
  parametroTipoDadoEnum = ParametroTipoDadoEnum;

  constructor(
    private fb: FormBuilder,
    private roboSettingsService: RoboSettingsDialogService,
    private dialogRef: MatDialogRef<RoboSettingsDialogComponent>
  ) { 
  }

  readonly formSettings = this.fb.group({});

  ngOnInit(): void {
    this.roboSettingsService.getSettings()
      .pipe(take(1))
      .subscribe(arraySettings => {
        arraySettings.forEach(setting => {
          this.formSettings.addControl(setting.nomeParametroSistema, new FormControl(this.transformDataType(setting.descricaoConteudoParametro, setting.idTipoDadoParametro)));
        });
        this.arraySettings = arraySettings;
        
      });
  }

  private transformDataType(dado: any, idTipoDadoParametro: number) {
    let transform = {
      [ParametroTipoDadoEnum.BOOLEANO]: (data) => data === 'true',
      [ParametroTipoDadoEnum.NUMERICO]: (data) => Number(data),
      [ParametroTipoDadoEnum.TEXTO]: (data) => String(data),
    }
    return transform[idTipoDadoParametro](dado);
  }

  onSubmit() {
    Object.keys(this.formSettings.value).forEach(keyForm => {
      this.arraySettings.forEach(setting => {
        if(setting.nomeParametroSistema == keyForm) {
          setting.descricaoConteudoParametro = String(this.formSettings.value[keyForm]);
        }

      })
    })
    this.roboSettingsService.setSettings(this.arraySettings)
      .pipe(take(1))
      .subscribe(() => {
        this.dialogRef.close(true);
      });
  }

  
}
