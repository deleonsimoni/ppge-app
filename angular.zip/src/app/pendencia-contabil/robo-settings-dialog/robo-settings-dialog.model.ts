export interface ParametroSistema {
    idParametro: number;
	idTipoDadoParametro: number;
	nomeParametroSistema: string;
	descricaoParametroSistema: string;
	descricaoConteudoParametro: string;
}

export enum ParametroTipoDadoEnum {
    NUMERICO = 2,
    TEXTO = 3,
    DATA = 4,
    HORA = 5,
    BOOLEANO = 6,
}