import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { SnackbarService } from "@core/services";
import { environment } from "@env/environment";
import { Observable } from "rxjs";
import { catchError, map } from "rxjs/operators";
import { ParametroSistema } from "./robo-settings-dialog.model";

@Injectable({
  providedIn: 'root',
})
export class RoboSettingsDialogService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_CONSULTA_SETTINGS = `${this.URL_PIX_GESTAO}/resolve-pendencia/consulta-configuracao`;
  private readonly URL_ALTERAR_SETTINGS = `${this.URL_PIX_GESTAO}/resolve-pendencia/configuracao`;

  constructor(
    private http: HttpClient,
    private snackbarService: SnackbarService
  ) { }

  getSettings(): Observable<ParametroSistema[]> {
    return this.http.get<ParametroSistema[]>(this.URL_CONSULTA_SETTINGS)
      .pipe(
        catchError((error) => {
          this.snackbarService.open("Ocorreu um erro no sistema!", 'error');
          throw error;
        })
      );
  }

  setSettings(body) {
    return this.http.post(this.URL_ALTERAR_SETTINGS, body )
      .pipe(
        map((response) => {
            this.snackbarService.open("Parâmetros alterados com sucesso.",'success');
        }),
        catchError((error) => {
          this.snackbarService.open("Ocorreu um erro no sistema!", 'error');
          throw error;
        })
      );
  }

}