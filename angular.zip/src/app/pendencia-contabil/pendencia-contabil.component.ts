import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import { formatDate } from '@angular/common';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { PorServicoDialogComponent } from '@app/consulta/por-servico/por-servico-dialog.component';
import { LoginService } from '@store/login';
import * as moment from 'moment';
import { error } from 'protractor';
import { BehaviorSubject, interval, Subscription } from 'rxjs';
import { mergeMap, take } from 'rxjs/operators';
import { InfoContabilDialogComponent } from './info-contabil-dialog/info-contabil-dialog.component';
import { PendenciaContabilFiltro, PendenciaResponse, situacaoPendenciaEnum, StatusRobo } from './pendencia-contabil.model';
import { PendenciaContabilService } from './pendencia-contabil.service';
import { RoboSettingsDialogComponent } from './robo-settings-dialog/robo-settings-dialog.component';

@Component({
  selector: 'app-pendencia-contabil',
  templateUrl: './pendencia-contabil.component.html',
  styleUrls: ['./pendencia-contabil.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition(
        'expanded <=> collapsed',
        animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)'),
      ),
    ]),
  ],
})
export class PendenciaContabilComponent implements OnInit, OnDestroy {

  @ViewChild('countDownTimer', { static: false }) countDownTimer: ElementRef;

  statusRobo: StatusRobo;
  isExecuntingRobo: boolean = false;

  header = [
    'idPendencia',
    'endToEnd',
    'ispbOrigem',
    'valor',
    'quantidadeTentativa',
    'situacao',
    'data',
    'hora',
    'acao'
  ];
  footer = ['total'];
  textButtonResolve = "";

  objectkeys = Object.keys;
  situacaoPendenciaEnum = situacaoPendenciaEnum;
  tipoOrdenacao = true;
  campoOrdenacao = '';
  paginaAtual = 1;
  checkAll = false;
  showButtonResolvePorCamt = false;
  tamanhoPagina: number = 15;
  date = new Date();
  readonly data$ = new BehaviorSubject<PendenciaResponse>(null);

  constructor(
    public dialog: MatDialog,
    private fb: FormBuilder,
    private pendenciaContabilService: PendenciaContabilService,
    public loginService: LoginService,
  ) { }
  ngOnDestroy(): void {
    clearInterval(this.idIterval);
  }

  ngOnInit(): void {
    this.getStatusRobo();
  }
  
  idIterval
  startTimer(duration: number) {
    var timer = duration, 
        hour: string | number, 
        minutes: string | number, 
        seconds: string | number;
        
      this.idIterval = setInterval(() => {
        
        hour = parseInt(String(timer / 60 / 60), 10);
        minutes = parseInt(String((timer / 60) % 60), 10);
        seconds = parseInt(String(timer % 60), 10);

        hour = hour < 10 ? "0" + hour : hour;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        this.countDownTimer.nativeElement.innerText = hour + ":" + minutes + ":" + seconds;

        if (--timer < 0) {
            clearInterval(this.idIterval);
            this.isExecuntingRobo = true;
            this.getStatusExecucaoRobo();
        }
    }, 1000);
  }


  readonly form = this.fb.group({
    idMensagem: [null],
    situacaoPendencia: ['', Validators.nullValidator],
    data: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
    horaInicio: ['00:00:00', [Validators.required, Validators.minLength(8)]],
    horaFim: ['23:59:59', [Validators.required, Validators.minLength(8)]],
  });
  
  get horaInicio() {
    return this.form.get('horaInicio');
  }

  get horaFim() {
    return this.form.get('horaFim');
  }

  public consultaOrdenada(campo: string) {
    this.tipoOrdenacao = !this.tipoOrdenacao;
    this.campoOrdenacao = campo;

    this.getMensagens();
  }

  public onPagination(event: PageEvent) {
    this.paginaAtual = event.pageIndex + 1;
    this.tamanhoPagina = event.pageSize;

    this.getMensagens();
  }

  public onSubmit() {

    this.campoOrdenacao = 'data';
    this.paginaAtual = 1;
    this.tamanhoPagina = 15;
    const indexSelecao = this.header.indexOf('selecao');
    if(this.form.value.situacaoPendencia == "5" && indexSelecao == -1)
      this.header.push('selecao')
    else if(this.form.value.situacaoPendencia != "5" && indexSelecao > -1)
      this.header.splice(indexSelecao, 1);
    this.getMensagens();
  }

  getStatusRobo() {
    this.pendenciaContabilService.getStatusRobo().pipe(take(1)).subscribe(
      (data: StatusRobo) => {
        this.statusRobo = data;
        if(data.ativo) {
          this.startTimer(data.tempo)
        }
      },
      (err) => {
        console.log("ERROR: ", err);
        this.statusRobo = null;
        
      }
    );
  }

  
  subscribedStatusExecucao: Subscription;
  getStatusExecucaoRobo() {
    this.pendenciaContabilService.getStatusExecucaoRobo().pipe(take(1)).subscribe(
      (data: StatusRobo) => {
        this.isExecuntingRobo = data.executando;
        if(data.executando) {

          this.subscribedStatusExecucao = interval(500)
            .pipe(mergeMap(() => this.pendenciaContabilService.getStatusExecucaoRobo()))
            .subscribe((dataFromInterval: StatusRobo) => {
              if(!dataFromInterval.executando) {
                this.isExecuntingRobo = dataFromInterval.executando;

                this.getStatusRobo();
                this.subscribedStatusExecucao.unsubscribe();
              }
            });
        } else {
          this.getStatusRobo();
        }
      }
    );
  }

  getMensagens() {
    const pendenciaFiltro= <PendenciaContabilFiltro> {
      idMensagem: this.form.value.idMensagem,
      statusPendencia: this.form.value.situacaoPendencia,
      data: formatDate(this.form.value.data, "dd/MM/yyyy", "pt-BR"),
      horaInicio: this.horaInicio.value,
      horaFim: this.horaFim.value,
    }
    
    this.pendenciaContabilService
      .getMensagens(
        pendenciaFiltro,
        this.campoOrdenacao,
        this.tipoOrdenacao ? 'DESC' : 'ASC',
        this.paginaAtual,
        this.tamanhoPagina,
      ).pipe(take(1))
      .subscribe((mensagens) => {
        this.checkAll = false;
        this.data$.next(mensagens)
        this.showButtonResolvePorCamt = mensagens != null && this.form.value.situacaoPendencia == "5";
        this.textButtonResolve = "Resolver selecionados por CAMT";
      });

  }

  resolverPorCamt(endToEnd: string) {
    this.pendenciaContabilService
          .solicitarCamt60(endToEnd)
          .pipe(take(1))
          .subscribe();
  }
  
  resolvePorCamtEmLote() {
    let listEndToEnd = [];
    this.data$.pipe(take(1)).subscribe(e => {
      e.dados.forEach(fe =>{
        const newItem = {idEndToEnd: fe.endToEnd, situacao: Number(fe.situacao == "5"), solicitarBacen: false}
        if(fe.checked && !listEndToEnd.find(element => element.idEndToEnd == fe.endToEnd)) {
          listEndToEnd.push(newItem);
        }
      })
      this.pendenciaContabilService.resolvePorCamtEmLote(listEndToEnd).pipe(take(1)).subscribe();
    })
  }




  onOpenDialogInfoMsg(endToEnd: string, dataMensagem: string) {
    const data: string = moment(dataMensagem).format('DD/MM/YYYY');
    this.pendenciaContabilService
          .getInfoMsg(endToEnd, data)
          .pipe(take(1))
          .subscribe(detalhe => {
            this.dialog.open(PorServicoDialogComponent, {
              data: { detalhe, tipo: detalhe.tipoMensagem }
            })
          },erro =>{
            this.dialog.open(PorServicoDialogComponent, {
             data: null
            })
          })

  }

  onOpenDialogInfoContabil(endToEnd: string) {
    
    this.pendenciaContabilService
          .getInfoContabil(endToEnd)
          .pipe(take(1))
          .subscribe(data => {
            this.dialog.open(InfoContabilDialogComponent, {
              data
            })
          })

  }

  onOpenDialogSettings() {
    let dialogRef = this.dialog.open(RoboSettingsDialogComponent);
    dialogRef.afterClosed().subscribe(isRefresh => {
      if(isRefresh) {
        clearInterval(this.idIterval);
        this.getStatusRobo();
      }
    });
  }
 
  toggleSelect(event, checkTodos = false, index = null) {
    if(checkTodos) this.checkAll = event.target.checked;
    
    this.data$.pipe(take(1)).subscribe(e => {
      if(checkTodos) e.dados.forEach(fe => fe.checked = event.target.checked);
      else e.dados[index].checked = event.target.checked;
    });
  }

}
