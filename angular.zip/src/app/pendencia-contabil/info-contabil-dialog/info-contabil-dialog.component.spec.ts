import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InfoContabilDialogComponent } from './info-contabil-dialog.component';

describe('InfoContabilDialogComponent', () => {
  let component: InfoContabilDialogComponent;
  let fixture: ComponentFixture<InfoContabilDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InfoContabilDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InfoContabilDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
