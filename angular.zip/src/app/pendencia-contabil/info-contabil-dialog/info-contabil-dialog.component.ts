import { ChangeDetectionStrategy, Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PendenciaInfoContabil, SituacaoProcessamentoLancamentoEnum } from '../pendencia-contabil.model';

@Component({
  selector: 'app-info-contabil-dialog',
  templateUrl: './info-contabil-dialog.component.html',
  styleUrls: ['./info-contabil-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class InfoContabilDialogComponent {
  readonly situacaoProcessamentoLancamentoEnum = SituacaoProcessamentoLancamentoEnum;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: PendenciaInfoContabil,
  ) { }

}
