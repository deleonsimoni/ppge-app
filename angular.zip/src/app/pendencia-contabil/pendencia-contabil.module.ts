import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PendenciaContabilComponent } from './pendencia-contabil.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialogModule } from '@angular/material/dialog';
import { MatListModule } from '@angular/material/list';
import { MatGridListModule } from '@angular/material/grid-list';
import { NgxMaskModule } from 'ngx-mask';
import { MatButtonModule } from '@angular/material/button';
import { HighlightModule } from 'ngx-highlightjs';
import { NgxCurrencyModule } from 'ngx-currency';
import { PendenciaContabilRoutingModule } from './pendencia-contabil-routing.module';
import { RoboSettingsDialogComponent } from './robo-settings-dialog/robo-settings-dialog.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { InfoContabilDialogComponent } from './info-contabil-dialog/info-contabil-dialog.component';



@NgModule({
  declarations: [
    PendenciaContabilComponent,
    RoboSettingsDialogComponent,
    InfoContabilDialogComponent
  ],
  imports: [
    CommonModule,
    PendenciaContabilRoutingModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatSlideToggleModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatTableModule,
    MatTooltipModule,
    MatDialogModule,
    MatListModule,
    MatGridListModule,
    NgxMaskModule.forRoot(),
    HighlightModule,
    NgxCurrencyModule,
    MatButtonModule,
  ]
})
export class PendenciaContabilModule { }
