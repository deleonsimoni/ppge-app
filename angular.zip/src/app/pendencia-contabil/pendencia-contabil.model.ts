export interface PendenciaResponse {
    dados: Pendencia[];
    pagina: number;
    paginas: number;
    tamanhoPagina: number;
    totalRegistros: number;
    
}

export interface Pendencia {
    idPendencia: string; 
    endToEnd: string; 
    ispbOrigem: string;
    valor: number;
    quantidadeTentativa: string; 
    situacao: string;
    data: string; 
    hora: string;
    checked?: boolean;
}

export interface PendenciaContabilFiltro {
    idMensagem: string;
    statusPendencia: string;
    data: string;
    horaInicio: string;
    horaFim: string;
}

export interface PendenciaInfoContabil {
    idLancamento: string;
	tipoLancamento: string;
	statusLancamento: string;
	valorLancamento: number;
	endToEnd: string;
	dataContabil: string;
	dataTranscao: string;
	dataInclusao: string;
}

export const situacaoPendenciaEnum = {
    1: "Pendente", 
    2: "Em processamento", 
    3: "Resolvido", 
    4: "Rejeitado", 
    5: "Falha",
    6: "Camt 60 Pendente",
}

export enum SituacaoProcessamentoLancamentoEnum {
    "N" = "Não Processado",
    "P" = "Processado",
    "S" = "Sem parâmetros registrados",
    "M" = "Outro motivo",
}

export interface StatusRobo {
    ativo: boolean;
    executando: boolean;
    horario: string;
    tempo: number;
}
