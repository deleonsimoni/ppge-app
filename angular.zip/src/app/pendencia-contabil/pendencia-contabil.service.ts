import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { SnackbarService } from '@core/services';
import { environment } from '@env/environment';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { PendenciaContabilFiltro, PendenciaInfoContabil, PendenciaResponse, StatusRobo } from './pendencia-contabil.model';

@Injectable({
    providedIn: 'root',
  })
export class PendenciaContabilService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_CONSULTA_PENDENCIA = `${this.URL_PIX_GESTAO}/resolve-pendencia/consulta`;
  private readonly URL_PENDENCIA_CONTABIL = `${this.URL_PIX_GESTAO}/resolve-pendencia/consulta-contabil`;

  
  private readonly URL_ROTINA = `${this.URL_PIX_GESTAO}/resolve-pendencia`;


  constructor(
    private http: HttpClient, 
    private snackbarService: SnackbarService
  ) {}

  getStatusRobo() {
    return this.http.get<StatusRobo>(`${this.URL_ROTINA}/consultar-status`);
  }

  getStatusExecucaoRobo() {
    return this.http.get<StatusRobo>(`${this.URL_ROTINA}/consultar-status-execucao`);
  }

  getMensagens(
    pendenciaFiltro: PendenciaContabilFiltro,
    campoOrdenado: string,
    tipoOrdenacao: string,
    page: number = 1,
    tamanhoPagina: number = 15,
  ): Observable<PendenciaResponse> {
    let params = new HttpParams();
    if (campoOrdenado && tipoOrdenacao) {
      params = params.set('campoOrdenado', campoOrdenado);
      params = params.set('tipoOrdenacao', tipoOrdenacao);
    }

    if (pendenciaFiltro.data) {
      params = params.set('data', pendenciaFiltro.data);
    }

    if (pendenciaFiltro.horaInicio) {
      params = params.set('horaInicio', pendenciaFiltro.horaInicio);
    }

    if (pendenciaFiltro.horaFim) {
      params = params.set('horaFim', pendenciaFiltro.horaFim);
    }

    if (pendenciaFiltro.idMensagem) {
      params = params.set('idMensagem', pendenciaFiltro.idMensagem);
    }

    if (pendenciaFiltro.statusPendencia) {
      params = params.set('statusPendencia', pendenciaFiltro.statusPendencia);
    }

    
    params = params
      .set('pagina', page.toString())
      .set('tamanhoPagina', tamanhoPagina.toString());

    return this.http.get<PendenciaResponse>(this.URL_CONSULTA_PENDENCIA, { params })
      .pipe(
        map((response) => {
          if (response.totalRegistros <= 0) {
            this.snackbarService.open("Nenhum Registro Encontrado.",'error');
          } else {
            return response;
          }
        }),
        catchError((error) => {
          let errorMsg: string;
          errorMsg = this.getServerErrorMessage(error);
          this.snackbarService.open(errorMsg,'error');
          throw errorMsg;
        })
      );

  }

  getInfoMsg(endToEnd: string, dataMensagem: string): Observable<any> {
    let params = new HttpParams().set('dataMensagem', dataMensagem);

    return this.http.get<any>(`${this.URL_CONSULTA_PENDENCIA}/${endToEnd}/detalhe`, {params})
      .pipe(
        catchError(this.getError)
    );
  }

  getInfoContabil(endToEnd: string): Observable<PendenciaInfoContabil> {
    return this.http.get<PendenciaInfoContabil>(`${this.URL_PENDENCIA_CONTABIL}/${endToEnd}/detalhe`)
      .pipe(
        catchError(this.getError)
    );
  }

  solicitarCamt60(endToEnd: string) {
    return this.http.get(`${this.URL_PENDENCIA_CONTABIL}/${endToEnd}/resolver-por-camt`)
      .pipe(
        map(() => {
          this.snackbarService.open('CAMT60 enviada com sucesso!', 'success');
        }),
        catchError(this.getError)
      )
  }

  resolvePorCamtEmLote(listEndToEnd){
    if(listEndToEnd.length) {
      return this.http.post(`${this.URL_PENDENCIA_CONTABIL}/resolver-por-camt-lote`, listEndToEnd).pipe(
        map((response) => {
            this.snackbarService.open("Enviado com sucesso.",'success');
        }),
        catchError((error) => {
          let errorMsg: string = this.getServerErrorMessage(error);
          this.snackbarService.open(errorMsg,'error');
          throw errorMsg;
        })
      )
    } else {
      this.snackbarService.open('Nenhuma pendência selecionada.','error');
    }
  }

  private getError = (err: any) => {
    let errorMsg: string = this.getServerErrorMessage(err);
    this.snackbarService.open(errorMsg,'error');
    throw errorMsg;
  }

  private getServerErrorMessage(error: HttpErrorResponse): string {
    const statusErrors = {
      404: `Not Found.`,
      403: `Access Denied.`,
      500: `Internal Server Error.`,
    }
    return statusErrors[error.status] ? statusErrors[error.status] : `Unknown Server Error.`;
  }
}