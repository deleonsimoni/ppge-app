import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PendenciaContabilComponent } from './pendencia-contabil.component';

describe('PendenciaContabilComponent', () => {
  let component: PendenciaContabilComponent;
  let fixture: ComponentFixture<PendenciaContabilComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PendenciaContabilComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PendenciaContabilComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
