import { HttpErrorResponse } from "@angular/common/http";


export function getServerErrorMessage(error: HttpErrorResponse): string {
  const statusErrors = {
    404: `Not Found.`,
    403: `Access Denied.`,
    500: `Internal Server Error.`,
  }
  return statusErrors[error.status] ? statusErrors[error.status] : `Unknown Server Error.`;
}