import { ChangeDetectionStrategy, Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-xml-mensagem-dialog',
  templateUrl: './xml-mensagem-dialog.component.html',
  styleUrls: ['./xml-mensagem-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class XmlMensagemDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<XmlMensagemDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { xml: string; tipo: string },
  ) {}
}
