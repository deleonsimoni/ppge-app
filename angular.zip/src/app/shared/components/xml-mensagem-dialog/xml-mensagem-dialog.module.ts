import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule } from '@angular/material/dialog';
import { BrowserModule } from '@angular/platform-browser';
import { PrettyXMLPipeModule } from '@core/pipes/pretty-xml/pretty-xml.module';
import { HighlightModule } from 'ngx-highlightjs';
import { XmlMensagemDialogComponent } from './xml-mensagem-dialog.component';
import { NgxCurrencyModule } from 'ngx-currency';



@NgModule({
  declarations: [XmlMensagemDialogComponent],
  imports: [
    CommonModule,
    MatDialogModule,
    PrettyXMLPipeModule,
    HighlightModule,
    NgxCurrencyModule,
  ],
  exports: [XmlMensagemDialogComponent]
})
export class XmlMensagemDialogModule { }
