import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SnackbarService } from '@core/services';
import { ConsultaDetalhadaCargaDTO, FiltroConsultaDetalhadaCarga } from '../carga-bacen.model';
import { CargaBacenService } from '../carga-bacen.service';

@Component({
  selector: 'app-relatorio-detalhado-dialog',
  templateUrl: './relatorio-detalhado-dialog.component.html',
  styleUrls: ['./relatorio-detalhado-dialog.component.scss']
})
export class RelatorioDetalhadoDialogComponent {
  paginaAtual = 1;
  tamanhoPagina = 10;
  campoOrdenacao = 'data';
  tipoOrdenacao = true;

  header = [
	 "operacao",
	 "idEndToEnd",
	 "tipo",
   'data',
   'hora',
	 "valorLancamento",
  ];

  constructor(
    public dialogRef: MatDialogRef<RelatorioDetalhadoDialogComponent>,
    private cargaBacenService: CargaBacenService,
    private snackbarService: SnackbarService,
    @Inject(MAT_DIALOG_DATA) public data,
  ) {}

  onPagination(event) {
    this.paginaAtual = event.pageIndex + 1;
    this.tamanhoPagina = event.pageSize;
    this.buscarDados();
  }

  consultaOrdenada(campo: string) {
    this.tipoOrdenacao = !this.tipoOrdenacao;
    this.campoOrdenacao = campo;
    this.buscarDados();
  }

  buscarDados() {
    this.cargaBacenService.getDetailedReports(<FiltroConsultaDetalhadaCarga>{
      data: this.data.dataSelecionada,
      pagina: this.paginaAtual,
      tamanhoPagina: this.tamanhoPagina,
      campoOrdenado: this.campoOrdenacao,
      tipoOrdenacao: this.tipoOrdenacao ? 'DESC' : 'ASC'
    }).subscribe((detalhe: ConsultaDetalhadaCargaDTO) => {
      if (detalhe.totalRegistros > 0) {
        this.data = { 
          ...this.data,
          dados: detalhe.dados, 
          totalRegistros: detalhe.totalRegistros,
          tamanhoPagina: detalhe.tamanhoPagina,
          pagina: detalhe.pagina
        }
        
      } else {
        this.snackbarService.open('Ocorreu um erro e não foi possível paginar o relatório.', 'error');
      }

    });
  }

  solicitarDownloadCsv(){
    this.cargaBacenService.getDetailedReportsCSV(this.data.dataSelecionada).subscribe(
      blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Relatorio de Lançamentos Efetuados ' + this.data.dataSelecionada + '.csv';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      });
  }

}
