import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CargaBacenComponent } from './carga-bacen.component';
import { CargaBacenRoutingModule } from './carga-bacen-routing.module';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatDialogModule } from '@angular/material/dialog';
import { MatListModule } from '@angular/material/list';
import { MatGridListModule } from '@angular/material/grid-list';
import { NgxMaskModule } from 'ngx-mask';
import { HighlightModule } from 'ngx-highlightjs';
import { NgxCurrencyModule } from 'ngx-currency';
import { MatButtonModule } from '@angular/material/button';
import { RelatorioDialogComponent } from './relatorio-dialog/relatorio-dialog.component';
import { ConfirmationDialogModule } from '@app/shared/components/confirmation-dialog/confirmation-dialog.module';
import { TipoMensagemContabilModule } from '@core/pipes/tipo-mensagem-contabill/tipo-mensagem-contabill.module';
import { RelatorioDetalhadoDialogComponent } from './relatorio-detalhado-dialog/relatorio-detalhado-dialog.component';
import { HistoricoCargaBacenDialogComponent } from './historico/historico-carga-bacen-dialog.component';
import { TipoStepPipeModule } from '@core/pipes/tipo-step/tipo-step-pipe.module';



@NgModule({
  declarations: [CargaBacenComponent, RelatorioDialogComponent, RelatorioDetalhadoDialogComponent, HistoricoCargaBacenDialogComponent],
  imports: [
    CommonModule,
    CargaBacenRoutingModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatTableModule,
    MatTooltipModule,
    MatDialogModule,
    MatListModule,
    MatGridListModule,
    NgxMaskModule.forRoot(),
    HighlightModule,
    NgxCurrencyModule,
    MatButtonModule,
    TipoMensagemContabilModule,
    ConfirmationDialogModule,
    TipoStepPipeModule
  ]
})
export class CargaBacenModule { }
