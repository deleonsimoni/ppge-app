export interface RelatorioCarga {
    tipo: string;
    operacao: string;
    quantidade: string;
    valor: string;
  }

export interface ConsultaDetalhadaCargaDTO {
	dados: RelatorioDetalhadoCargaBacenDTO[] | null;
	pagina: number | null;
	paginas: number | null;
	tamanhoPagina: number | null;
	totalRegistros: number | null;
}

export interface RelatorioDetalhadoCargaBacenDTO {
	operacao: string | null;
	idEndToEnd: string | null;
	tipo: number | null;
	tsTransacao: Date | null; 
	valorLancamento: number | null;	
}

export interface FiltroConsultaDetalhadaCarga {
  data: string;
  pagina: number; 
  tamanhoPagina: number;
  tipoOrdenacao: string;
  campoOrdenado: string;
}

export interface HistoricoSolucaoDiferenca {
  numeroTentativa: number;
	dataMovimentoContabil: Date;
	dataInicioExecucao: Date;
	dataFimExecucao: Date;
	ultimaTarefaExecucao: string;
  situacaoUltimaExecucao: string;
	descricaoErroExecucao: string;
}





  
	








