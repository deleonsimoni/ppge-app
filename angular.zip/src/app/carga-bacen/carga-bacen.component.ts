import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmationDialogComponent } from '@app/shared/components/confirmation-dialog/confirmation-dialog.component';
import { SnackbarService } from '@core/services';
import { LoginService } from '@store/login';
import * as moment from 'moment';
import { interval, Subscription } from 'rxjs';
import { mergeMap, take } from 'rxjs/operators';
import { ConsultaDetalhadaCargaDTO, FiltroConsultaDetalhadaCarga } from './carga-bacen.model';
import { CargaBacenService } from './carga-bacen.service';
import { HistoricoCargaBacenDialogComponent } from './historico/historico-carga-bacen-dialog.component';
import { RelatorioDetalhadoDialogComponent } from './relatorio-detalhado-dialog/relatorio-detalhado-dialog.component';
import { RelatorioDialogComponent } from './relatorio-dialog/relatorio-dialog.component';

@Component({
  selector: 'app-carga-bacen',
  templateUrl: './carga-bacen.component.html',
  styleUrls: ['./carga-bacen.component.scss']
})
export class CargaBacenComponent implements OnInit {
  readonly date = new Date(new Date().setDate(new Date().getDate() - 1));

  private readonly NO_DATA_FOR_OPERATION = 'Dados inexistentes para iniciar a operação'

  stringTranslate = {
    solicitacaoCamt60AndCamt052Step: "SOLICITAÇÃO CAMT60/CAMT52",
    downloadFileStep: "DOWNLOAD DO ARQUIVO",
    uncompressStep: "UNZIP DO ARQUIVO",
    leituraArquivoRelacaoLancamentoStep: "LEITURA DO ARQUIVO",
    atualizarSaldoStep: "ATUALIZAÇÃO SALDO",
    deletedFileStep: "EXCLUSÃO DO ARQUIVO",
    reprocessarStep:"EXECUÇÃO REPROCESSAR",
    COMPLETED: "COMPLETO",
    STARTING: "INICIANDO",
    STARTED: "INICIADO",
    STOPPING: "PARANDO",
    STOPPED: "PARADO",
    FAILED: "FALHA",
    ABANDONED: "ABANDONADO",
    UNKNOWN: "DESCONHECIDO",
    EXECUTING: "EM EXECUÇÃO",
    NOOP: "SEM OPERAÇÃO"
  }

  headerCarga = [
    "idCarga",
    "dataInicioCarga",
    "dataFimCarga",
    "dataSolicitacaoCarga",
    "tentativaCarga",
    "statusCarga",
  ]

  headerStep = [
    "idStep",
    "nomeTarefaStep",
    "dataInicioStep",
    "dataFimStep",
    "totalLidoStep",
    "totalFiltradoStep",
    "totalEscritoStep",
    "statusStep",
  ]

  dataSource: any;

  constructor(
    private fb: FormBuilder,
    private cargaBacenService: CargaBacenService,
    private snackbarService: SnackbarService,
    public dialog: MatDialog,
    public loginService: LoginService
  ) { }

  readonly form = this.fb.group({
    dataSolicitacao: [null, [Validators.required]],
    idTentativa: [1, [Validators.pattern("^[0-9]*$")]],
  });

  ngOnInit(): void {
    this.getCarga();
  }

  textTooltipCarga() {
    const { id, exitStatus } = this.dataSource;

    return `
ID: ${id} 
Nome da Tarefa: CARGA BACEN

Em Execução: ${exitStatus.running ? 'SIM' : 'NÃO'}
Código de Saída: ${this.stringTranslate[exitStatus.exitCode] ? this.stringTranslate[exitStatus.exitCode] : exitStatus.exitCode}
Descrição: ${exitStatus.exitDescription}
    `;
  }

  textTooltipStep(text) {
    const { id, startTime, endTime, exitStatus, stepName } = text;

    let duracao: any;
    if (!endTime)
      duracao = 'Em Andamento';
    else {
      const msToMinute = 60 * 1000;
      duracao = Number(moment(endTime).diff(moment(startTime)) / msToMinute).toFixed(2);
    }

    return `
ID: ${id} 
Nome da Tarefa: ${this.stringTranslate[stepName] ? this.stringTranslate[stepName] : stepName}

Em Execução: ${exitStatus.running ? 'SIM' : 'NÃO'}
Duração (em minutos): ${duracao}
Código de Saída: ${this.stringTranslate[exitStatus.exitCode] ? this.stringTranslate[exitStatus.exitCode] : exitStatus.exitCode}
Descrição: ${exitStatus.exitDescription}
    `;
  }

  subscribedGetCarga: Subscription;
  getCarga() {
    this.cargaBacenService.getCarga().subscribe(data => {
      this.dataSource = data;
      if (this.dataSource.exitStatus.running) {
        const msToOneMinute = 1 * 60 * 1000;
        this.subscribedGetCarga = interval(msToOneMinute)
          .pipe(mergeMap(() => this.cargaBacenService.getCarga()))
          .subscribe(dataFromInterval => {
            this.dataSource = dataFromInterval;
            if (!this.dataSource.exitStatus.running) {
              this.subscribedGetCarga.unsubscribe()
            }
          });

      }
    });

  }

  verificarLimpezaExecucao() {
    if (this.dataSource && this.dataSource.exitStatus) {
      if (this.dataSource.exitStatus.exitCode === 'UNKNOWN') {
        this.limparExecucao();
      } else {
        const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
          width: '600px',
          data: {
            title: "Atenção!",
            text: "Tem certeza que deseja continuar?"
          }
        })

        dialogRef.afterClosed().subscribe(flagAccept => {
          if (flagAccept) {
            this.limparExecucao();
          }
        })
      }
    } else {
      this.snackbarService.open(this.NO_DATA_FOR_OPERATION, 'error');
    }

  }

  private limparExecucao() {
    this.cargaBacenService
      .limparExecucao()
      .pipe(take(1))
      .subscribe()
  }

  iniciarCarga() {
    if (this.form.valid) {
      const data: string = moment(this.form.value.dataSolicitacao).format('DD-MM-YYYY');
      this.cargaBacenService
        .iniciarCarga(data, this.form.value.idTentativa)
        .pipe(take(1))
        .subscribe(() => {
          this.getCarga();
        });
    } else {
      this.snackbarService.open('Fomulário inválido', 'error');

    }
  }

  verificarReprocessarExecucao(){
    if (this.form.valid) {
      const data: string = moment(this.form.value.dataSolicitacao, 'YYYY-MM-DD').format('DD-MM-YYYY');
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        width: '600px',
        data: {
          title: "Atenção!",
          text: `Deseja realmente reprocessar para a data do movimento ${data.replace(/-/g, "/")}?`
        }
      })

      dialogRef.afterClosed().subscribe(flagAccept => {
        if (flagAccept) {
          this.iniciarReprocessar(data);
        }
      })
    } else {
      this.snackbarService.open('Fomulário inválido', 'error');

    }
  }

  private iniciarReprocessar(data: string) {
    this.cargaBacenService
        .iniciarReprocessar(data)
        .pipe(take(1))
        .subscribe()
  }

  verificarReverterReprocessar () {
    if (this.form.valid) {
      const data: string = moment(this.form.value.dataSolicitacao, 'YYYY-MM-DD').format('DD-MM-YYYY');
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        width: '600px',
        data: {
          title: "Atenção!",
          text: `Deseja realmente reverter o reprocessamento para a data do movimento ${data.replace(/-/g, "/")}?`
        }
      })

      dialogRef.afterClosed().subscribe(flagAccept => {
        if (flagAccept) {
          this.reverterReprocessar(data);
        }
      })
    } else {
      this.snackbarService.open('Fomulário inválido', 'error');

    }
  }
  private reverterReprocessar(data: string) { 
      this.cargaBacenService
        .reverterReprocessar(data)
        .pipe(take(1))
        .subscribe()
  }

  verificarLimpezaTabelas() {
    if (this.dataSource && this.dataSource.exitStatus) {
      if (this.dataSource.exitStatus.exitCode === 'UNKNOWN') {
        this.limparExecucao();
      } else {
        const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
          width: '600px',
          data: {
            title: "Atenção!",
            text: "Tem certeza que deseja continuar?"
          }
        })

        dialogRef.afterClosed().subscribe(flagAccept => {
          if (flagAccept) {
            this.limparTabelas();
          }
        })
      }
    } else {
      this.snackbarService.open(this.NO_DATA_FOR_OPERATION, 'error');
    }

  }

  private limparTabelas() {
    this.cargaBacenService
      .limparTabelas()
      .pipe(take(1))
      .subscribe()
  }

  relatorioDialog(): void {
    if (this.form.valid) {
      const data: string = moment(this.form.value.dataSolicitacao).format('DD/MM/YYYY');
      this.cargaBacenService.getReports(data).pipe().subscribe(
        detalhe => {
          if (detalhe.length > 0) {
            this.dialog.open(RelatorioDialogComponent, {
              data: { detalhe, data },
              maxHeight: '800px',
              width: '800px',
            })
          } else {
            this.snackbarService.open('Relatório sem dados disponíveis para esta data.', 'error');
          }

        }
      )
    } else {
      this.snackbarService.open('Fomulário inválido', 'error');

    }
  }


  relatorioDetalhadoDialog(): void {
    if (this.form.valid) {
      const dataSelecionada: string = moment(this.form.value.dataSolicitacao).format('DD/MM/YYYY');
      this.cargaBacenService.getDetailedReports(<FiltroConsultaDetalhadaCarga>{
        data: dataSelecionada,
        pagina: 1,
        tamanhoPagina: 10,
        campoOrdenado: 'data',
        tipoOrdenacao: 'DESC'
      }).pipe().subscribe(
        (detalhe: ConsultaDetalhadaCargaDTO) => {
          if (detalhe.totalRegistros > 0) {
            this.dialog.open(RelatorioDetalhadoDialogComponent, {
              data: { 
                dados: detalhe.dados, 
                dataSelecionada,
                totalRegistros: detalhe.totalRegistros,
                tamanhoPagina: detalhe.tamanhoPagina,
                pagina: detalhe.pagina
              },
              maxHeight: '800px',
              width: '1100px',
            })
          } else {
            this.snackbarService.open('Relatório sem dados disponíveis para esta data.', 'error');
          }

        }
      )
    } else {
      this.snackbarService.open('Fomulário inválido', 'error');

    }
  }

  historicoDialog(): void {
    if (this.form.valid) {
      const dataSelecionada: string = moment(this.form.value.dataSolicitacao).format('DD/MM/YYYY');
      this.cargaBacenService.getHistorico(dataSelecionada)
      .pipe().subscribe(
        (detalhe) => {
          if (detalhe.length > 0) {
            this.dialog.open(HistoricoCargaBacenDialogComponent, {
              data: { 
                dados: detalhe,
                dataSelecionada
              },
              maxHeight: '800px',
              width: '1200px',
            })
          } else {
            this.snackbarService.open('Histórico sem dados disponíveis para esta data.', 'error');
          }

        }
      )
    
    
    } else {
      this.snackbarService.open('Fomulário inválido', 'error');
    }
  }
}
