import { Component, Inject, OnInit } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";

@Component({
    selector: 'app-relatorio-dialog',
    templateUrl: './relatorio-dialog.component.html',
    styleUrls: ['./relatorio-dialog.component.scss']
  })
export class RelatorioDialogComponent implements OnInit{
    
    readonly displayedColumns: string[] = [
      'tipo', 
      'quantidade', 
      'valor'
    ];
    dataSource = [];
    constructor (
      public dialogRef: MatDialogRef<RelatorioDialogComponent>,
      @Inject(MAT_DIALOG_DATA) public data
    ) {}
  ngOnInit(): void {
    this.dataSource = this.data.detalhe.sort((a, b) => b.tipo - a.tipo);
  }
}