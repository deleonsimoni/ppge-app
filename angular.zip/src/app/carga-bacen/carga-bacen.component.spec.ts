import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CargaBacenComponent } from './carga-bacen.component';

describe('CargaBacenComponent', () => {
  let component: CargaBacenComponent;
  let fixture: ComponentFixture<CargaBacenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CargaBacenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CargaBacenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
