import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { getServerErrorMessage } from "@app/shared/functions-utils";
import { SnackbarService } from "@core/services";
import { environment } from "@env/environment";
import { catchError, map } from "rxjs/operators";
import { ConsultaDetalhadaCargaDTO, FiltroConsultaDetalhadaCarga, HistoricoSolucaoDiferenca, RelatorioCarga } from "./carga-bacen.model";

@Injectable({
  providedIn: 'root',
})
export class CargaBacenService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;

  constructor(
    private http: HttpClient,
    private snackbarService: SnackbarService
  ) { }

  getReports(data: string){
    return this.http.get<RelatorioCarga[]>(`${this.URL_PIX_GESTAO}/carga-bacen/relatorio-carga`, { params: {data}});
  }

  getDetailedReports(filtro: FiltroConsultaDetalhadaCarga){
    return this.http.get<ConsultaDetalhadaCargaDTO>(`${this.URL_PIX_GESTAO}/carga-bacen/relatorio-carga/detalhado`, 
      { params: {
        data: filtro.data, 
        pagina: String(filtro.pagina), 
        tamanhoPagina: String(filtro.tamanhoPagina),
        campoOrdenado: filtro.campoOrdenado,
        tipoOrdenacao: filtro.tipoOrdenacao
      }}
    );
  }

  getHistorico(data: string) {
    return this.http.get<HistoricoSolucaoDiferenca[]>(`${this.URL_PIX_GESTAO}/solucao-diferenca/historico`, { params: {data: data}});
  }
    
  getDetailedReportsCSV(data){
    return this.http.get(`${this.URL_PIX_GESTAO}/carga-bacen/relatorio-carga/detalhado/download/arquivo`, { responseType: 'blob', params: {data}});
  }

  getCarga() {
    return this.http.get(`${this.URL_PIX_GESTAO}/carga-bacen/status-job`)
      .pipe(
        catchError(this.catchMsgError)
      );
  }

  limparExecucao() {
    return this.http.get(`${this.URL_PIX_GESTAO}/carga-bacen/limpar-ultimo-job`)
    .pipe(
      map(() => {
        this.snackbarService.open("Limpeza iniciada com sucesso.", 'success');
      }),
      catchError(this.catchMsgError)
    );

  }

  limparTabelas(){
    return this.http.get(`${this.URL_PIX_GESTAO}/carga-bacen/limpar-tabelas`)
    .pipe(
      map(() => {
        this.snackbarService.open("Reciclar ambiente iniciado com sucesso", 'success');
      }),
      catchError(this.catchMsgError)
    )
  }

  iniciarCarga(dataSolicitacao, tentativa) {
    const params = new HttpParams()
      .set('data-contabil', dataSolicitacao)
      .set('numero-execucao', (typeof tentativa) === "number" ? tentativa : 1);

    return this.http.get(`${this.URL_PIX_GESTAO}/carga-bacen/carregar-transacao-bacen`, {params})
    .pipe(
      map(() => {
        this.snackbarService.open("Carga iniciada com sucesso.", 'success');
      }),
      catchError(this.catchMsgError)
    );

  }

  iniciarJobDiferencaSaldo(dataSolicitacao, tentativa) {
    const params = new HttpParams()
    .set('data-contabil', dataSolicitacao)
    .set('numero-execucao', (typeof tentativa) === "number" ? tentativa : 1);

    return this.http.get(`${this.URL_PIX_GESTAO}/carga-bacen/diferenca-saldo`, {params})
    .pipe(
      map(() => {
        this.snackbarService.open("Job Diferença de Saldo iniciada com sucesso.", 'success');
      }),
      catchError(this.catchMsgError)
    );
  }

  iniciarReprocessar(dataSolicitacao) {
    const params = new HttpParams()
      .set('data-contabil', dataSolicitacao);

    return this.http.get(`${this.URL_PIX_GESTAO}/carga-bacen/reprocessar-transacao-bacen`, {params})
    .pipe(
      map(() => {
        this.snackbarService.open("Reprocessar iniciado com sucesso.", 'success');
      }),
      catchError(this.catchMsgError)
    );

  }

  reverterReprocessar(dataSolicitacao) {
    const params = new HttpParams()
      .set('data-contabil', dataSolicitacao);

    return this.http.get(`${this.URL_PIX_GESTAO}/carga-bacen/rollback-reprocessar-transacao-bacen`, {params})
    .pipe(
      map(() => {
        this.snackbarService.open("Reversão do reprocessar iniciada com sucesso.", 'success');
      }),
      catchError(this.catchMsgError)
    );

  }

  private catchMsgError = (error) => {
    let errorMsg;
    if(error.error && error.error.errorMessage)
      errorMsg = error.error.errorMessage;
    else
      errorMsg = getServerErrorMessage(error);

    this.snackbarService.open(errorMsg, 'error');
    throw errorMsg;
  }
}