import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CargaBacenComponent } from './carga-bacen.component';
const routes: Routes = [
  {
    path: '',
    component: CargaBacenComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CargaBacenRoutingModule {}