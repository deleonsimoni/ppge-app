import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
@Component({
  selector: 'app-historico-carga-bacen-dialog',
  templateUrl: './historico-carga-bacen-dialog.component.html',
  styleUrls: ['./historico-carga-bacen-dialog.component.scss']
})
export class HistoricoCargaBacenDialogComponent implements OnInit {

  header = [
	 "tentativa",
   "dataInicio",
	 "dataFinalizacao",
	 "tarefa",
   "status",
   "motivo"
  ];

  constructor(
    public dialogRef: MatDialogRef<HistoricoCargaBacenDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
  ) {}

  ngOnInit(): void {
    console.log(this.data.dados);
  }
}
