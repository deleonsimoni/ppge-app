import { ChangeDetectionStrategy, Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { DetalheAporte } from '../chave-sinaf.model';

@Component({
  selector: 'app-detalhe-aporte',
  templateUrl: './detalhe-aporte.component.html',
  styleUrls: ['./detalhe-aporte.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DetalheAporteComponent  {

  constructor(
    public dialogRef: MatDialogRef<DetalheAporteComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { detalhe: DetalheAporte, tipo: string },
  ) {
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

}
