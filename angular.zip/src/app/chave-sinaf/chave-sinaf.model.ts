export interface DetalhePagamentoSinaf {
  codigoMensagem: number;
  agencia: string;
  dataReferencia: Date;
  dataEfetiva: Date;
  valor: number;
  idMensagemBacen: number;
  idAporte: number;
}

export interface DetalheChaveSinaf {
  idRoteiro: number;
  mensagem: number;
  tipoLancamento: string;
  sl: string;
  evento: string;
  dataMovimentacao: string;
}

export interface DetalheAporte {
  numControleStr: string;
  dataOperacaoBacen: Date;
  valorOperacao: number;
  tipoOperacao: string;
  tipoMensagem: string;
}

export interface MensagemContabil {
  value: string;
  name: string;
}
