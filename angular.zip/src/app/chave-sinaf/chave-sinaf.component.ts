import { DatePipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { PorServicoDialogComponent } from '@app/consulta/por-servico/por-servico-dialog.component';
import { SnackbarService } from '@core/services';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';
import { take, tap } from 'rxjs/operators';
import { DetalhePagamentoSinaf, MensagemContabil } from './chave-sinaf.model';
import { ChaveSinafService } from './chave-sinaf.service';
import { DetalheAporteComponent } from './detalhe-aporte/detalhe-aporte.component';

@Component({
  selector: 'app-chave-sinaf',
  templateUrl: './chave-sinaf.component.html',
  styleUrls: ['./chave-sinaf.component.scss'],
})
export class ChaveSinafComponent{
  readonly data$ = new BehaviorSubject<DetalhePagamentoSinaf[]>(null);
  name = 'Angular 6';
  status: any[];
  formula: string = 'Formula 1';
  loading=false;
  readonly form = this.fb.group({
    idSimpiSinaf: [{value:'3282282', disabled: true}, [Validators.required, Validators.maxLength(7)]],
    mensagemContabil: [null, [Validators.required]],
    dataDoMovimento: [null, [Validators.required]],
    chave: [{value:'', disabled: true}, [Validators.required, Validators.maxLength(22)]],
    mensagem: [null],
    tipoLancamento: [null],
    sl: [null],
    evento: [null],
    dataMovimentacao: [null],
    idMensagem: [null],
    agencia: [null],
    valorInicio: [null],
    valorFim: [null],
    idRoteiro: [null],
  });
  filtroDownloadCsv = null;
  header = ['id', 'agencia', 'dataReferencia', 'dataEfetiva', 'valor', 'acao'];
  footer = ['quantidade', 'total', 'paginacao'];
  readonly mensagens: MensagemContabil[];

  constructor(
    private fb: FormBuilder,
    public datepipe: DatePipe,
    private snackbarService: SnackbarService,
    private chaveSinafService: ChaveSinafService,
    public dialog: MatDialog,
    private http: HttpClient,
  ) {
    this.mensagens = this.chaveSinafService.getMensagensContabil();
  }

  getData(date: Date) {
    return this.datepipe.transform(date, 'dd/MM/yyyy');
  }

  getDataHora(dateHora: Date) {
    return this.datepipe.transform(dateHora, 'DDMMYYYY-HHMMSS');
  }

  buscarRoteiro() {
    this.chaveSinafService
      .getInfoChaveSinaf(this.form.get('chave').value)
      .pipe(take(1))
      .subscribe((detalhe) => {
        if (detalhe) {
          this.form.get('mensagem').setValue(detalhe.mensagem);
          this.form.get('tipoLancamento').setValue(detalhe.tipoLancamento);
          this.form.get('sl').setValue(detalhe.sl);
          this.form.get('evento').setValue(detalhe.evento);
          this.form
            .get('dataMovimentacao')
            .setValue(
              this.datepipe.transform(detalhe.dataMovimentacao, 'dd/MM/yyyy'),
            );
          this.form.get('idRoteiro').setValue(detalhe.idRoteiro);
        } else {
          this.snackbarService.open('Chave não encontrada', 'error');
        }
      });
  }

  limpar() {
    this.form.reset();
    this.form.get('idSimpiSinaf').setValue('3282282');
    this.data$.next(null);
    this.filtroDownloadCsv = null;

  }

  atualizarChave(){
    let chave =  this.form.get('idSimpiSinaf').value;
    let mensagemContabil = this.form.get('mensagemContabil').value;
    let dataDoMovimento = this.datepipe.transform(this.form.get('dataDoMovimento').value, "ddMMyyyy");

    if (mensagemContabil === undefined || !this.form.controls['mensagemContabil'].valid) {
      mensagemContabil = '';
    }
    if ( dataDoMovimento === null || !this.form.controls['dataDoMovimento'].valid) {
      dataDoMovimento = '';
    }

    this.setChaveSinaf(chave, mensagemContabil, dataDoMovimento);
  }

  setChaveSinaf(chave, mensagemContabil, dataDoMovimento ) {
    this.form.get('chave').setValue(chave + mensagemContabil + dataDoMovimento);
  }

  onDownloadCsv() {
    var options = {};
    this.loading = true;
    this.chaveSinafService
      .getGerarArquivoSinaf(this.filtroDownloadCsv)
      .pipe(
        tap(blob => {
          const a = document.createElement('a')
          const objectUrl = URL.createObjectURL(blob)
          a.href = objectUrl;
          let dataHora = this.datepipe.transform(new Date(), 'ddMMyyyy-HHmmss');
          a.download = 'chaveSINAF' + dataHora + '.csv';
          a.click();
          URL.revokeObjectURL(objectUrl);
          this.loading = false;
        },
        (error) => {
          this.loading = false;
          this.snackbarService.open('Erro ao realizar download do arquivo!', 'error');
        },
        ),
      )
      .subscribe();
  }

  onSubmit(): void {
    this.chaveSinafService
      .getLancamentosChaveSinaf(
        this.form.get('agencia').value,
        this.form.get('valorInicio').value,
        this.form.get('valorFim').value,
        this.form.get('idMensagem').value,
        this.form.get('sl').value,
        this.form.get('evento').value,
        this.form.get('dataMovimentacao').value,
        this.form.get('mensagem').value,
      )
      .pipe(take(1))
      .subscribe((consulta) => {
        if (consulta && consulta.totalRegistros > 0) {
          this.data$.next(consulta);
          this.preencherFiltroDownload();
        } else {
          this.filtroDownloadCsv = null;
          this.data$.next(null);
          this.snackbarService.open('Nenhum registro encontrado', 'error');
        }
        if (
          this.form.get('agencia').value ||
          this.form.get('idMensagem').value
        ) {
        }
      });
  }

  preencherFiltroDownload() {
    this.filtroDownloadCsv = {
      agencia: this.form.get('agencia').value,
      valorInicio: this.form.get('valorInicio').value,
      valorFim: this.form.get('valorFim').value,
      idMensagem: this.form.get('idMensagem').value,
      sl: this.form.get('sl').value,
      evento: this.form.get('evento').value,
      data: this.form.get('dataMovimentacao').value,
      tipo: this.form.get('tipoLancamento').value,
      mensagem: this.form.get('mensagem').value
    };
  }

  onPagination(event: PageEvent): void {
    this.chaveSinafService
      .getLancamentosChaveSinaf(
        this.form.get('agencia').value,
        this.form.get('valorInicio').value,
        this.form.get('valorFim').value,
        this.form.get('idMensagem').value,
        this.form.get('sl').value,
        this.form.get('evento').value,
        this.form.get('dataMovimentacao').value,
        this.form.get('mensagem').value,
        event.pageIndex + 1,
        event.pageSize,
      )
      .pipe(take(1))
      .subscribe((consulta) => {
        this.data$.next(consulta);
      });
  }

  onOpenDialog(idMensagem: number, idAporte: number, dataMensagem: string) {
    let tipo = this.form.get('mensagem').value;

    const data: string = moment(dataMensagem).format('DD/MM/YYYY');

    if (idMensagem) {
      this.chaveSinafService
        .getDetalheMensagem(idMensagem, data)
        .pipe(take(1))
        .subscribe((detalhe) => {
          this.dialog.open(PorServicoDialogComponent, {
            data: { detalhe, tipo },
          });
        });
    }

    if (idAporte) {
      this.chaveSinafService
        .getDetalheAporte(idAporte)
        .pipe(take(1))
        .subscribe((detalhe) => {
          this.dialog.open(DetalheAporteComponent, {
            data: { detalhe, tipo },
          });
        });
    }
  }
}
