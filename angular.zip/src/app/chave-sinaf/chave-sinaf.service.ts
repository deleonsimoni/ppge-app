import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { Observable } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { DetalheAporte, DetalheChaveSinaf } from './chave-sinaf.model';





@Injectable({
  providedIn: 'root',
})
export class ChaveSinafService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_CONSULTA_CHAVE = `${this.URL_PIX_GESTAO}/chaves-sinaf`;
  private readonly URL_EXPORTAR_ARQUIVO_SINAF = `${this.URL_PIX_GESTAO}/chaves-sinaf/download/arquivo`;
  private readonly URL_DETALHE = `${this.URL_PIX_GESTAO}/mensagens`;

  constructor(private http: HttpClient, public datepipe: DatePipe) {}

  public getInfoChaveSinaf(chave: string): Observable<DetalheChaveSinaf> {
    return this.http.get<DetalheChaveSinaf>(
      `${this.URL_CONSULTA_CHAVE}/${chave}`,
    );
  }

  getDetalheMensagem(id: number, dataMensagem: string): Observable<object> {
    let params = new HttpParams().set('dataMensagem', dataMensagem);
    return this.http.get<object>(`${this.URL_DETALHE}/${id}/detalhe/chave-sinaf`, {params});
  }

  getMensagensContabil(){
    return [
      { name: 'PACS008 C', value: '3421811'},
      { name: 'PACS008 D', value: '3421491'},
      { name: 'PACS004 C', value: '3421492'},
      { name: 'PACS004 D', value: '3421812'},
      { name: 'LPI0001 C', value: '3424161'},
      { name: 'LPI0003 D', value: '3424241'},
      { name: 'LPI0006 C', value: '3424161'},
      { name: 'SEL1009 C', value: '3424321'},
      { name: 'SEL1016 D', value: '3424401'},
      { name: 'CAMT053 C', value: '3669861'}
      
    ]
  }

  getDetalheAporte(id: number): Observable<DetalheAporte> {
    return this.http.get<DetalheAporte>(`${this.URL_PIX_GESTAO}/aporte-recursos/${id}`);
  }

  public getLancamentosChaveSinaf(
    agencia: string,
    valorInicio: string,
    valorFim: string,
    idMensagem: string,
    sl: string,
    evento:string,
    data: string,
    tipoMensagem: string,
    page: number = 1,
    tamanhoPagina: number = 15,
  ): Observable<any> {
    let params = new HttpParams();
    params = params.set('evento', evento);
    params = params.set('sl', sl);
    params = params.set('pagina',  page.toString());
    params = params.set('tamanhoPagina', tamanhoPagina.toString());
    params = params.set('data', data);
    params = params.set('tipoMensagem', tipoMensagem);
    if (agencia) {
      params = params.set('agencia', agencia);
    }
    if (valorInicio) {
      params = params.set('valorInicio', valorInicio);
    }
    if (valorFim) {
      params = params.set('valorFim', valorFim);
    }
    if (idMensagem) {
      params = params.set('idMensagem', idMensagem);
    }

    return this.http.get<any>(this.URL_CONSULTA_CHAVE, {params});

  }

  public getGerarArquivoSinaf(
    filtro: any
  ): Observable<any> {
    let params = new HttpParams();
    params = params.set('evento', filtro.evento);
    params = params.set('sl', filtro.sl);
    params = params.set('data', filtro.data);
    if (filtro.agencia) {
      params = params.set('agencia', filtro.agencia);
    }
    if (filtro.valorInicio) {
      params = params.set('valorInicio', filtro.valorInicio);
    }
    if (filtro.valorFim) {
      params = params.set('valorFim', filtro.valorFim);
    }
    if (filtro.idMensagem) {
      params = params.set('idMensagem', filtro.idMensagem);
    }
    if (filtro.tipo) {
      params = params.set('tipo', filtro.tipo);
    }
    if (filtro.mensagem) {
      params = params.set('mensagem', filtro.mensagem);
    }
    return this.http.get<any>(this.URL_EXPORTAR_ARQUIVO_SINAF, {params, responseType: 'blob'as 'json'});

  }

  getDownloadArquivo(arquivo: string):Observable<ArrayBuffer> {
    let params = new HttpParams();
    if (arquivo) {
      params = params.set('arquivo', arquivo);
    }
    return this.http.get<ArrayBuffer>(this.URL_EXPORTAR_ARQUIVO_SINAF, { params, responseType: 'blob' as 'json'});

    }
}
