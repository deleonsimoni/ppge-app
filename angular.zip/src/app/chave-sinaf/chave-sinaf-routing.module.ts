import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChaveSinafComponent } from './chave-sinaf.component';

const routes: Routes = [
  {
    path: '',
    component: ChaveSinafComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ChaveSinafRoutingModule { }
