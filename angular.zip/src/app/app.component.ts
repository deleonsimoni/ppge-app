import { ChangeDetectionStrategy, Component } from '@angular/core';
import { map } from 'rxjs/operators';
import { LoadingService } from '@core/services';
import { LoginService } from '@store/login';
import { environment } from '@env/environment';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent {
  readonly loading$ = this.loadingService.isLoading();
  readonly token$ = this.loginService
    .getToken()
    .pipe(map((token) => (token ? token : !environment.production)));

  constructor(
    private loginService: LoginService,
    private loadingService: LoadingService,
  ) {
  }

  isClass(): boolean {
    return Math.floor(Math.random() * 5) > 2;
  }
}
