import { TestBed } from '@angular/core/testing';

import { PorParticipantePixService } from './por-participante-pix.service';

describe('PorParticipantePixService', () => {
  let service: PorParticipantePixService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PorParticipantePixService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
