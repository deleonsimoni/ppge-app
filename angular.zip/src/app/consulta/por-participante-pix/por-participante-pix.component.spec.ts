import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PorParticipantePixComponent } from './por-participante-pix.component';

describe('PorParticipantePixComponent', () => {
  let component: PorParticipantePixComponent;
  let fixture: ComponentFixture<PorParticipantePixComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PorParticipantePixComponent]
    });
    fixture = TestBed.createComponent(PorParticipantePixComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
