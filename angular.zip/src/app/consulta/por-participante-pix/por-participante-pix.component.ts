import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';

import { PageEvent } from '@angular/material/paginator';
import DataUtils from '@app/shared/data-utils';
import { SnackbarService } from '@core/services';
import * as moment from 'moment';

import { BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import { PorParticipantePixService } from './por-participante-pix.service';
import { RelatorioCamtResponse } from './por-participante-pix.model';

@Component({
  selector: 'app-por-participante-pix',
  templateUrl: './por-participante-pix.component.html',
  styleUrls: ['./por-participante-pix.component.scss']
})
export class PorParticipantePixComponent {

  header = [
    "dataLiquidacao",
    "ispb",
    "nome",
    "tipo",
    "modalidade",
    "situacao"
  ]
  footer = ['total'];
  paginaAtual = 1;
  tamanhoPagina: number = 15;

  readonly data$ = new BehaviorSubject<RelatorioCamtResponse>(null);

  readonly date = new Date(new Date().setDate(new Date().getDate() -1));

  readonly form = this.fb.group({
    dataInicio: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
    dataFim: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ]});
  constructor(
    private fb: FormBuilder,
    public datepipe: DatePipe,
    private snackbarService: SnackbarService,
    private porParticipantePixService: PorParticipantePixService
  ) { }

  onPagination(event: PageEvent): void {
    this.paginaAtual = event.pageIndex + 1;
    this.tamanhoPagina = event.pageSize;

    this.porParticipantePixService
      .getListRelatorioCam14(
        this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT),
        this.datepipe.transform(this.form.value.dataFim, DataUtils.DATE_FORMAT),
        this.paginaAtual,
        this.tamanhoPagina,
      ).pipe(take(1))
      .subscribe((listRelatorioCamt14) => {
        this.data$.next(listRelatorioCamt14);
      })
  }

  onSubmit() {
    if(this.form.valid) {
      this.porParticipantePixService
        .getListRelatorioCam14(
          this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT),
          this.datepipe.transform(this.form.value.dataFim, DataUtils.DATE_FORMAT)
        ).pipe(take(1))
        .subscribe((listRelatorioCamt14) => {
          this.data$.next(listRelatorioCamt14);
        })
    } else {
      this.snackbarService.open("Formulário inválido!", "error");
    }
  }
}
