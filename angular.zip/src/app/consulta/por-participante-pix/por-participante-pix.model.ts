export interface RelatorioCamtResponse{
  dados: RelatorioCamt14[];
	pagina: number;
	paginas: number;
	tamanhoPagina: number;
	totalRegistros: number;
}

export interface RelatorioCamt14 {
  dataLiquidacao: Date;
  ispb: string;
  nome: string;
  tipo: string;
  modalidade: string;
  situacao: string;
}
