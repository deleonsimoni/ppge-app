import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { SnackbarService } from "@core/services";
import { catchError, map } from "rxjs/operators";
import { RelatorioCamtResponse } from './por-participante-pix.model';

@Injectable({
  providedIn: 'root'
})
export class PorParticipantePixService {

  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_CONSULTA = `${this.URL_PIX_GESTAO}/mensagens/camt/participantes-pix`;
  private statusErrors = {
    404: `Not Found.`,
    403: `Access Denied.`,
    500: `Internal Server Error.`,
  }
  constructor(
    private http: HttpClient,
    private snackbarService: SnackbarService) { }

  getListRelatorioCam14(
      dataInicio: string,
      dataFim: string,
      page: number = 1,
      tamanhoPagina: number = 15,
    ) {
      const params = new HttpParams()
      .set("dataInicio", dataInicio)
      .set("dataFim", dataFim)
      .set('pagina', page.toString())
      .set('tamanhoPagina', tamanhoPagina.toString())

      return this.http.get<RelatorioCamtResponse>(`${this.URL_CONSULTA}`, {params})
      .pipe(
        map((response) => {
          if (response.dados.length <= 0) {
            this.snackbarService.open("Nenhum Registro Encontrado.",'error');
          } else {
            return response;
          }
        }),
        catchError((error) => {
          let errorMsg: string = this.statusErrors[error.status] ? this.statusErrors[error.status] : `Unknown Server Error.`;
          this.snackbarService.open(errorMsg,'error');
          throw errorMsg;
        })
      )
    }
}
