import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PorParticipantePixComponent } from './por-participante-pix.component';

import { MatInputModule } from '@angular/material/input';
import { ReactiveFormsModule } from '@angular/forms';
import { MatRadioModule } from '@angular/material/radio';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { TipoModalidadeModule } from '@core/pipes/tipo-modalidade/tipo-modalidade.module';


@NgModule({
  declarations: [
    PorParticipantePixComponent
  ],
  imports: [
    CommonModule,
    MatInputModule,
    ReactiveFormsModule,
    MatRadioModule,
    MatDatepickerModule,
    MatTableModule,
    MatPaginatorModule,
    TipoModalidadeModule
  ]
})
export class PorParticipantePixModule { }
