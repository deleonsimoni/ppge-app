import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PorServicoComponent } from './por-servico/por-servico.component';
import { PorStatusComponent } from './por-status/por-status.component';
import { RemuneracaoContaPiComponent } from './remuneracao-conta-pi/remuneracao-conta-pi.component';
import { PorParticipantePixComponent } from './por-participante-pix/por-participante-pix.component';

const routes: Routes = [
  {
    path: 'por-servico',
    component: PorServicoComponent,
  },
  {
    path: 'por-status',
    component: PorStatusComponent,
  },
  {
    path: 'remuneracao-conta-pi',
    component: RemuneracaoContaPiComponent,
  },
  {
    path: 'por-participante-pix',
    component: PorParticipantePixComponent,
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ConsultaRoutingModule {}
