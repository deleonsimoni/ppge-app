import { ChangeDetectionStrategy, Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Mensagem } from '@app/consulta/por-servico/por-servico.model';

@Component({
  selector: 'app-xml-mensagem-dialog',
  templateUrl: './xml-mensagem-dialog.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class XmlMensagemDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<Mensagem>,
    @Inject(MAT_DIALOG_DATA) public data: { xml: string; tipo: string },
  ) {}
}
