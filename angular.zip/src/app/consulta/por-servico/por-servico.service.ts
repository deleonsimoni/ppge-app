import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MensagemResponse, Mensagem, MensagemRejeicaoResponse } from './por-servico.model';
import { environment } from '@env/environment';
import { DetalheMensagemUnion } from '@app/mensageria/mensageria.model';
import { catchError, map } from 'rxjs/operators';
import { SnackbarService } from '@core/services';

@Injectable({
  providedIn: 'root',
})
export class PorServicoService {

  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_SIMPI_MENSAGERIA = `${environment.urlSIMPIMensageria}/simpi-mensageria-api/api/v1/simpi-mensageria`;


  private readonly URL_CONSULTA = `${this.URL_PIX_GESTAO}/mensagens/consulta-mensagens`;
  private readonly URL_CONSULTA_APORTE_SAQUE = `${this.URL_PIX_GESTAO}/aporte-recursos/consulta`;
  private readonly URL_DETALHE = `${this.URL_PIX_GESTAO}/mensagens`;
  private readonly URL_DETALHE_APORTE_SAQUE = `${this.URL_PIX_GESTAO}/aporte-recursos/consulta`;
  private readonly URL_HISTORICO = `${this.URL_PIX_GESTAO}/historico-mensagens`;
  private readonly URL_DOWNLOAD = `${this.URL_SIMPI_MENSAGERIA}/download-arquivo`;
  private readonly URL_MENSAGEM_REJEICAO = `${this.URL_PIX_GESTAO}/mensagem-rejeicao`;
  private readonly URL_MENSAGEM_AUTOMATICA =  `${this.URL_PIX_GESTAO}/mensagens-automaticas`;
  private readonly URL_REENVIO_CONTABIL =  `${this.URL_PIX_GESTAO}/aporte-recursos`;

  constructor(private http: HttpClient, private datePipe: DatePipe, private snackbarService: SnackbarService) {}

  getDetalheMensagem(id: string, isTabelaHistorico: string, isTabelaOld: string, isTabelaSimples: string): Observable<object> {
    let params = new HttpParams();
    params = params.set('isTabelaHistorico', isTabelaHistorico);
    params = params.set('isTabelaOld', isTabelaOld);
    params = params.set('isTabelaSimples', isTabelaSimples);
    return this.http.get<object>(`${this.URL_DETALHE}/${id}/detalhe`, { params});
  }

  getDetalheMensagemAutomatica(id: string): Observable<object> {
    return this.http.get<object>(`${this.URL_MENSAGEM_AUTOMATICA}/${id}/detalhe`);
  }

  getDetalheMensagemAporteSaque(id: string): Observable<object> {
    return this.http.get<object>(`${this.URL_PIX_GESTAO}/aporte-recursos/consulta/${id}/detalhe`);
  }

  getXMLMensagem(id: string, tipo: string, isTabelaHistorico: string, coMensagemPagamento: string, isTabelaOld: string, isTabelaSimples: string): Observable<string> {
    switch (tipo) {
      case 'CXM1024':
        return this.http.get(`${this.URL_DETALHE_APORTE_SAQUE}/${id}/xml`, { responseType: 'text' });
      case 'CAMT014': case 'REDA041':
        return this.http.get(`${this.URL_MENSAGEM_AUTOMATICA}/${id}/xml`, { responseType: 'text' });
      default:
        let params = new HttpParams();
        params = params.set('coMensagemPagamento', coMensagemPagamento);
        params = params.set('isTabelaHistorico', isTabelaHistorico);
        params = params.set('isTabelaOld', isTabelaOld);
        params = params.set('isTabelaSimples', isTabelaSimples);
        return this.http.get(`${this.URL_DETALHE}/${id}/xml`, { params, responseType: 'text' });
    }
  }

  getDetalheMensagem2(id: string): Observable<DetalheMensagemUnion> {
    return this.http.get<DetalheMensagemUnion>(
      `${this.URL_DETALHE}/${id}/detalhe`,
    );
  }

  getMensagensRelacionadas(id: string, isTabelaHistorico: string, isTabelaOld: string, isTabelaSimples: string): Observable<Mensagem[]> {
    let params = new HttpParams();
    params = params.set('isTabelaHistorico', isTabelaHistorico);
    params = params.set('isTabelaOld', isTabelaOld);
    params = params.set('isTabelaSimples', isTabelaSimples);

    return this.http.get<Mensagem[]>(
      `${this.URL_DETALHE}/${id}/mensagens-relacionadas`, { params});
  }

  getDownloadArquivo(nomeArquivo: string, idMensagemOriginal: string):Observable<ArrayBuffer> {
    let params = new HttpParams();
    if (nomeArquivo) {
      params = params.set('nomeArquivo', nomeArquivo);
      params = params.set('idMensagemOriginal', idMensagemOriginal);
    }
    return this.http.get<ArrayBuffer>(this.URL_DOWNLOAD, { params, responseType: 'blob' as 'json'});

    }

  getMensagens(
    data: string,
    horaInicio: string,
    horaFim: string,
    idMensagem: string,
    idFimAFim: string,
    statusMensagem: string,
    coMensagemRejeicao: string,
    situacao: string,
    ispb: string,
    valorInicio: string,
    valorFim: string,
    tipoPagamento: string,
    codigo: string,
    campoOrdenado: string,
    tipoOrdenacao: string,
    page: number = 1,
    tamanhoPagina: number = 15,
  ): Observable<MensagemResponse> {
    let params = new HttpParams();

    if (campoOrdenado && tipoOrdenacao) {
      params = params.set('campoOrdenado', campoOrdenado);
      params = params.set('tipoOrdenacao', tipoOrdenacao);
    }
    if (data) {
      params = params.set('data', data);
    }
    if (horaInicio) {
      params = params.set('horaInicio', horaInicio);
    }
    if (idFimAFim) {
      params = params.set('idFimAFim', idFimAFim);
    }
    if (horaFim) {
      params = params.set('horaFim', horaFim);
    }
    if (idMensagem) {
      params = params.set('idMensagem', idMensagem);
    }
    if (statusMensagem) {
      params = params.set('statusMensagem', statusMensagem);
    }

    if (coMensagemRejeicao) {
      params = params.set('coMensagemRejeicao', coMensagemRejeicao);
    }
    if (situacao) {
      params = params.set('situacaoMensagem', situacao);
    }
    if (ispb) {
      params = params.set('ispb', ispb);
    }

    if (tipoPagamento) {
      params = params.set('tipoPagamento', tipoPagamento);
    }
    if (codigo) {
      params = params.set('codigo', codigo);
    }
    if ((valorInicio && valorFim) && (codigo === 'PACS004' || codigo === 'PACS008')) {
      params = params.set('valorInicio', valorInicio);
      params = params.set('valorFim', valorFim);
    }
    params = params
      .set('pagina', page.toString())
      .set('tamanhoPagina', tamanhoPagina.toString());
    switch (codigo) {
      case 'CXM1024':
        return this.http.get<MensagemResponse>(this.URL_CONSULTA_APORTE_SAQUE, { params })
        .pipe(
          map((response) => {
            if (response.totalRegistros <= 0) {
              this.snackbarService.open("Nenhum Registro Encontrado.",'error');
            } else {
              return response;
            }
          }),
          catchError((error) => {
            let errorMsg: string;
            errorMsg = this.getServerErrorMessage(error);
            this.snackbarService.open(errorMsg,'error');
            throw errorMsg;
          })
        );
      case 'CAMT014': case 'REDA041':
        return this.http.get<MensagemResponse>(`${this.URL_MENSAGEM_AUTOMATICA}/consulta`, { params })
        .pipe(
          map((response) => {
            if (response.totalRegistros <= 0) {
              this.snackbarService.open("Nenhum Registro Encontrado.",'error');
            } else {
              return response;
            }
          }),
          catchError((error) => {
            let errorMsg: string;
            errorMsg = this.getServerErrorMessage(error);
            this.snackbarService.open(errorMsg,'error');
            throw errorMsg;
          })
        );
      default:
        return this.http.get<MensagemResponse>(this.URL_CONSULTA, { params })
        .pipe(
          map((response) => {
            if (response.totalRegistros <= 0) {
              this.snackbarService.open("Nenhum Registro Encontrado.",'error');
            } else {
              return response;
            }
          }),
          catchError((error) => {
            let errorMsg: string;
            errorMsg = this.getServerErrorMessage(error);
            this.snackbarService.open(errorMsg,'error');
            throw errorMsg;
          })
        );
    }
  }

  getHistoricoMensagem(id: string, isTabelaHistorico: string, isTabelaOld: string, isTabelaSimples: string) {
    let params = new HttpParams();
    params = params.set('isTabelaHistorico', isTabelaHistorico);
    params = params.set('isTabelaOld', isTabelaOld);
    params = params.set('isTabelaSimples', isTabelaSimples);
    return this.http.get<MensagemResponse>(`${this.URL_HISTORICO}/${id}`, {params});
  }

  getHistoricoMensagemAutomatica(id: string) {
    return this.http.get<MensagemResponse>(`${this.URL_MENSAGEM_AUTOMATICA}/historico/${id}`);
  }

  getMensagemRejeicao(): Observable<MensagemRejeicaoResponse>{
    return this.http.get<MensagemRejeicaoResponse>(`${this.URL_MENSAGEM_REJEICAO}`);
  }


  reenviarContabil(id: string): Observable<boolean> {
    return this.http
      .post(`${this.URL_REENVIO_CONTABIL}/${id}/reenvio-contabil`,null, { observe: 'response' })
      .pipe(
        map((response) => response.status === 202),
        catchError((err) => {
          let errorMsg: string;
          console.log(err);
          this.snackbarService.open(err.error.errorMessage,'error');
          throw errorMsg;
        }),
      );
  }

  private getServerErrorMessage(error: HttpErrorResponse): string {
    switch (error.status) {
      case 404: {
        return `Not Found.`;
      }
      case 403: {
        return `Access Denied.`;
      }
      case 500: {
        return `Internal Server Error.`;
      }
      default: {
        return `Unknown Server Error.`;
      }
    }
  }
}
