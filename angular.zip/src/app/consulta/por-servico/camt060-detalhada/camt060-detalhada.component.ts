import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { DetalheCamt060 } from '../por-servico.model';

@Component({
  selector: 'app-camt060-detalhada',
  templateUrl: './camt060-detalhada.component.html',
  styleUrls: [
    './camt060-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Camt060DetalhadaComponent {
  @Input() detalhe: DetalheCamt060;
}
