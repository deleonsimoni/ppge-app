import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { DetalheCxm1024 } from '../por-servico.model';

@Component({
  selector: 'app-cxm1024-detalhada',
  templateUrl: './cxm1024-detalhada.component.html',
  styleUrls: [
    './cxm1024-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Cxm1024DetalhadaComponent {
  @Input() detalhe: DetalheCxm1024;
  
  formatarCpfCnpj(valor : string) : string {
    if (valor.length <= 11) {
        return valor.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/g,"\$1.\$2.\$3\-\$4");
    } else {
        return valor.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/g,"\$1.\$2.\$3\/\$4\-\$5");
    }
  }
}
