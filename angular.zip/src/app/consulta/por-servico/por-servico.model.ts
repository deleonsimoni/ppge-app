import {
  Usuario,
  DetalheMensagemUnion,
} from '../../mensageria/mensageria.model';
export interface MensagemResponse {
  dados: Mensagem[];
  pagina: number;
  paginas: number;
  tamanhoPagina: number;
  totalRegistros: number;
  isTabelaHistorico: string;
  isTabelaOld: string;
}

export interface Mensagem {
  idDetalhamentoMensagem: string;
  codMensagem: string;
  id: string;
  idMensagem: string;
  idFimAFim: string;
  xml: string;
  destinatarioEmissor: string;
  data: string;
  hora: string;
  valor: number;
  icMensagemEnviada: string;
  ispbOrigem: string;
  ispbDestino: string;
  detalhe: DetalheMensagemUnion;
  coMensagemRejeicao: string;
  descricaoMensagemRejeicao: string;
  tabelaHistorico: string;
  coMensagemOriginal: string;
  tabelaOld: string;
  tabelaSimples: string;
}

export interface MensagemRejeicaoResponse {
  coMensagemRejeicao: string;
  descricaoMensagemRejeicao: string;
  dataInicioMensagemRejeicao: Date;
  dataFimMensagemRejeicao: Date;
}

export interface Historico {
  idMensagem: string;
  idFimAFim: string;
  dataEvento: Date;
  tipoMensagem: string;
  situacaoMensagem: string;
}

export interface DetalheReda041 {
  idMensagem: string;
  participante:
    {
      ispb: string;
      emissor: string;
    };
  nome:
    {
      nomeAntigo: string;
      nomeNovo: string;
    };
}

export interface DetalheCamt052 {
  idMensagem: string;
  lancamentos: [
    {
      idMensagemOriginal: string;
      quantidadeLancamentos: string;
      nomeArquivo: string;
    },
  ];
}

export interface DetalheCamt053 {
  idMensagem: string;
  saldos: [
    {
      idMensagemOriginal: string;
      detalhesSaldos: [
        {
          tipoSaldo: string;
          valorSaldo: number;
          saldoCredorDevedor: string;
          dataConsulta: string;
        },
      ];
    },
  ];
}

export interface DetalheValoresCamt054 {
  tipo: string;
  valor: string;
}

export interface DetalheCamt054 {
  idMensagem: string;
  lancamentos: [
    {
      idMensagemOriginal: string;
      valorLancamento: number;
      tipoDebitoCredito: string;
      statusLancamento: string;
      idDevolucaoLancamento: string;
      idFimAFimLancamento: string;
      idAporteSaque: string;
      idTransacao: string;
      tipoAgente: string;
      ispbOrigemLancamento: string;
      formaDeIniciacao: string;
      tipoPrioridadePagamento: string;
      finalidadeDaTransacao: string;
      dadosValoresAjustes: Array<DetalheValoresCamt054>;
    },
  ];
}


export interface DetalheCamt060 {
  idMensagem: string;
  idInstrucao: string;
  tipoConsulta: string;
  tipoResultado: string;
  dataInicialResultado: string;
  dataFinalResultado: string;
  horarioInicialResultado: string;
  horarioFinalResultado: string;
}

export interface DetalhePacs004 {
  idMensagem: string;
  idDevolucao: string;
  idFimAFimOriginal: string;
  valor: number;
  ipsbParticipantePagador: string;
  ispbParticipanteRecebedor: string;
  codigoDevolucao: string;
  informacaoAdicional: string;
}

export interface DetalhePibr002 {
  idMensagem: string;
  conteudoMensagemOriginal: string;
}

export interface DetalhePibr001 {
  idMensagem: string;
  conteudoMensagem: string;
}

export interface DetalheAdmi002 {
  idMensagem: string;
  referencia: string;
  motivoErro: string;
  localizacaoErro: string;
  descricaoErro: string;
}

export interface DetalheAdmi004 {
  idMensagem: string;
  descricao: string;
  codigo: string;
}

export interface DetalhePacs002 {
  idMensagem: string;
  idInstrucaoOriginal: string;
  idFimAFimOriginal: string;
  situacaoTransacao: string;
  listaCodigo: [
    {
      Rsn: {
          Cd: string;
       },
      AddtlInf: string[];
    }];
  dataHoraLiquidacao: Date;
}

export enum PrioridadePagamento {
  'HIGH' = 'ALTA',
  'NORM' = 'NORMAL',
}

export enum TipoConta {
  'CACC' = 'Conta Corrente',
  'SLRY' = 'Conta-Salário',
  'SVGS' = 'Conta de Poupança',
  'TRAN' = 'Conta de Pagamento',
}

export enum ParticipanteTarifado {'SLEV' = 'As cobranças devem ser aplicadas de acordo com as regras acordadas no nível de serviço.'}

export interface UsuarioDetalhado {
  nome?: string;
  agencia: string;
  tipoConta: TipoConta;
  conta: string;
  ispb: string;
  inscricao: string;
  ispbParticipante?: string;
  cpfCnpj?: string;
}

export interface DetalhePacs008 {
  idMensagem: string;
  idFimAFim: string;
  informacoesEntreUsuarios: string;
  prioridadePagamento: string;
  participanteTarifado: string;
  usuarioPagador: Usuario;
  usuarioRecebedor: Usuario;
  valor: number;
  dataTransacao: Date;
}

export interface DetalheCamt014 {
	idMensagem: string;
	dataHoraEnvioPeloParticipante: Date;
  nomeParticipante: string;
  tipoParticipante: string;
  situacaoParticipante: string;
  ispbParticipante: string;

}

export interface DetalheReda014 {
  idMensagem: string;
  dataHoraEnvioPeloParticipante: string;
  idParticipanteDireto: string;
  cnpjParticipanteIndireto: string;
  nomeAtributo: string;
  bcb: string;
  tipoParticipanteIndireto: string;
}

export interface DetalheReda016 {
  idMensagem: string;
	situacaoSolicitacao: string;
	codigoErro: string;
	ispbParticipante: string;
	entidadeEmissora: string;
	ispbResponsavelRegistro: string;
	entidadeEmissoraResponsavelRegistro: string;
}

export interface DetalheReda022 {
	idMensagem: string;
	ispbParticipanteDireto: string;
	entidadeEmissora: string;
	modificacoes: [{
   tipoModificacao: string;
   telefone01: string;
   telefone02: string;
   telefone03: string;
   emailParaInformeSpi: string;
   tipoResponsavel: string;
   nomeDiretor: string;
   palavraChave: string;
   nomeAtributo: string;
   cpfDiretor: string;
  }];
}
export interface DetalheReda031 {
  idMensagem: string;
	participanteIndireto: string;
}
export interface DetalheCxm1024 {
	numControleStr: string;
	tipoOperacao: string;
	dataOperacaoBacen: Date;
	tipoMensagem: string;
	valorOperacao: number;
	dataInclusaoOperacao: Date;
	deConteudoMnsgmAporteSaque: string;
}

