import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { DetalhePibr001 } from '../por-servico.model';

@Component({
  selector: 'app-pibr001-detalhada',
  templateUrl: './pibr001-detalhada.component.html',
  styleUrls: [
    './pibr001-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Pibr001DetalhadaComponent {
  @Input() detalhe: DetalhePibr001;
}
