import { Component, Input } from '@angular/core';
import { DetalheReda041 } from '../por-servico.model';

@Component({
  selector: 'app-reda041-detalhada',
  templateUrl: './reda041-detalhada.component.html',
  styleUrls: [
    './reda041-detalhada.component.scss',
  ],
})
export class Reda041DetalhadaComponent {
  @Input() detalhe: DetalheReda041;
}
