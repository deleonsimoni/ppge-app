import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { DetalhePacs002 } from '../por-servico.model';
import { Pacs002Status, Pacs002ReasonCode } from '@app/mensageria/mensageria.model';

@Component({
  selector: 'app-pacs002-detalhada',
  templateUrl: './pacs002-detalhada.component.html',
  styleUrls: [
    './pacs002-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Pacs002DetalhadaComponent {
  @Input() detalhe: DetalhePacs002;
  readonly pacs002Status = Pacs002Status;
  readonly pacs002ReasonCode = Pacs002ReasonCode;
}
