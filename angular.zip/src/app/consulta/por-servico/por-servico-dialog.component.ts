import { ChangeDetectionStrategy, Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Mensagem } from '@app/consulta/por-servico/por-servico.model';
import { PorServicoService } from './por-servico.service';

@Component({
  selector: 'app-por-servico-dialog',
  templateUrl: 'por-servico-dialog.component.html',
  styleUrls: ['./por-servico.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PorServicoDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<Mensagem>,
    private porServicoService: PorServicoService,
    @Inject(MAT_DIALOG_DATA) public data: { detalhe: object; tipo: string },
  ) {
  }
}
