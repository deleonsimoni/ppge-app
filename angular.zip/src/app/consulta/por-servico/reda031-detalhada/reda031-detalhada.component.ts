import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { DetalheReda031 } from '../por-servico.model';
import { ISPBInstituicao } from '@app/mensageria/mensageria.model';

@Component({
  selector: 'app-reda031-detalhada',
  templateUrl: './reda031-detalhada.component.html',
  styleUrls: [
    './reda031-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Reda031DetalhadaComponent {

  @Input() detalhe: DetalheReda031;
  readonly ispbs = ISPBInstituicao;
}

