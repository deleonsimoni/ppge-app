import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { NgxMaskModule } from 'ngx-mask';
import { MatTooltipModule } from '@angular/material/tooltip';
import { PorServicoComponent } from './por-servico.component';
import { MatDialogModule } from '@angular/material/dialog';
import { PorServicoDialogComponent } from './por-servico-dialog.component';
import { MatListModule } from '@angular/material/list';
import { MatGridListModule } from '@angular/material/grid-list';
import { Pacs008DetalhadaComponent } from './pacs008-detalhada/pacs008-detalhada.component';
import { Pacs002DetalhadaComponent } from './pacs002-detalhada/pacs002-detalhada.component';
import { Admi002DetalhadaComponent } from './admi002-detalhada/admi002-detalhada.component';
import { Camt054DetalhadaComponent } from './camt054-detalhada/camt054-detalhada.component';
import { XmlMensagemDialogComponent } from './xml-mensagem-dialog/xml-mensagem-dialog.component';
import { HistoricoDialogComponent } from './historico-dialog/historico-dialog.component';
import { PrettyXMLPipeModule } from '@core/pipes/pretty-xml/pretty-xml.module';
import { HighlightModule } from 'ngx-highlightjs';
import { Camt052DetalhadaComponent } from './camt052-detalhada/camt052-detalhada.component';
import { Camt053DetalhadaComponent } from './camt053-detalhada/camt053-detalhada.component';
import { Pibr001DetalhadaComponent } from './pibr001-detalhada/pibr001-detalhada.component';
import { Pibr002DetalhadaComponent } from './pibr002-detalhada/pibr002-detalhada.component';
import { Pacs004DetalhadaComponent } from './pacs004-detalhada/pacs004-detalhada.component';
import { Camt060DetalhadaComponent } from './camt060-detalhada/camt060-detalhada.component';
import { Cxm1024DetalhadaComponent } from './cxm1024-detalhada/cxm1024-detalhada.component';
import { NgxCurrencyModule } from 'ngx-currency';
import { Reda016DetalhadaComponent } from './reda016-detalhada/reda016-detalhada.component';
import { Reda022DetalhadaComponent } from './reda022-detalhada/reda022-detalhada.component';
import { Camt014DetalhadaComponent } from './camt014-detalhada/camt014-detalhada.component';
import { Admi004DetalhadaComponent } from './admi004-detalhada/admi004-detalhada.component';
import { Reda041DetalhadaComponent } from './reda041-detalhada/reda041-detalhada.component';
import { Reda014DetalhadaComponent } from './reda014-detalhada/reda014-detalhada.component';
import { Reda031DetalhadaComponent } from './reda031-detalhada/reda031-detalhada.component';
import { MatButtonModule } from '@angular/material/button';
import { TipoSaldoPipeModule } from '@core/pipes/tipo-saldo/tipo-saldo-pipe.module';

@NgModule({
  declarations: [
    PorServicoComponent,
    PorServicoDialogComponent,
    Pacs008DetalhadaComponent,
    Pacs002DetalhadaComponent,
    Admi002DetalhadaComponent,
    Camt054DetalhadaComponent,
    XmlMensagemDialogComponent,
    HistoricoDialogComponent,
    Camt052DetalhadaComponent,
    Camt053DetalhadaComponent,
    Pibr001DetalhadaComponent,
    Pibr002DetalhadaComponent,
    Pacs004DetalhadaComponent,
    Camt060DetalhadaComponent,
    Cxm1024DetalhadaComponent,
    Reda016DetalhadaComponent,
    Reda022DetalhadaComponent,
    Camt014DetalhadaComponent,
    Admi004DetalhadaComponent,
    Reda031DetalhadaComponent,
    Reda041DetalhadaComponent,
    Reda014DetalhadaComponent,
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatTableModule,
    MatTooltipModule,
    MatDialogModule,
    MatListModule,
    MatGridListModule,
    NgxMaskModule.forRoot(),
    PrettyXMLPipeModule,
    TipoSaldoPipeModule,
    HighlightModule,
    NgxCurrencyModule,
    MatButtonModule
  ],
})
export class PorServicoModule {}
