import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { BehaviorSubject } from 'rxjs';
import * as moment from 'moment';
import { MensagemResponse, Mensagem, MensagemRejeicaoResponse } from './por-servico.model';
import { PorServicoService } from './por-servico.service';
import { PorServicoDialogComponent } from './por-servico-dialog.component';
import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import {
  distinctUntilChanged,
  switchMap,
  startWith,
  tap,
  take,
} from 'rxjs/operators';
import { SnackbarService } from '@core/services';
import { XmlMensagemDialogComponent } from './xml-mensagem-dialog/xml-mensagem-dialog.component';
import { HistoricoDialogComponent } from './historico-dialog/historico-dialog.component';
import { ISPBInstituicao } from '@app/mensageria/mensageria.model';
import { LoginService } from '@store/login';

@Component({
  selector: 'app-por-servico',
  templateUrl: './por-servico.component.html',
  styleUrls: ['./por-servico.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition(
        'expanded <=> collapsed',
        animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)'),
      ),
    ]),
  ],
})
export class PorServicoComponent {
  @Input() mensagem: MensagemResponse;

  mensagemRejeicao: MensagemRejeicaoResponse[];

  readonly expandedElement$ = new BehaviorSubject<Mensagem>(null);

  readonly relacionadas$ = this.expandedElement$.asObservable().pipe(
    distinctUntilChanged(),
    switchMap((element) =>
      this.porServicoService.getMensagensRelacionadas(element.id, element.tabelaHistorico, element.tabelaOld, element.tabelaSimples),
    ),
  );
  readonly ispbs = ISPBInstituicao;
  readonly date = new Date();
  readonly form = this.fb.group({
    servico: ['ADMI', Validators.required], // ADMI, CAMT, PACS, PIBR
    tipo: [''], // 002, 004, 008...
    idMensagem: [''],
    idFimAFim: [''],
    statusMensagem: [''],
    coMensagemRejeicao: [''],
    valorInicio: ['0.00', Validators.required],
    valorFim: ['0.00', Validators.required],
    situacao: [''],
    ispb: [''],
    tipoPagamento: [''],
    data: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
    horaInicio: ['00:00:00', [Validators.required, Validators.minLength(8)]],
    horaFim: ['23:59:59', [Validators.required, Validators.minLength(8)]],
  });
  readonly data$ = new BehaviorSubject<MensagemResponse>(null);

  readonly servicoSelecionado$ = this.form.get('servico').valueChanges.pipe(
    startWith(this.form.get('servico').value),
    tap(() => {
      this.form.get('valorInicio').setValue('0.00');
      this.form.get('valorFim').setValue('0.00');
      this.form.get('situacao').setValue('');
      this.form.get('tipo').setValue('');
      this.form.get('ispb').setValue('');
      this.form.get('idMensagem').setValue('');
      this.form.get('idFimAFim').setValue('');
      this.form.get('statusMensagem').setValue('');
      this.form.get('coMensagemRejeicao').setValue('');
      this.form.get('tipoPagamento').setValue('');

      if (this.form.get('servico').value === 'PIBR') {
        this.form.get('tipo').setValue('001');
      }
    }),
  );

  readonly tipoSelecionado$ = this.form.get('tipo').valueChanges.pipe(
    tap(() => {
      this.form.get('statusMensagem').setValue('');
      this.form.get('coMensagemRejeicao').setValue('');
      this.form.get('valorInicio').setValue('0.00');
      this.form.get('valorFim').setValue('0.00');
    }),
  );

  readonly situacaoSelecionada$ = this.form.get('situacao').valueChanges.pipe(
    tap(() => {
      if (this.form.get('situacao').value === '') {
        this.form.get('ispb').setValue('');
      }
    }),
  );

  readonly idFimAFim$ = this.form.get('idFimAFim').valueChanges.pipe(
    tap(() => {
      if (this.form.get('idFimAFim').value !== '') {
        this.form.controls['dataInicial'].setValidators(null);
        this.form.controls['horaInicio'].setValidators(null);
        this.form.controls['horaFim'].setValidators(null);
        this.form.controls['dataFinal'].setValidators(null);
      } else {
        this.form.controls['dataInicial'].setValidators([Validators.required]);
        this.form.controls['dataFinal'].setValidators([Validators.required]);
        this.form.controls['horaFim'].setValidators(Validators.required);
        this.form.controls['horaInicio'].setValidators([Validators.required]);
      }
      this.form.controls['dataFinal'].updateValueAndValidity();
      this.form.controls['dataInicial'].updateValueAndValidity();
      this.form.controls['horaInicio'].updateValueAndValidity();
      this.form.controls['horaFim'].updateValueAndValidity();
    }),
  );

  readonly idMensagem$ = this.form.get('idMensagem').valueChanges.pipe(
    tap(() => {
      if (this.form.get('idMensagem').value !== '') {
        this.form.controls['dataInicial'].setValidators(null);
        this.form.controls['horaInicio'].setValidators(null);
        this.form.controls['dataFinal'].setValidators(null);
        this.form.controls['horaFim'].setValidators(null);
      } else {
        this.form.controls['dataInicial'].setValidators([Validators.required]);
        this.form.controls['horaInicio'].setValidators([Validators.required]);
        this.form.controls['horaFim'].setValidators(Validators.required);
        this.form.controls['dataFinal'].setValidators([Validators.required]);
      }
      this.form.controls['dataFinal'].updateValueAndValidity();
      this.form.controls['horaFim'].updateValueAndValidity();
      this.form.controls['dataInicial'].updateValueAndValidity();
      this.form.controls['horaInicio'].updateValueAndValidity();
    }),
  );

  header = [];
  tipoOrdenacao = true;
  campoOrdenacao = '';
  paginaAtual = 1;
  tamanhoPagina: number;

  constructor(
    public dialog: MatDialog,
    private fb: FormBuilder,
    private porServicoService: PorServicoService,
    private snackbarService: SnackbarService,
    public loginService: LoginService
  ) {}

  getDate(ts: number) {
    return new Date(ts);
  }

  onOpenDialog(id: string, tipo: string, isTabelaHistorico: any, isTabelaOld: any, isTabelaSimples: any): void {
    if(tipo==='CXM1024') {
        this.porServicoService.getDetalheMensagemAporteSaque(id).pipe(take(1)).subscribe((detalhe) => {
          this.dialog.open(PorServicoDialogComponent, {
            data: { detalhe, tipo },
          });
        });
      } else if(tipo==='CAMT014' || tipo==='REDA041') {
        this.porServicoService.getDetalheMensagemAutomatica(id).pipe(take(1)).subscribe((detalhe) => {
          this.dialog.open(PorServicoDialogComponent, {
            data: { detalhe, tipo },
          });
        });
      } else {
        this.porServicoService.getDetalheMensagem(id, isTabelaHistorico, isTabelaOld, isTabelaSimples).pipe(take(1)).subscribe((detalhe) => {
          this.dialog.open(PorServicoDialogComponent, {
            data: { detalhe, tipo },
          });
        });
    }
  }

  onOpenDialogXml(id: string, tipo: string, isTabelaHistorico: string, coMensagemPagamento: string, isTabelaOld: string, isTabelaSimples: string): void {
    this.porServicoService.getXMLMensagem(id, tipo, isTabelaHistorico, coMensagemPagamento, isTabelaOld, isTabelaSimples).pipe(take(1)).subscribe((xml) => {
      this.dialog.open(XmlMensagemDialogComponent, {
        data: { xml, tipo },
      });
    });

  }

  openDialogHistorico(id: string, tipo: string, isTabelaHistorico: string, isTabelaOld: string, isTabelaSimples: string): void {
    if(tipo==='CAMT014' || tipo==='REDA041') {
      this.porServicoService.getHistoricoMensagemAutomatica(id).pipe(take(1)).subscribe((hist) => {
        this.dialog.open(HistoricoDialogComponent, {
          data: { hist },
          width: '800px',
        });
      });
    } else {
      this.porServicoService.getHistoricoMensagem(id, isTabelaHistorico, isTabelaOld, isTabelaSimples).pipe(take(1)).subscribe((hist) => {
        this.dialog.open(HistoricoDialogComponent, {
          data: { hist },
          width: '800px',
        });
      });
    }
  }

  reenviarContabil(id: string): void {
      this.porServicoService.reenviarContabil(id).pipe(take(1)).subscribe(() => {
        this.snackbarService.open('Lançamento gravado com sucesso!', 'success');
      });
  }

  setExpandedElement(element: Mensagem, event) {
    // evita que expanda a tabela de mensagens relacionadas sem precisar
    if (
      event.target.nodeName !== 'BUTTON' &&
      event.target.nodeName !== 'I' &&
      event.target.nodeName !== 'EM' &&
      !element.codMensagem.startsWith('CAMT05')
    ) {
      this.expandedElement$.next(
        this.expandedElement$.value === element ? null : element,
      );
    }
  }

  get horaInicio() {
    return this.form.get('horaInicio');
  }

  get horaFim() {
    return this.form.get('horaFim');
  }


  onSubmit(): void {
    switch (this.form.get('servico').value + this.form.get('tipo').value) {
      case 'PACS008':
        this.header = [
          'codMensagem',
          'idFimAFim',
          'ispb',
          'data',
          'hora',
          'valor',
          'acao',

        ];
        break;
      case 'PACS004':
        this.header = [
          'codMensagem',
          'idFimAFim',
          'ispb',
          'data',
          'hora',
          'valor',
          'acao',

        ];
        break;
      case 'PACS002':
        this.header = [
          'codMensagem',
          'idFimAFim',
          'status',
          'coMensagemRejeicao',
          'ispb',
          'data',
          'hora',
          'acao',

        ];
        break;
      case 'PACS':
        this.header = [
          'codMensagem',
          'idFimAFim',
          'status',
          'ispb',
          'data',
          'hora',
          'valor',
          'acao',
    
        ];
        break;
      case 'CXM1024':
        this.header = [
          'codMensagem',
          'idFimAFim',
          'data',
          'hora',
          'valor',
          'acao',

        ];
        break;
      default:
        this.header = [
          'codMensagem',
          'idFimAFim',
          'ispb',
          'data',
          'hora',
          'acao',
        ];
    }
    if (
      this.usaValor() &&
      this.form.get('valorInicio').value > this.form.get('valorFim').value
    ) {
      this.snackbarService.open(
        'Valor início não pode ser maior que ao valor fim.',
        'info',
      );
    } else {
  
      this.paginaAtual = 1;
      this.campoOrdenacao = 'data';
      this.porServicoService
        .getMensagens(
          moment(this.form.value.data).format('DD/MM/YYYY'),
          `${this.form.value.horaInicio}`,
          `${this.form.value.horaFim}`,
          `${this.form.value.idMensagem}`,
          `${this.form.value.idFimAFim}`,
          `${this.form.value.statusMensagem}`,
          `${this.form.value.coMensagemRejeicao}`,
          `${this.form.value.situacao}`,
          `${this.form.value.ispb}`,
          `${this.form.value.valorInicio}`,
          `${this.form.value.valorFim}`,
          `${this.form.value.tipoPagamento}`,
          `${this.form.value.servico}${this.form.value.tipo}`,
          this.campoOrdenacao,
          this.tipoOrdenacao ? 'DESC' : 'ASC',
          this.paginaAtual,
          15,
        ).pipe(take(1))
        .subscribe((mensagens) =>{
           this.data$.next(mensagens)
        });
    }
  
  }

  consultaOrdenada(campo: string) {
    this.tipoOrdenacao = !this.tipoOrdenacao;
    this.campoOrdenacao = campo;
    this.porServicoService
      .getMensagens(
        moment(this.form.value.data).format('DD/MM/YYYY'),
        `${this.form.value.horaInicio}`,
        `${this.form.value.horaFim}`,
        `${this.form.value.idMensagem}`,
        `${this.form.value.idFimAFim}`,
        `${this.form.value.statusMensagem}`,
        `${this.form.value.coMensagemRejeicao}`,
        `${this.form.value.situacao}`,
        `${this.form.value.ispb}`,
        `${this.form.value.valorInicio}`,
        `${this.form.value.valorFim}`,
        `${this.form.value.tipoPagamento}`,
        `${this.form.value.servico}${this.form.value.tipo}`,
        this.campoOrdenacao,
        this.tipoOrdenacao ? 'DESC' : 'ASC',
        this.paginaAtual,
        this.tamanhoPagina,
      ).pipe(take(1))
      .subscribe((mensagens) => this.data$.next(mensagens));
  }

  usaValor() {
    return (
      this.form.get('servico').value === 'PACS' &&
      (this.form.get('tipo').value === '004' ||
        this.form.get('tipo').value === '008')
    );
  }

  onPagination(event: PageEvent): void {
    this.paginaAtual = event.pageIndex + 1;
    this.tamanhoPagina = event.pageSize;
    this.porServicoService
      .getMensagens(
        moment(this.form.value.data).format('DD/MM/YYYY'),
        `${this.form.value.horaInicio}`,
        `${this.form.value.horaFim}`,
        `${this.form.value.idMensagem}`,
        `${this.form.value.idFimAFim}`,
        `${this.form.value.statusMensagem}`,
        `${this.form.value.coMensagemRejeicao}`,
        `${this.form.value.situacao}`,
        `${this.form.value.ispb}`,
        `${this.form.value.valorInicio}`,
        `${this.form.value.valorFim}`,
        `${this.form.value.tipoPagamento}`,
        `${this.form.value.servico}${this.form.value.tipo}`,
        this.campoOrdenacao,
        this.tipoOrdenacao ? 'DESC' : 'ASC',
        event.pageIndex + 1,
        event.pageSize,
      ).pipe(take(1))
      .subscribe((mensagens) => this.data$.next(mensagens));
  }

  consultarMensagemRejeicao(): void {
    this.porServicoService.getMensagemRejeicao().pipe().subscribe((dados ) => {
      this.mensagemRejeicao = [];
      // @ts-ignore
      this.mensagemRejeicao = dados;
    });
  }
}
