import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { DetalheReda016 } from '../por-servico.model';
import { Reda016Status, Reda016ErrorCode } from '@app/mensageria/mensageria.model';

@Component({
  selector: 'app-reda016-detalhada',
  templateUrl: './reda016-detalhada.component.html',
  styleUrls: [
    './reda016-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Reda016DetalhadaComponent {

  @Input() detalhe: DetalheReda016;

  readonly statusReda016Enum = Reda016Status;
  readonly errorReda016Enum = Reda016ErrorCode;
}
