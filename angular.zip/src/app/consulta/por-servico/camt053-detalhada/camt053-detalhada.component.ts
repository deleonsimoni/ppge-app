import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { DetalheCamt053 } from '../por-servico.model';

@Component({
  selector: 'app-camt053-detalhada',
  templateUrl: './camt053-detalhada.component.html',
  styleUrls: [
    './camt053-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Camt053DetalhadaComponent {
  @Input() detalhe: DetalheCamt053;
}
