import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { DetalheAdmi004 } from '../por-servico.model';

@Component({
  selector: 'app-admi004-detalhada',
  templateUrl: './admi004-detalhada.component.html',
  styleUrls: [
    './admi004-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Admi004DetalhadaComponent {
  @Input() detalhe: DetalheAdmi004;
}
