import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { DetalheCamt014 } from '../por-servico.model';
import { Camt014TipoParticipante, Camt014Situacao } from '@app/mensageria/mensageria.model';

@Component({
  selector: 'app-camt014-detalhada',
  templateUrl: './camt014-detalhada.component.html',
  styleUrls: [
    './camt014-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Camt014DetalhadaComponent {
  @Input() detalhe: DetalheCamt014;

  readonly tipoParticipanteEnum = Camt014TipoParticipante;
  readonly situacaoParticipanteEnum = Camt014Situacao;
}
