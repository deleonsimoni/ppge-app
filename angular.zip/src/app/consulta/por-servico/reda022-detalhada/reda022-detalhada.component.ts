import { Component, ChangeDetectionStrategy, Input } from '@angular/core';
import { DetalheReda022 } from '../por-servico.model';

@Component({
  selector: 'app-reda022-detalhada',
  templateUrl: './reda022-detalhada.component.html',
  styleUrls: [
    './reda022-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Reda022DetalhadaComponent {

  @Input() detalhe: DetalheReda022;
}
