import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { DetalheAdmi002 } from '../por-servico.model';

@Component({
  selector: 'app-admi002-detalhada',
  templateUrl: './admi002-detalhada.component.html',
  styleUrls: [
    './admi002-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Admi002DetalhadaComponent {
  @Input() detalhe: DetalheAdmi002;
}
