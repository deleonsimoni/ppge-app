import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { DetalheReda014 } from '../por-servico.model';
import { Reda014Status } from '@app/mensageria/mensageria.model';

@Component({
  selector: 'app-reda014-detalhada',
  templateUrl: './reda014-detalhada.component.html',
  styleUrls: ['./reda014-detalhada.component.scss',],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Reda014DetalhadaComponent{

  @Input() detalhe: DetalheReda014;

  readonly statusReda016Enum = Reda014Status;
}