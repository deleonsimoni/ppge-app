import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Historico } from '../por-servico.model';

@Component({
  selector: 'app-historico-dialog',
  templateUrl: './historico-dialog.component.html',
  styleUrls: ['./historico-dialog.component.scss'],
})
export class HistoricoDialogComponent {
  readonly displayedColumns = ['data', 'situacao', 'status'];

  constructor(
    public dialogRef: MatDialogRef<Historico>,
    @Inject(MAT_DIALOG_DATA) public data,
  ) {}

  getData(timeStamp: number) {
    return new Date(timeStamp);
  }
}
