import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { DetalheCamt052 } from '../por-servico.model';
import { PorServicoService } from '../por-servico.service';
import { tap } from 'rxjs/operators';
import { SnackbarService } from '@core/services';

@Component({
  selector: 'app-camt052-detalhada',
  templateUrl: './camt052-detalhada.component.html',
  styleUrls: [
    './camt052-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Camt052DetalhadaComponent {
 

  constructor(
    private porServicoService: PorServicoService,
    private snackbarService: SnackbarService,
  ) {}

  @Input() detalhe: DetalheCamt052;
  onDownloadArquivo(nomeArquivo: string, idMensagemOriginal: string){
    this.porServicoService
      .getDownloadArquivo(nomeArquivo, idMensagemOriginal)
      .pipe(
        tap(blob => {
          const a = document.createElement('a')
          const objectUrl = URL.createObjectURL(blob)
          a.href = objectUrl
          a.download = nomeArquivo + '.zip';
          a.click();
          URL.revokeObjectURL(objectUrl);
        },
        (error) => {
          this.snackbarService.open('Erro ao realizar download do arquivo!', 'error');
        },
        ),
      )
      .subscribe();
  }
}
