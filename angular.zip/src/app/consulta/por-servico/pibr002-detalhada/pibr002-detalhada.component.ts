import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { DetalhePibr002 } from '../por-servico.model';

@Component({
  selector: 'app-pibr002-detalhada',
  templateUrl: './pibr002-detalhada.component.html',
  styleUrls: [
    './pibr002-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Pibr002DetalhadaComponent {
  @Input() detalhe: DetalhePibr002;
}
