import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { DetalheCamt054 } from '../por-servico.model';

@Component({
  selector: 'app-camt054-detalhada',
  templateUrl: './camt054-detalhada.component.html',
  styleUrls: [
    './camt054-detalhada.component.scss',
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Camt054DetalhadaComponent {
  @Input() detalhe: DetalheCamt054;
}
