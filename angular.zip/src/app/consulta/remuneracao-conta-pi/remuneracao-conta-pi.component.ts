import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MAT_DATE_FORMATS } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { PageEvent } from '@angular/material/paginator';
import { ISPBInstituicao } from '@app/mensageria/mensageria.model';
import { XmlMensagemDialogComponent } from '@app/shared/components/xml-mensagem-dialog/xml-mensagem-dialog.component';
import { SnackbarService } from '@core/services';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';
import { take, tap } from 'rxjs/operators';
import {  MensagemResponse } from './remuneracao-conta-pi.model';
import { RemuneracaoContaPiService } from './remuneracao-conta-pi.service';

export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-remuneracao-conta-pi',
  templateUrl: './remuneracao-conta-pi.component.html',
  styleUrls: ['./remuneracao-conta-pi.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition(
        'expanded <=> collapsed',
        animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)'),
      ),
    ]),
  ],
  providers: [
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS}
  ]
})
export class RemuneracaoContaPiComponent {
  date = new Date();
  header = ['data', 'valorEfetivoRemuneracao', 'parcelaSaldoSujeitoRemuneracao', 'valorPercentualSaldosMoedaEletronica', 'valorPercentualMediaVsr', 'acao'];
  footer = ['total','totalValorEfetivoRemuneracao','totalParcelaSaldoSujeitoRemuneracao','totalValorPercentualSaldosMoedaEletronica','totalValorPercentualMediaVsr', 'empty'];
  buscaRealizada = false;
  loading = false;
  dataConsultada = '';
  paginaAtual = 1;
  tamanhoPagina: number;
  enviandoLancamento = false;

  readonly ispbs = ISPBInstituicao;

  constructor(
    public dialog: MatDialog,
    private fb: FormBuilder,
    private remuneracaoContaPiService: RemuneracaoContaPiService,
    private snackbarService: SnackbarService,
  ) {}

  readonly form = this.fb.group({
    dataMes: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
      ]),
      Validators.required,
    ],
  });
  readonly data$ = new BehaviorSubject<MensagemResponse>(null);
  
  public getMaxTimeSelected() {
    return moment(new Date());
  }

  public closeDatePicker(eventData: any, dp?:any) {
    this.form.get('dataMes').setValue(eventData);
    dp.close();    
  }
  
  onPagination(event: PageEvent): void {
    this.paginaAtual = event.pageIndex + 1;
    this.tamanhoPagina = event.pageSize;
    this.remuneracaoContaPiService
      .getMensagens(
        this.dataConsultada, //
        this.paginaAtual,
        this.tamanhoPagina,
      ).pipe(take(1))
      .subscribe((mensagens) => {
        this.data$.next(mensagens);
        this.buscaRealizada = true;
      });
  }
  onOpenDialogXml(id: string): void {
    this.remuneracaoContaPiService.getXMLMensagem(id).pipe(take(1)).subscribe((xml) => {
      this.dialog.open(XmlMensagemDialogComponent, {
        data: { xml, tipo:"Camt53" },
      });
    });
  }

  reenviarLancamento(id: string) {
    this.enviandoLancamento = true;
    this.remuneracaoContaPiService.reenviarLancamento(id).subscribe((res) => {
      this.snackbarService.open('Reenviado com sucesso!', 'success');
      this.enviandoLancamento = false;
    },
    (err) => {
      this.enviandoLancamento = false;
    })
  }

  onSubmit(): void {
    
    this.paginaAtual = 1;
    
    this.remuneracaoContaPiService
      .getMensagens(
        moment(this.form.value.dataMes).format("MM/yyyy"), //
        this.paginaAtual,
        15,
      ).pipe(take(1))
      .subscribe((mensagens) => {
        this.data$.next(mensagens);
        this.buscaRealizada = mensagens != null;
        this.dataConsultada = moment(this.form.value.dataMes).format("MM/yyyy");
      });

  }

  public exportarDados() {
    this.loading = true;
    this.remuneracaoContaPiService
        .downloadArquivo(this.dataConsultada).pipe(
          tap(blob => {
            const a = document.createElement('a')
            const objectUrl = URL.createObjectURL(blob)
            a.href = objectUrl;
            a.download = 'RemuneracaoContaPI-mes' + this.dataConsultada + '.csv';
            a.click();
            URL.revokeObjectURL(objectUrl);
            this.loading = false;
          },
          (error) => {
            this.loading = false;
            this.snackbarService.open('Erro ao realizar download do arquivo!', 'error');
          },
          ),
        ).subscribe();
  }

  public exportarDadosPDF() {
    this.loading = true;
    this.remuneracaoContaPiService
        .downloadArquivoPDF(this.dataConsultada).pipe(
          tap(blob => {
            const a = document.createElement('a')
            const objectUrl = URL.createObjectURL(blob)
            a.href = objectUrl;
            a.download = 'RemuneracaoContaPI-mes' + this.dataConsultada + '.pdf';
            a.click();
            URL.revokeObjectURL(objectUrl);
            this.loading = false;
          },
          (error) => {
            this.loading = false;
            this.snackbarService.open('Erro ao realizar download do arquivo!', 'error');
          },
          ),
        ).subscribe();
  }

}
