import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MensagemResponse } from './remuneracao-conta-pi.model';
import { environment } from '@env/environment';
import { catchError, map } from 'rxjs/operators';
import { SnackbarService } from '@core/services';

@Injectable({
  providedIn: 'root',
})
export class RemuneracaoContaPiService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_CONSULTA = `${this.URL_PIX_GESTAO}/mensagem-remuneracao/consulta-remuneracao`;

  constructor(private http: HttpClient, private datePipe: DatePipe, private snackbarService: SnackbarService) {}

  getMensagens(
    dataMonth: string,
    page: number = 1,
    tamanhoPagina: number = 15,
  ): Observable<MensagemResponse> {
    let params = new HttpParams();

    if (dataMonth) {
      params = params.set('data', dataMonth);
    }

    params = params
      .set('pagina', page.toString())
      .set('tamanhoPagina', tamanhoPagina.toString());

    return this.http.get<MensagemResponse>(this.URL_CONSULTA, { params })
      .pipe(
        map((response) => {
          if (response.totalRegistros <= 0) {
            this.snackbarService.open("Nenhum Registro Encontrado.",'error');
            return null;
          } else {
            return response;
          }
        }),
        catchError((error) => {
          let errorMsg: string;
          errorMsg = this.getServerErrorMessage(error);
          this.snackbarService.open(errorMsg,'error');
          throw errorMsg;
        })
      );
  }

  getXMLMensagem(id: string) {
    return this.http.get(`${this.URL_CONSULTA}/${id}/xml`, { responseType: 'text' });
  }

  reenviarLancamento(id: string) {
    return this.http.post(`${this.URL_CONSULTA}/${id}/reenviar-lancamento-contabil`, { responseType: 'text' }).pipe(
      catchError((error) => {
        this.snackbarService.open(error.error.errorMessage,'error');
        throw error.error.errorMessage;
      })
    );
  }

  public downloadArquivo(data: string): Observable<any> {
    let params = new HttpParams();
    params = params.set('data', data);
    return this.http.get<any>(`${this.URL_CONSULTA}/download/arquivo`, { params, responseType: 'blob' as 'json' });
  }

  public downloadArquivoPDF(data: string) {
    let params = new HttpParams();
    params = params.set('data', data);
    return this.http.get<any>(`${this.URL_CONSULTA}/download/pdf`, { params, responseType: 'blob' as 'json' });
  }

  private getServerErrorMessage(error: HttpErrorResponse): string {
    const statusErrors = {
      404: `Not Found.`,
      403: `Access Denied.`,
      500: `Internal Server Error.`,
    }
    return statusErrors[error.status] ? statusErrors[error.status] : `Unknown Server Error.`;
  }

}
