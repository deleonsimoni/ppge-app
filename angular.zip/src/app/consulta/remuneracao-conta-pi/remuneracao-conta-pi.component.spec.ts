import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';

import { RemuneracaoContaPiComponent } from './remuneracao-conta-pi.component';
import { RemuneracaoContaPiService } from './remuneracao-conta-pi.service';

describe('RemuneracaoContaPiComponent', () => {
  let component: RemuneracaoContaPiComponent;
  let fixture: ComponentFixture<RemuneracaoContaPiComponent>;

  const matDialogStup: Partial<MatDialog> = {};
  const formBuilderStub = {
    group: (_params: any) => {
      return <FormGroup>{};
    }
  };
  const serviceStub: Partial<RemuneracaoContaPiService> = {};

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        
      ],
      providers: [
        {
          provide: MatDialog,
          useValue: matDialogStup
        },
        {
          provide: FormBuilder,
          useValue: formBuilderStub
        },
        {
          provide: RemuneracaoContaPiService,
          useValue: serviceStub
        }
      ],
      declarations: [ RemuneracaoContaPiComponent ],
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RemuneracaoContaPiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
