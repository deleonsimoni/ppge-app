import { DatePipe } from "@angular/common";
import { HttpClient } from "@angular/common/http";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { TestBed } from "@angular/core/testing";
import { of } from "rxjs";
import { MensagemResponse } from "./por-status.model";
import { PorStatusService } from "./por-status.service";

describe('PorStatusService', () => {
    let service: PorStatusService;
    let http: HttpClient;
    let spyGetHttp: jasmine.Spy;
    let mensagemResponse: MensagemResponse;
    // let http: HttpClient;

    const datePipeStub: Partial<DatePipe> = {};

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                {
                    provide: DatePipe,
                    useValue: datePipeStub
                }
            ],
            imports: [
                HttpClientTestingModule
            ]
        });
        service = TestBed.inject(PorStatusService);
        http = TestBed.inject(HttpClient);

        spyGetHttp = spyOn(http, 'get');

        mensagemResponse = generateMensagemResponse();

    });

    it('deve estar criado', () => {
        expect(service).toBeTruthy();
    });

    it('deve retornar as mensagens', () => {
        const spyReturnMensagemResponse: MensagemResponse = generateMensagemResponse();
        spyGetHttp.and.returnValue(of(spyReturnMensagemResponse));
        
        const res = service.getMensagens(
            '10/10/22 13:20:20',
            '11/11/22 13:20:20',
            'idMensagem',
            'idFimAFim',
            ['statusMensagem'],
            'coMensagemRejeicao',
            'situacao',
            'ispb',
            'valorInicio',
            'valorFim',
            'codigo',
            'campoOrdenado',
            'tipoOrdenacao',
        );
        res.subscribe((data) => {
            expect(data).toEqual(mensagemResponse);
        })
    });

    const generateMensagemResponse = () => {
        return <MensagemResponse> {
            dados: [
                {
                    codMensagem: 'codMensagem',
                    idFimAFim: 'idFimAFim',
                    ispbOrigem: 'ispbOrigem',
                    data: '10/10/22',
                    hora: '13:20:20',
                    status: 'status',
                    motivoErro: 'motivoErro',
                    icMensagemEnviada: 'icMensagemEnviada',
                    valor: 24.4,
                }
            ],
            pagina: 10,
            paginas: 11,
            tamanhoPagina: 12,
            totalRegistros: 13,
        };
    }
});