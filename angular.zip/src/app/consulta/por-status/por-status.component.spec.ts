import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AbstractControl, FormBuilder, FormGroup } from '@angular/forms';
import { of } from 'rxjs';

import { PorStatusComponent } from './por-status.component';
import { PorStatusService } from './por-status.service';

describe('PorStatusComponent', () => {
  let component: PorStatusComponent;
  let fixture: ComponentFixture<PorStatusComponent>;

  const formGroupStup: Partial<FormGroup> = {
    get: (_params: any) => {
      return <AbstractControl>{
        valueChanges: of({}),
        setValue: (value: any, options?: Object) => {},
        hasError: (_params: any) => {return false}
      };
    }
  }

  const formBuilderStub = {
    group: (_params: any) => {
      return formGroupStup;
    },
    
  };
  const serviceStub: Partial<PorStatusService> = {};

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers: [
        {
          provide: FormBuilder,
          useValue: formBuilderStub
        },
        {
          provide: PorStatusService,
          useValue: serviceStub
        }
      ],
      declarations: [ PorStatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PorStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
