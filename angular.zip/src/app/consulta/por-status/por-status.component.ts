import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { PageEvent } from '@angular/material/paginator';
import { ISPBInstituicao } from '@app/mensageria/mensageria.model';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import {  MensagemResponse, EnumStatusMensagem } from './por-status.model';
import { PorStatusService } from './por-status.service';

@Component({
  selector: 'app-por-status',
  templateUrl: './por-status.component.html',
  styleUrls: ['./por-status.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition(
        'expanded <=> collapsed',
        animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)'),
      ),
    ]),
  ],
})
export class PorStatusComponent {
  date = new Date();
  header = [];
  footer = ['total'];
  tipoOrdenacao = true;
  campoOrdenacao = '';
  paginaAtual = 1;
  tamanhoPagina: number;
  checkAll = false;
  showButtonResolve = false;
  textButtonResolve = "";

  readonly ispbs = ISPBInstituicao;

  constructor(
    private fb: FormBuilder,
    private porStatusService: PorStatusService,
  ) {}

  readonly form = this.fb.group({
    servico: ['PACS002', Validators.required],
    statusMensagem: ['NB'],
    situacao: ['E', Validators.nullValidator],
    dataInicial: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
    horaInicio: ['00:00:00'],
    horaFim: ['23:59:59'],
  });
  readonly data$ = new BehaviorSubject<MensagemResponse>(null);

  readonly changesSituacao$ = this.form.get('situacao').valueChanges.subscribe(() => {
    if(this.form.get('servico').value == "PACS002") {
      this.form.get('statusMensagem').setValue(this.form.get('situacao').value === 'E' ? 'NB' : 'AI');
    } else {
      this.form.get('statusMensagem').setValue('NC');
    }
  });

  readonly changesMensagem$ = this.form.get('servico').valueChanges.subscribe(() => {
    console.log(this.form.get('servico').value)
    if(this.form.get('servico').value == "PACS002") {
      this.form.get('situacao').setValue('E');
      this.form.get('statusMensagem').setValue('NB');
    } else {
      this.form.get('statusMensagem').setValue('NC');
      this.form.get('situacao').setValue('E');
    }
  });

  get horaInicio() {
    return this.form.get('horaInicio');
  }

  get horaFim() {
    return this.form.get('horaFim');
  }

  private de(): string {
    if (this.form.get('dataInicial').value) {
      const date: moment.Moment = this.form.get('dataInicial').value;
      const horaI = this.horaInicio.value ? this.horaInicio.value : '00:00:00';
      const horario = horaI.split(':');
      return new Date(
        date.year(),
        date.month(),
        date.date(),
        horario[0],
        horario[1],
        horario[2],
      ).toString();
    } else {
      return '';
    }
  }

  public getDescricaoStatusMensagem(status: string) {
    return EnumStatusMensagem[status];
  }

  private ate(): string {
    if (this.form.get('dataInicial').value) {
      const date: moment.Moment = this.form.get('dataInicial').value;
      const horaF = this.horaFim.value ? this.horaFim.value : '23:59:59';
      const horario = horaF.split(':');
      return new Date(
        date.year(),
        date.month(),
        date.date(),
        horario[0],
        horario[1],
        horario[2],
      ).toString();
    } else {
      return '';
    }
  }

  onPagination(event: PageEvent): void {
    this.paginaAtual = event.pageIndex + 1;
    this.tamanhoPagina = event.pageSize;
    this.porStatusService
      .getMensagens(
        this.de(),
        this.ate(),
        null,
        null,
        `${this.form.value.statusMensagem}`,
        null,
        `${this.form.value.situacao}`,
        null,
        null,
        null,
        `${this.form.value.servico}`,
        this.campoOrdenacao,
        this.tipoOrdenacao ? 'DESC' : 'ASC',
        event.pageIndex + 1,
        event.pageSize,
      ).pipe(take(1))
      .subscribe((mensagens) => {
        this.checkAll = false;
        this.data$.next(mensagens);
      });
  }

  onSubmit(): void {
    let headersChoose = [
        'codMensagem',
        'idFimAFim',
        'icMensagemEnviada',
        'data',
        'hora',
        'valor',
        'motivoErro',
      ]

    if(this.form.value.statusMensagem == 'NC' || this.form.value.statusMensagem == 'AI')
      headersChoose.push('selecao');

    this.header = headersChoose;

    this.paginaAtual = 1;
    this.campoOrdenacao = 'data';
    this.porStatusService
      .getMensagens(
        this.de(),
        this.ate(),
        null,
        null,
        `${this.form.value.statusMensagem}`,
        null,
        `${this.form.value.situacao}`,
        null,
        null,
        null,
        `${this.form.value.servico}`, 
        this.campoOrdenacao,
        this.tipoOrdenacao ? 'DESC' : 'ASC',
        this.paginaAtual,
        15,
      ).pipe(take(1))
      .subscribe((mensagens) => {
        console.log(mensagens)
        this.checkAll = false;
        this.data$.next(mensagens);
        this.showButtonResolve = mensagens != null && (this.form.value.statusMensagem == 'NC' || this.form.value.statusMensagem == 'AI');
        this.textButtonResolve = this.form.value.statusMensagem == 'AI' ? "Enviar selecionadas para o Contábil" : "Resolver selecionados por CAMT";
      });

  }

  consultaOrdenada(campo: string) {
    this.tipoOrdenacao = !this.tipoOrdenacao;
    this.campoOrdenacao = campo;
    this.porStatusService
      .getMensagens(
        this.de(),
        this.ate(),
        null,
        null,
        `${this.form.value.statusMensagem}`,
        null,
        `${this.form.value.situacao}`,
        null,
        null,
        null,
        `${this.form.value.servico}`,
        this.campoOrdenacao,
        this.tipoOrdenacao ? 'DESC' : 'ASC',
        this.paginaAtual,
        15,
      ).pipe(take(1))
      .subscribe((mensagens) => {
        this.checkAll = false;
        this.data$.next(mensagens);
      });
  }

  resolverMensagemPorCamt() {
    let listEndToEnd = [];
    this.data$.pipe(take(1)).subscribe(e => {
      e.dados.forEach(fe => {
        const newItem = {idEndToEnd: fe.idFimAFim, situacao: 0, solicitarBacen: false, isSalveConsulta: false}
        if(fe.checked && !listEndToEnd.find(element => element.idEndToEnd === fe.idFimAFim)) {
          listEndToEnd.push(newItem);
        }
      })
      this.porStatusService.resolverMensagemPorCamt(listEndToEnd).pipe(take(1)).subscribe();
    })
  }

  toggleSelect(event, checkTodos = false, index = null) {
    if(checkTodos) this.checkAll = event.target.checked;

    this.data$.pipe(take(1)).subscribe(e => {
      if(checkTodos) e.dados.forEach(fe => fe.checked = event.target.checked);
      else e.dados[index].checked = event.target.checked;
    });
  }


}
