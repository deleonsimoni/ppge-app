import { Injectable } from '@angular/core';
import { DatePipe } from '@angular/common';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { MensagemResponse } from './por-status.model';
import { environment } from '@env/environment';
import { catchError, map } from 'rxjs/operators';
import { SnackbarService } from '@core/services';

@Injectable({
  providedIn: 'root',
})
export class PorStatusService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_CONSULTA = `${this.URL_PIX_GESTAO}/mensagens/consulta-mensagens-status`;
  private readonly URL_RESOLVE_MANUAL = `${this.URL_PIX_GESTAO}/mensagens/validacao-pendencia-manual`;

  constructor(private http: HttpClient, private datePipe: DatePipe, private snackbarService: SnackbarService) {}

  resolverMensagemPorCamt(listEndToEnd) {
    if(listEndToEnd.length) {
      return this.http.post(this.URL_RESOLVE_MANUAL, listEndToEnd).pipe(
        map((response) => {
            this.snackbarService.open("Enviado com sucesso.",'success');
        }),
        catchError((error) => {
          let errorMsg: string = this.getServerErrorMessage(error);
          this.snackbarService.open(errorMsg,'error');
          throw errorMsg;
        })
      )
    } else {
      this.snackbarService.open('Nenhuma mensagem selecionada.','error');
    }
  }

  getMensagens(
    horaInicio: string,
    horaFim: string,
    idMensagem: string,
    idFimAFim: string,
    statusMensagem: string,
    coMensagemRejeicao: string,
    situacao: string,
    ispb: string,
    valorInicio: string,
    valorFim: string,
    codigo: string,
    campoOrdenado: string,
    tipoOrdenacao: string,
    page: number = 1,
    tamanhoPagina: number = 15,
  ): Observable<MensagemResponse> {

    let params = new HttpParams();

    if (campoOrdenado && tipoOrdenacao) {
      params = params.set('campoOrdenado', campoOrdenado);
      params = params.set('tipoOrdenacao', tipoOrdenacao);
    }

    if (horaInicio) {
      params = params.set('horaInicio', horaInicio);
    }
    if (horaFim) {
      params = params.set('horaFim', horaFim);
    }
    if (idMensagem) {
      params = params.set('idMensagem', idMensagem);
    }

    if (idFimAFim) {
      params = params.set('idFimAFim', idFimAFim);
    }

    if (statusMensagem) {
      params = params.set('statusMensagem', statusMensagem);
    }

    if (coMensagemRejeicao) {
      params = params.set('coMensagemRejeicao', coMensagemRejeicao);
    }

    if (situacao) {
      params = params.set('situacaoMensagem', situacao);
    }
    if (ispb) {
      params = params.set('ispb', ispb);
    }
    if ((valorInicio && valorFim) && (codigo === 'PACS004' || codigo === 'PACS008')) {
      params = params.set('valorInicio', valorInicio);
      params = params.set('valorFim', valorFim);
    }
    if (codigo) {
      params = params.set('codigo', codigo);
    }

    params = params
      .set('pagina', page.toString())
      .set('tamanhoPagina', tamanhoPagina.toString());

    return this.http.get<MensagemResponse>(this.URL_CONSULTA, { params })
      .pipe(
        map((response) => {
          if (response.totalRegistros <= 0) {
            this.snackbarService.open("Nenhum Registro Encontrado.",'error');
          } else {
            return response;
          }
        }),
        catchError((error) => {
          let errorMsg: string;
          errorMsg = this.getServerErrorMessage(error);
          this.snackbarService.open(errorMsg,'error');
          throw errorMsg;
        })
      );
  }

  private getServerErrorMessage(error: HttpErrorResponse): string {
    const statusErrors = {
      404: `Not Found.`,
      403: `Access Denied.`,
      500: `Internal Server Error.`,
    }
    return statusErrors[error.status] ? statusErrors[error.status] : `Unknown Server Error.`;
  }

}
