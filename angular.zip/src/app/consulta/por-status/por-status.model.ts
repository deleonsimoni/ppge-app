export interface MensagemResponse {
  dados: Mensagem[];
  pagina: number;
  paginas: number;
  tamanhoPagina: number;
  totalRegistros: number;
}

export interface Mensagem {
  codMensagem: string;
  idFimAFim: string;
  ispbOrigem: string;
  data: string;
  hora: string;
  status: string;
  motivoErro: string;
  icMensagemEnviada: string;
  valor: number;
  checked?: boolean;
}

export const allStatusErroByMessage = {
  PACS004: {
    E: ['NB', 'NC'],
    R: ['NS'],
    ALL: ['NB', 'NC', 'NS']
  },
  PACS008: {
    E: ['NB', 'NC'],
    R: ['NS'],
    ALL: ['NB', 'NC', 'NS']
  },
  PACS002: {
    E: ['AG', 'AH'],
    R: ['AA', 'AB', 'AC', 'AD', 'AE', 'AF'],
    ALL: ['AA', 'AB', 'AC', 'AD', 'AE', 'AF', 'AG', 'AH']
  },
}

export enum EnumStatusMensagem {
  "ES" = "Encaminhado ao SISPI",
	"RS" = "Recebida do SISPI",
	"RB" = "Recebida do BACEN",
	"EB" = "Enviado ao BACEN",
	"EC" = "Sensibilizado na conta da Reserva",
	"NP" = "Sem Pacs002 ACSP",
	"NC" = "Sem Pacs002 ACSC",
	"NB" = "Não enviado ao Bacen",
	"NI" = "Idempotencia não salvo",
  "NS" = "Não enviado para fila do SISPI",
  "AA" = "PACS002 ACSP recebida e não enviada ao SISPI",
  "AB" = "PACS002 ACCC recebida e não enviada ao SISPI",
  "AC" = "PACS002 ACCC enviada ao SISPI e não sensibilizado saldo",
  "AD" = "PACS002 ACSC recebida e não enviada ao SISPI",
  "AE" = "PACS002 ACSC enviada ao SISPI e não sensibilizado saldo",
  "AF" = "Pacs002 RJCT recebida do BACEN e não enviada ao SISPI",
	"AG" = "Pacs002 ACSP recebida do SISPI e não enviada ao Bacen",
	"AH" = "Pacs002 RJCT recebida do SISPI e não enviada ao Bacen",
} 