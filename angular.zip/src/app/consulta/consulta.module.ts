import { PorParticipantePixModule } from './por-participante-pix/por-participante-pix.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConsultaRoutingModule } from './consulta-routing.module';
import { PorServicoModule } from './por-servico/por-servico.module';
import { PorStatusModule } from './por-status/por-status.module';
import { RemuneracaoContaPiModule } from './remuneracao-conta-pi/remuneracao-conta-pi.module';

@NgModule({
  imports: [CommonModule, ConsultaRoutingModule, PorServicoModule, PorStatusModule, PorParticipantePixModule, RemuneracaoContaPiModule],
})
export class ConsultaModule {}
