import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MensageriaRoutingModule } from './mensageria-routing.module';
import { EnviarModule } from './enviar/enviar.module';

@NgModule({
  imports: [CommonModule, MensageriaRoutingModule, EnviarModule],
})
export class MensageriaModule {}
