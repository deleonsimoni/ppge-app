import { DetalheAdmi002, DetalheCamt052, DetalheCamt053, DetalheCamt054, DetalheCamt060, DetalhePacs002, DetalhePacs004, DetalhePacs008, DetalhePibr001, DetalhePibr002, DetalheReda016, DetalheReda022, DetalheReda014, DetalheReda031 } from '@app/consulta/por-servico/por-servico.model';

export interface MensagemResponse {
  nuMensagemBacen: number;
  tipoMensagemXml: {
    nuTipoMensagemBacen: number;
    sgMensagemBacen: string;
  };
  coMensagemBacen: string;
  deConteudoMensagemXml: string;
  tsInclusaoMensagemBacen: number;
  edLinkProximaRequisicao: string;
  icMensagemEnviada: string;
  coFimAfimMensagem: string;
  coPrtloRcbmoMensagemEnvda: string;
}

export interface Mensagem {
  id: string;
  ispb: string;
  tipo:
    | 'ADMI.002'
    | 'CAMT.052'
    | 'CAMT.053'
    | 'CAMT.054'
    | 'CAMT.060'
    | 'PACS.002'
    | 'PACS.004'
    | 'PACS.008'
    | 'PIBR.001'
    | 'PIBR.002';
  xml: string;
  date: string;
}

export interface LancamentoCamt054 {
  creditoOuDebito: 'CRDT' | 'DBIT';
  valor: number;
  situacao: 'BOOK' | 'INFO' | Status;
  dataContabil?: string;
  idFimAFim: string;
  idInstrucao?: string;
  idConciliacaoRecebedor?: string;
  numeroControleSTR?: string;
  pagador?: Usuario;
  recebedor?: Usuario;
  informacoesEntreUsuarios?: string;
  codigoDevolucao?: Devolucao;
  motivoDevolucao?: string;
  error?: {
    code: ReasonCode;
    info?: string;
  };
}


export interface Usuario {
  nome?: string;
  agencia: string;
  tipoConta: TipoConta;
  conta: string;
  ispb: string;
  inscricao: string;
  ispbParticipante?: string;
  cpfCnpj?: string;
}


export interface XmlAdmi002 {
  Envelope: {
    Document: {
      'admi.002.001.01': {
        Rsn: {
          RjctgPtyRsn: string;
          ErrorLocation?: string;
          RsnDesc?: string;
          AddtlData?: string;
        };
      };
    };
  };
}

export interface XmlCamt052 {
  Envelope: {
    Document: {
      BkToCstmrAcctRpt: {
        Rpt: {
          TxsSummry: {
            TtlNtries: {
              NbOfNtries: number;
            };
          };
          AddtlRptInf: string;
        };
      };
    };
  };
}

export interface XmlCamt053 {
  Envelope: {
    Document: {
      BkToCstmrStmt: {
        Stmt: {
          Bal: {
            Tp: {
              CdOrPrtry: {
                Prtry: 'SADP' | 'SABK';
              };
            };
            Amt: number;
            Dt: {
              DtTm: string;
            };
          }[];
        };
      };
    };
  };
}

export interface XmlCamt054 {
  Envelope: {
    Document: {
      BkToCstmrDbtCdtNtfctn: {
        Ntfctn: {
          Ntry: {
            Amt: number;
            CdtDbtInd: 'CRDT' | 'DBIT';
            Sts: {
              Cd: 'BOOK' | 'INFO' | Status;
            };
            NtryDtls: {
              TxDtls: {
                Refs: {
                  EndToEndId: string;
                  InstrId?: string;
                  ClrSysRef?: string;
                  TxId?: string;
                };
                RltdPties: {
                  Dbtr: {
                    Pty: {
                      Nm: string;
                      Id: {
                        PrvtId: {
                          Othr: {
                            Id: string;
                          };
                        };
                      };
                    };
                  };
                  DbtrAcct: {
                    Id: {
                      Othr: {
                        Id: string;
                        Issr: string;
                      };
                    };
                    Tp: {
                      Cd: TipoConta;
                    };
                  };
                  Cdtr: {
                    Pty: {
                      Id: {
                        PrvtId: {
                          Othr: {
                            Id: string;
                          };
                        };
                      };
                    };
                  };
                  CdtrAcct: {
                    Id: {
                      Othr: {
                        Id: string;
                        Issr: string;
                      };
                    };
                    Tp: {
                      Cd: TipoConta;
                    };
                    Prxy?: {
                      Id: string;
                    };
                  };
                };
                RltdAgts: {
                  DbtrAgt: {
                    FinInstnId: {
                      ClrSysMmbId: {
                        MmbId: string;
                      };
                    };
                  };
                  CdtrAgt: {
                    FinInstnId: {
                      ClrSysMmbId: {
                        MmbId: string;
                      };
                    };
                  };
                };
                RmtInf?: {
                  Ustrd: string;
                };
                RtrInf?: {
                  Rsn: {
                    Cd: Devolucao;
                  };
                  AddtlInf?: string;
                };
              };
            };
            AddtlNtryInf?: ReasonCode;
          }[];
          AddtlNtfctnInf?: string;
        };
      };
    };
  };
}

export interface XmlCamt060 {
  Envelope: {
    Document: {
      AcctRptgReq: {
        RptgReq: {
          Id?: string;
          ReqdMsgNmId: string;
          RptgPrd?: {
            FrToDt: {
              FrDt: string;
              ToDt?: string;
            };
            FrToTm?: {
              FrTm: string;
              ToTm?: string;
            };
          };
        };
      };
    };
  };
}

export interface XmlPacs002 {
  Envelope: {
    Document: {
      FIToFIPmtStsRpt: {
        TxInfAndSts: {
          TxSts: Status;
          StsRsnInf?: {
            Rsn: {
              Cd: ReasonCode;
            };
            AddtlInf?: string;
          };
        };
      };
    };
  };
}

export interface XmlPacs004 {
  Envelope: {
    Document: {
      PmtRtr: {
        TxInf: {
          RtrId: string;
          OrgnlEndToEndId: string;
          RtrdIntrBkSttlmAmt: number;
          RtrRsnInf: {
            Rsn: {
              Cd: Devolucao;
            };
            AddtlInf?: string;
          };
          OrgnlTxRef: {
            RmtInf?: {
              Ustrd: string;
            };
            DbtrAgt: {
              FinInstnId: {
                ClrSysMmbId: {
                  MmbId: string;
                };
              };
            };
            CdtrAgt: {
              FinInstnId: {
                ClrSysMmbId: {
                  MmbId: string;
                };
              };
            };
          };
        };
      };
    };
  };
}

export interface XmlPacs008 {
  Envelope: {
    Document: {
      FIToFICstmrCdtTrf: {
        CdtTrfTxInf: {
          PmtId: {
            EndToEndId: string;
          };
          IntrBkSttlmAmt: number;
          Dbtr: {
            Nm: string;
            Id: {
              PrvtId: {
                Othr: {
                  Id: string;
                };
              };
            };
          };
          DbtrAcct: {
            Id: {
              Othr: {
                Id: string;
                Issr: string;
              };
            };
            Tp: {
              Cd: string;
            };
          };
          DbtrAgt: {
            FinInstnId: {
              ClrSysMmbId: {
                MmbId: string;
              };
            };
          };
          CdtrAgt: {
            FinInstnId: {
              ClrSysMmbId: {
                MmbId: string;
              };
            };
          };
          Cdtr: {
            Id: {
              PrvtId: {
                Othr: {
                  Id: string;
                };
              };
            };
          };
          CdtrAcct: {
            Id: {
              Othr: {
                Id: string;
                Issr: string;
              };
            };
            Tp: {
              Cd: string;
            };
          };
          RmtInf?: {
            Ustrd: string;
          };
        };
      };
    };
  };
}

export interface XmlPibr001 {
  Envelope: {
    Document: {
      EchoReq: {
        EchoTxInf: {
          Data: string;
        };
      };
    };
  };
}

export interface XmlPibr002 {
  Envelope: {
    Document: {
      EchoRpt: {
        EchoTxInf: {
          OrgnlData: string;
        };
      };
    };
  };
}


export type DetalheMensagemUnion =
  | DetalheAdmi002
  | DetalheCamt052
  | DetalheCamt053
  | DetalheCamt054
  | DetalheCamt060
  | DetalhePacs002
  | DetalhePacs004
  | DetalhePacs008
  | DetalhePibr001
  | DetalhePibr002
  | DetalheReda014
  | DetalheReda016
  | DetalheReda022
  | DetalheReda031;


export enum ISPB {
  'BACEN' = '00038166',
  'CAIXA' = '00360305',
}

// https://www.bcb.gov.br/pom/spb/estatistica/port/ASTR003.pdf
// Documento ASTR003.pdf atualizado em 01/06/2020
// ISPBs consultados em 02/06/2020
export const ISPBInstituicao = {
  '00000000': 'BCO DO BRASIL S.A.',
  '00000208': 'BRB - BCO DE BRASILIA S.A.',
  '00038121': 'Selic',
  '00038166': 'Bacen',
  '00250699': 'AGK CC S.A.',
  '00315557': 'UNICRED',
  '00360305': 'CAIXA ECONOMICA FEDERAL',
  '00394460': 'STN',
  '00416968': 'BANCO INTER',
  '00517645': 'BCO RIBEIRAO PRETO S.A.',
  '00556603': 'BANCO BARI S.A.',
  '00558456': 'BCO CETELEM S.A.',
  '00795423': 'BANCO SEMEAR',
  '00806535': 'PLANNER CV S.A.',
  '00997185': 'BCO B3 S.A.',
  '01023570': 'BCO RABOBANK INTL BRASIL S.A.',
  '01073966': 'CCR DE ABELARDO LUZ',
  '01181521': 'BCO COOPERATIVO SICREDI S.A.',
  '01330387': 'CREHNOR LARANJEIRAS',
  '01522368': 'BCO BNP PARIBAS BRASIL S A',
  '01634601': 'CCCM UNICRED CENTRAL RS',
  '01701201': 'KIRTON BANK',
  '01800019': 'PORTOCRED S.A. - CFI',
  '02038232': 'BANCOOB',
  '02318507': 'BCO KEB HANA DO BRASIL S.A.',
  '02332886': 'XP INVESTIMENTOS CCTVM S/A',
  '02398976': 'UNIPRIME NORTE DO PARANÁ - CC',
  '02685483': 'CM CAPITAL MARKETS CCTVM LTDA',
  '02801938': 'BCO MORGAN STANLEY S.A.',
  '02819125': 'UBS BRASIL CCTVM S.A.',
  '02992317': 'TREVISO CC S.A.',
  '02992335': 'CIP Siloc',
  '03012230': 'HIPERCARD BM S.A.',
  '03017677': 'BCO. J.SAFRA S.A.',
  '03046391': 'UNIPRIME CENTRAL CCC LTDA.',
  '03311443': 'PARATI - CFI S.A.',
  '03323840': 'BCO ALFA S.A.',
  '03502968': 'PI DTVM S.A.',
  '03532415': 'BCO ABN AMRO S.A.',
  '03609817': 'BCO CARGILL S.A.',
  '03751794': 'TERRA INVESTIMENTOS DTVM',
  '03973814': 'SERVICOOP',
  '04062902': 'VISION S.A. CC',
  '04184779': 'BANCO BRADESCARD',
  '04257795': 'NOVA FUTURA CTVM LTDA.',
  '04332281': 'GOLDMAN SACHS DO BRASIL BM S.A',
  '04391007': 'CIP Sitraf',
  '04632856': 'CREDISIS CENTRAL DE COOPERATIVAS DE CRÉDITO LTDA.',
  '04715685': 'SICOOB CREDITRAN',
  '04814563': 'SOROCRED CFI S.A.',
  '04866275': 'BANCO INBURSA',
  '04902979': 'BCO DA AMAZONIA S.A.',
  '04913129': 'CONFIDENCE CC S.A.',
  '04913711': 'BCO DO EST. DO PA S.A.',
  '05442029': 'CASA CREDITO S.A. SCM',
  '05463212': 'COOP CENTRAL AILOS',
  '05790149': 'CENTRAL COOPERATIVA DE CRÉDITO NO ESTADO DO ESPÍRITO SANTO',
  '06271464': 'BCO BBI S.A.',
  '07207996': 'BCO BRADESCO FINANC. S.A.',
  '07237373': 'BCO DO NORDESTE DO BRASIL S.A.',
  '07450604': 'BCO CCB BRASIL S.A.',
  '07512441': 'HS FINANCEIRA',
  '07652226': 'LECCA CFI S.A.',
  '07656500': 'BCO KDB BRASIL S.A.',
  '07679404': 'BANCO TOPÁZIO S.A.',
  '07853842': 'CCR DE OURO',
  '07945233': 'POLOCRED SCMEPP LTDA.',
  '08253539': 'CCR DE SÃO MIGUEL DO OESTE',
  '08357240': 'BCO CSF S.A.',
  '08561701': 'PAGSEGURO',
  '08609934': 'MONEYCORP BCO DE CÂMBIO S.A.',
  '09089356': 'GERENCIANET PAGTOS BRASIL LTDA',
  '09105360': 'ICAP DO BRASIL CTVM LTDA.',
  '09210106': 'SOCRED SA - SCMEPP',
  '09274232': 'STATE STREET BR S.A. BCO COMERCIAL',
  '09313766': 'CARUANA SCFI',
  '09512542': 'CODEPE CVC S.A.',
  '09516419': 'BCO ORIGINAL DO AGRO S/A',
  '09554480': 'SUPER PAGAMENTOS E ADMINISTRACAO DE MEIOS ELETRONICOS S.A.',
  10264663: 'BANCOSEGURO S.A.',
  10398952: 'CRESOL CONFEDERAÇÃO',
  10573521: 'MERCADO PAGO',
  10664513: 'BCO AGIBANK S.A.',
  10690848: 'BCO DA CHINA BRASIL S.A.',
  10853017: 'GET MONEY CC LTDA',
  10866788: 'BCO BANDEPE S.A.',
  11495073: 'OM DTVM LTDA',
  11581339: 'MONEY PLUS SCMEPP LTDA',
  11703662: 'TRAVELEX BANCO DE CÂMBIO S.A.',
  11758741: 'BANCO FINAXIS',
  11970623: 'SENFF S.A. - CFI',
  12865507: 'BRK S.A. CFI',
  13009717: 'BCO DO EST. DE SE S.A.',
  13059145: 'BEXS BCO DE CAMBIO S.A.',
  13140088: 'ACESSO SOLUCOES PAGAMENTO SA',
  13220493: 'BR PARTNERS BI',
  13293225: 'ÓRAMA DTVM S.A.',
  13370835: 'BPP IP S.A.',
  13486793: 'BRL TRUST DTVM SA',
  13673855: 'FRAM CAPITAL DTVM S.A.',
  13720915: 'BCO WESTERN UNION',
  14190547: 'CAMBIONET CC LTDA',
  14388334: 'PARANA BCO S.A.',
  14511781: 'BARI CIA HIPOTECÁRIA',
  15114366: 'BCO BOCOM BBM S.A.',
  15173776: 'BCO CAPITAL S.A.',
  15357060: 'BCO WOORI BANK DO BRASIL S.A.',
  15581638: 'FACTA S.A. CFI',
  16501555: 'STONE PAGAMENTOS S.A.',
  16944141: 'BROKER BRASIL CC LTDA.',
  17184037: 'BCO MERCANTIL DO BRASIL S.A.',
  17298092: 'BCO ITAÚ BBA S.A.',
  17351180: 'BCO TRIANGULO S.A.',
  17352220: 'SENSO CCVM S.A.',
  17453575: 'ICBC DO BRASIL BM S.A.',
  17772370: 'VIPS CC LTDA.',
  18188384: 'CREFAZ SCMEPP LTDA',
  18236120: 'NU PAGAMENTOS S.A.',
  18520834: 'UBS BRASIL BI S.A.',
  19307785: 'MS BANK S.A. BCO DE CÂMBIO',
  20155248: 'PARMETAL DTVM LTDA',
  22610500: 'VORTX DTVM LTDA.',
  23522214: 'COMMERZBANK BRASIL S.A. - BCO MÚLTIPLO',
  23862762: 'AVISTA S.A. CFI',
  24074692: 'GUITTA CC LTDA',
  24537861: 'FFA SCMEPP LTDA.',
  26563270: 'CCR DE PRIMAVERA DO LESTE',
  27098060: 'BANCO DIGIO',
  27214112: 'AMAGGI S.A. CFI',
  27652684: 'GENIAL INVESTIMENTOS CVM S.A.',
  27842177: 'IB CCTVM S.A.',
  28127603: 'BCO BANESTES S.A.',
  28195667: 'BCO ABC BRASIL S.A.',
  28650236: 'BS2 DTVM S.A.',
  28719664: 'B3 Cetip',
  29011780: 'CIP C3',
  29030467: 'SCOTIABANK BRASIL',
  29162769: 'TORO CTVM LTDA',
  30306294: 'BANCO BTG PACTUAL S.A.',
  30723886: 'BCO MODAL S.A.',
  31597552: 'BCO CLASSICO S.A.',
  31872495: 'BCO C6 S.A.',
  31880826: 'BCO GUANABARA S.A.',
  31895683: 'BCO INDUSTRIAL DO BRASIL S.A.',
  32062580: 'BCO CREDIT SUISSE S.A.',
  32402502: 'QI SCD S.A.',
  32648370: 'FAIR CC S.A.',
  32997490: 'CREDITAS SCD',
  33042151: 'BCO LA NACION ARGENTINA',
  33042953: 'CITIBANK N.A.',
  33132044: 'BCO CEDULA S.A.',
  33147315: 'BCO BRADESCO BERJ S.A.',
  33172537: 'BCO J.P. MORGAN S.A.',
  33264668: 'BCO XP S.A.',
  33466988: 'BCO CAIXA GERAL BRASIL S.A.',
  33479023: 'BCO CITIBANK S.A.',
  33603457: 'BCO RODOBENS S.A.',
  33644196: 'BCO FATOR S.A.',
  33657248: 'BNDES',
  33775974: 'ATIVA S.A. INVESTIMENTOS CCTVM',
  33862244: 'BGC LIQUIDEZ DTVM LTDA',
  33885724: 'BANCO ITAÚ CONSIGNADO S.A.',
  33923798: 'BCO MÁXIMA S.A.',
  34111187: 'HAITONG BI DO BRASIL S.A.',
  34335592: 'ÓTIMO SCD S.A.',
  34711571: 'VITREO DTVM S.A.',
  35977097: 'UP.P SEP S.A.',
  36113876: 'OLIVEIRA TRUST DTVM S.A.',
  40303299: 'PORTOPAR DTVM LTDA',
  42272526: 'BNY MELLON BCO S.A.',
  43180355: 'PERNAMBUCANAS FINANC S.A. CFI',
  44189447: 'BCO LA PROVINCIA B AIRES BCE',
  45246410: 'PLURAL BCO BM',
  46518205: 'JPMORGAN CHASE BANK',
  48795256: 'BCO ANDBANK S.A.',
  49336860: 'ING BANK N.V.',
  50579044: 'LEVYCAM CCV LTDA',
  50585090: 'BCV',
  52904364: 'NECTON INVESTIMENTOS S.A CVM',
  52937216: 'BEXS CC S.A.',
  53518684: 'BCO HSBC S.A.',
  54403563: 'BCO ARBI S.A.',
  54641030: 'BMFBOVESPA',
  55230916: 'INTESA SANPAOLO BRASIL S.A. BM',
  57839805: 'BCO TRICURY S.A.',
  58160789: 'BCO SAFRA S.A.',
  58497702: 'SMARTBANK',
  58616418: 'BCO FIBRA S.A.',
  59118133: 'BCO LUSO BRASILEIRO S.A.',
  59285411: 'BANCO PAN',
  59588111: 'BCO VOTORANTIM S.A.',
  60394079: 'BCO ITAUBANK S.A.',
  60498557: 'BCO MUFG BRASIL S.A.',
  60518222: 'BCO SUMITOMO MITSUI BRASIL S.A.',
  60701190: 'ITAÚ UNIBANCO S.A.',
  60746948: 'BCO BRADESCO S.A.',
  60814191: 'BCO MERCEDES-BENZ S.A.',
  60850229: 'OMNI BANCO S.A.',
  60872504: 'ITAÚ UNIBANCO HOLDING S.A.',
  60889128: 'BCO SOFISA S.A.',
  60934221: 'BMF Câmbio',
  61024352: 'BCO INDUSVAL S.A.',
  61033106: 'BCO CREFISA S.A.',
  61088183: 'BCO MIZUHO S.A.',
  61182408: 'BANCO INVESTCRED UNIBANCO S.A.',
  61186680: 'BCO BMG S.A.',
  61348538: 'BCO FICSA S.A.',
  61444949: 'SAGITUR CC LTDA',
  61533584: 'BCO SOCIETE GENERALE BRASIL',
  61723847: 'MAGLIANO S.A. CCVM',
  61747085: 'TULLETT PREBON BRASIL CVC LTDA',
  61809182: 'C.SUISSE HEDGING-GRIFFO CV S/A',
  61820817: 'BCO PAULISTA S.A.',
  62073200: 'BOFA MERRILL LYNCH BM S.A.',
  62109566: 'CREDISAN CC',
  62144175: 'BCO PINE S.A.',
  62169875: 'EASYNVEST - TÍTULO CV SA',
  62232889: 'BCO DAYCOVAL S.A',
  62237649: 'CAROL DTVM LTDA.',
  62285390: 'SOCOPA SC PAULISTA S.A.',
  62287735: 'RENASCENCA DTVM LTDA',
  62331228: 'DEUTSCHE BANK S.A.BCO ALEMAO',
  62421979: 'BANCO CIFRA',
  65913436: 'GUIDE',
  68757681: 'SOLIDUS S.A. CCVM',
  68900810: 'BCO RENDIMENTO S.A.',
  71027866: 'BCO BS2 S.A.',
  71371686: 'BCO OLÉ BONSUCESSO CONSIGNADO S.A.',
  71590442: 'LASTRO RDV DTVM LTDA',
  71677850: 'FRENTE CC LTDA.',
  73622748: 'B&T CC LTDA.',
  74828799: 'NOVO BCO CONTINENTAL S.A. - BM',
  75647891: 'BCO CRÉDIT AGRICOLE BR S.A.',
  76461557: 'CCR COOPAVEL',
  76543115: 'BANCO SISTEMA',
  78157146: 'CREDIALIANÇA CCR',
  78626983: 'BCO VR S.A.',
  78632767: 'BCO OURINVEST S.A.',
  81723108: 'CREDICOAMO',
  89960090: 'RB CAPITAL INVESTIMENTOS DTVM LTDA.',
  90400888: 'BCO SANTANDER (BRASIL) S.A.',
  91884981: 'BANCO JOHN DEERE S.A.',
  92702067: 'BCO DO ESTADO DO RS S.A.',
  92856905: 'ADVANCED CC LTDA',
  92874270: 'BCO A.J. RENNER S.A.',
  92875780: 'WARREN CVMC LTDA',
  92894922: 'BANCO ORIGINAL',
  94968518: 'DECYSEO CC LTDA.',
};

export interface DetalhePagamento {
  idFimAFim: string;
  participanteTarifado: ParticipanteTarifado;
  usuarioPagador: UsuarioDetalhe;
  usuarioRecebedor: UsuarioDetalhe;
  informacoesEntreUsuarios: string;
  valor: number;
  dataHoraRecebimentoPagador: string;
  idIdentificadorTransacao:string;
  formaDeIniciacao: string;
  finalidadeDaTransacao:string;
  dadosValoresAjustes: Array<object>;
}

export interface DetalheSolicitacaoRegistro {
  cnpjParticipanteIndireto: string;
  idParticipanteDireto: string;
}

export interface UsuarioDetalhe {
  nome?: string;
  agencia?: string;
  tipoConta: TipoConta;
  conta: string;
  ispbParticipante: string;
  cpfCnpj: string;
  idContaTransacional?: string;
}

export interface DetalheDevolucao {
  originalEndToEnd: string;
  participanteTarifado: ParticipanteTarifado;
  idDevolucao: string;
  prioridadePagamento: PrioridadePagamento;
  valorDevolucao: string;
  codigoDevolucao: Devolucao;
  motivoDevolucao: string;
  ispbPagador: string;
  ispbRecebedor: string;
  informacoesEntreUsuarios: string;
}

export interface AtualizacaoResponsaveis {
  tipoModificacao: string;
  telefone01Responsavel: string;
  telefone02Responsavel: string;
  telefone03Responsavel: string;
  emailParaInformeSPI: string;
  tipoResponsavel: string;
  nomeDiretor: string;
  telefone01Diretor: string;
  telefone02Diretor: string;
  tipoResponsavelDiretor: string;
  emailDiretor: string;
  palavraChave: string;
  nomeAtributo: string;
  cpfDiretor: string;
}

export interface RegistroDescontinuidade {
  participanteIndireto : string;
}

export type MetodoLiquidacao = 'CLRG';

export type PrioridadePagamento = 'HIGH' | 'NORM';

export type TipoPrioridadePagamento = 'PAGPRI' | 'PAGFRD' | 'PAGAGD';

export type FinalidadeTransacao = 'IPAY' | 'GSCB' | 'OTHR';

export type ParticipanteTarifado = 'SLEV';

export type TipoConta = 'CACC' | 'SLRY' | 'SVGS' | 'TRAN';

export type Status = 'ACCC' | 'ACSC' | 'ACSP' | 'RJCT';

export enum Pacs002Status {
  'ACCC' = 'Notificação do SPI da conclusão da transação ao PSP do Recebedor',
  'ACSC' = 'Notificação do SPI da conclusão da transação ao PSP do Pagador',
  'ACSP' = 'Prosseguimento do pagamento após as validação realizadas pelo PSP do Recebedor',
  'RJCT' = 'Instrução de pagamento rejeitada pelo SPI / PSP do Recebedor por erro de negócio',
}

export enum Camt054Status {
  'BOOK' = 'Transação liquidada e contabilizada',
  'INFO' = 'Transação não liquidada. Registro somente para informação.',
}

export enum Camt014Situacao {
  'ENBL' = 'Inclusão de PSP no SPI',
  'DLTD' = 'Exclusão de PSP no SPI',
}

export enum Camt014TipoParticipante {
  'DRCT' = 'Participante direto do SPI (titular de conta PI)',
  'IDRT' = 'Participante indireto do SPI',
}

export type ReasonCode =
  | 'AB03'
  | 'AB09'
  | 'AC03'
  | 'AC06'
  | 'AC07'
  | 'AC14'
  | 'AG03'
  | 'AGNT'
  | 'AM01'
  | 'AM04'
  | 'AM09'
  | 'AM18'
  | 'BE01'
  | 'CH11'
  | 'CH16'
  | 'DS04'
  | 'DS24'
  | 'DS0G'
  | 'DT02'
  | 'ED05'
  | 'FF08'
  | 'MD01'
  | 'RC09'
  | 'RC10';



export enum Reda016ErrorCode {
  'DIR1' = 'Registro/descontinuidade de um participante direto',
  'DIR2' = 'Participante direto solicitante do registro não corresponde ao participante remetente da mensagem',
  'IND2' = 'Registro de participante indireto com vínculo de liquidação',
  'IND3' = 'Descontinuidade de participante indireto sem vínculo de liquidação',
  'IND4' = 'Registro de instituição que prescinde de autorização de funcionamento do BCB como participante indireta por PSP não responsável por ela no arranjo PIX',
  'CAI4' = 'Cadastro Inexistente de participante indireto',
  'EXP5' = 'Prazo de confirmação da instrução expirado',
  'ITC6' = 'Instrução recusada devido recebimento de uma outra instrução em suspenso',
  'ATC7' = 'Atualização das informações de contato de um participante diverso do solicitante',
  'PCH8' = 'Palavra-chave não informada',
  'TEM9' = 'Telefone e/ou e-mail não informados',
  'CP10' = 'CPF do Diretor não informado',
  'NM11' = 'Nome do Diretor não informado',
  'RP12' = 'Tipo do responsável pelo participante não informado',
  'RP13' = 'Tipo do responsável pelo participante incorreto',
}

export enum Reda016Status{
  'REJT' = 'Instrução foi rejeitada.',
  'COMP' = 'Instrução foi processada com sucesso.',
  'QUED' = 'Instrução, temporariamente, em suspenso. Este código será retornado quando houver uma solicitação de registro de um participante indireto que já possui vínculo ativo com um liquidante.',
}

export enum Reda014Status{
  'REJT' = 'Instrução foi rejeitada.',
  'COMP' = 'Instrução foi processada com sucesso.',
  'QUED' = 'Instrução, temporariamente, em suspenso. Este código será retornado quando houver uma solicitação de registro de um participante indireto que já possui vínculo ativo com um liquidante.',
}

export enum Pacs002ReasonCode {
  'AB03' = 'Controle de timeout no SPI',
  'AB09' = 'Transação interrompida devido a erro no PSP do Recebedor',
  'AC03' = 'Número da conta transacional inexistente ou inválido no PSP do Recebedor',
  'AC06' = 'A conta transacional especificada encontra-se bloqueada',
  'AC07' = 'Número da conta transacional encerrada no PSP do Recebedor',
  'AC14' = 'Tipo incorreto para a conta transacional especificada',
  'AG03' = 'Tipo de transação não é suportado/autorizado na conta transacional especificada; Exemplo: transferência para conta salário.',
  'AGNT' = 'Participante direto não é liquidante do participante do usuário pagador',
  'AM01' = 'Ordem de pagamento com valor zero',
  'AM04' = 'Saldo insuficiente na conta PI do PSP do pagador',
  'AM09' = 'Devolução em valor que faz superar o valor da ordem de pagamento correspondente',
  'AM18' = 'Quantidade de transações inválida',
  'BE01' = 'CPF/CNPJ do usuário recebedor não é consistente com o titular da conta transacional especificada',
  'CH11' = 'CPF/CNPJ do usuário recebedor incorreto',
  'CH16' = 'Preenchimento do conteúdo da mensagem incorreto ou incompatível com as regras de negócio',
  'DS04' = 'Ordem rejeitada pelo PSP do Recebedor',
  'DS24' = 'Ordem rejeitada por extrapolação do tempo decorrido entre o envio da pain.013 e o recebimento da pacs.008 correspondentes pelo PSP do usuário recebedor',
  'DS0G' = 'Participante que assinou a mensagem não é autorizado a realizar a operação na conta PI debitada. No caso em que o participante que assinou a mensagem não é o titular da conta PI debitada nem é o liquidante do PSP do usuário pagador.',
  'DT02' = 'Data e Hora do envio da mensagem inválida',
  'ED05' = 'Erro no processamento do pagamento (erro genérico)',
  'FF08' = 'Identificador da operação mal formatado',
  'MD01' = 'ISPB do participante prestador de serviço Pix Saque ou Pix Troco inexistente',
  'RC09' = 'ISPB do PSP do Pagador inválido ou inexistente',
  'RC10' = 'ISPB do PSP do Recebedor inválido ou inexistente',
}

export type Devolucao =
  | 'AM05'
  | 'AM09'
  | 'BE08'
  | 'DS28'
  | 'FOCR'
  | 'FR01'
  | 'MD06'
  | 'NARR'
  | 'RUTA'
  | 'SL11'
  | 'SL12'
  | 'UPAY';

export enum Pacs004Devolucao {
  BE08 = 'Devolução devido a um erro do PSP',
  FR01 = 'Devolução devido a fraude no pagamento',
  MD06 = 'Devolução solicitado pelo usuário recebedor do pagamento original',
  SL02 = "Devolução motivada por um erro relacionado ao SaquePix"
}
