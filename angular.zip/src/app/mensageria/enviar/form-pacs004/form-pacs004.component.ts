import { ChangeDetectionStrategy, Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { startWith, map, tap } from 'rxjs/operators';
import { EnviarFormBaseComponent } from '../enviar-form-base.component';
import {
  alphaNumericValidator,
  currencyBacenValidator,
  numericValidator,
} from '@core/validators';
import { Pacs004Devolucao, ISPB } from '../../mensageria.model';

@Component({
  selector: 'app-form-pacs004',
  templateUrl: './form-pacs004.component.html',
  styleUrls: ['./form-pacs004.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FormPacs004Component extends EnviarFormBaseComponent {
  readonly Devolucao = Pacs004Devolucao;
  readonly ID_LENGTH = 32;
  readonly MOTIVO_DEVOLUCAO_MAXLENGTH = 105;
  readonly PARTICIPANTE_LENGTH = 8;
  readonly INFORMACOES_MAXLENGTH = 140;
  readonly participanteValidators = [
    Validators.required,
    Validators.minLength(this.PARTICIPANTE_LENGTH),
    Validators.maxLength(this.PARTICIPANTE_LENGTH),
    numericValidator,
  ];
  readonly form = this.fb.group({
    idFimAFim: [
      '',
      [
        Validators.required,
        Validators.minLength(this.ID_LENGTH),
        Validators.maxLength(this.ID_LENGTH),
        alphaNumericValidator,
      ],
    ],
    codigoDevolucao: ['', Validators.required],
    motivoDevolucao: [
      '',
      [
        Validators.maxLength(this.MOTIVO_DEVOLUCAO_MAXLENGTH),
        alphaNumericValidator,
      ],
    ],
    participanteOrigem: [ISPB.CAIXA, this.participanteValidators],
    participanteDestino: [
      { value: '', disabled: true },
      this.participanteValidators,
    ],
    informacoesEntreUsuarios: [
      '',
      [Validators.maxLength(this.INFORMACOES_MAXLENGTH), alphaNumericValidator],
    ],
    valor: [
      null,
      [Validators.required, Validators.minLength(4), currencyBacenValidator],
    ], // máximo 18 caracteres numéricos (2 casas decimais separados por ponto)
  });
  readonly isNarr$ = this.form.get('codigoDevolucao').valueChanges.pipe(
    startWith(this.form.get('codigoDevolucao').value),
    map((codigoDevolucao) => {
      const motivoDevolucao = this.form.get('motivoDevolucao');

      if (codigoDevolucao === 'NARR') {
        motivoDevolucao.enable();
      } else {
        motivoDevolucao.setValue('');
        motivoDevolucao.disable();
      }

      return motivoDevolucao.enabled;
    }),
  );
  readonly idFimAFim$ = this.form.get('idFimAFim').valueChanges.pipe(
    startWith(this.form.get('idFimAFim').value),
    tap((idFimAFim) => {
      const participanteDestino = this.form.get('participanteDestino');
      if (this.form.get('idFimAFim').valid) {
        participanteDestino.setValue(idFimAFim.substr(1, 8));
      } else {
        participanteDestino.setValue('');
      }
    }),
  );

  constructor(private fb: FormBuilder) {
    super();
  }

  get idFimAFim() {
    return this.form.get('idFimAFim');
  }

  get motivoDevolucao() {
    return this.form.get('motivoDevolucao');
  }

  get participanteOrigem() {
    return this.form.get('participanteOrigem');
  }

  get participanteDestino() {
    return this.form.get('participanteDestino');
  }

  get informacoesEntreUsuarios() {
    return this.form.get('informacoesEntreUsuarios');
  }

  get valor() {
    return this.form.get('valor');
  }
}
