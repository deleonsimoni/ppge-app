import { ChangeDetectionStrategy, Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import {
  alphaNumericValidator,
  contaTransacionalValidator,
  currencyBacenValidator,
  inscricaoValidator,
  numericValidator,
} from '@core/validators';
import { ISPB } from '@app/mensageria/mensageria.model';
import { EnviarFormBaseComponent } from '../enviar-form-base.component';

@Component({
  selector: 'app-form-pacs008',
  templateUrl: './form-pacs008.component.html',
  styleUrls: ['./form-pacs008.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FormPacs008Component extends EnviarFormBaseComponent {
  readonly NOME_MAXLENGTH = 140;
  readonly PARTICIPANTE_LENGTH = 8;
  readonly AGENCIA_MAXLENGTH = 4;
  readonly CONTA_MAXLENGTH = 20;
  readonly ID_CONTA_MAXLENGTH = 77;
  readonly INFORMACOES_MAXLENGTH = 140;
  readonly cpfCnpjValidators = [
    Validators.required,
    Validators.minLength(11),
    Validators.maxLength(14),
    numericValidator,
    inscricaoValidator,
  ];
  readonly participanteValidators = [
    Validators.required,
    Validators.minLength(this.PARTICIPANTE_LENGTH),
    Validators.maxLength(this.PARTICIPANTE_LENGTH),
    numericValidator,
  ];
  readonly agenciaValidators = [
    Validators.maxLength(this.AGENCIA_MAXLENGTH),
    numericValidator,
  ];
  readonly contaValidators = [
    Validators.required,
    Validators.maxLength(this.CONTA_MAXLENGTH),
    numericValidator,
  ];

  readonly form = this.fb.group({
    tipoPrioridadePagamento:['',[Validators.required ]],
    prioridadePagamento:['',[Validators.required ]],
    nomePagador: [
      '',
      [
        Validators.required,
        Validators.maxLength(this.NOME_MAXLENGTH),
        alphaNumericValidator,
      ],
    ],
    cpfCnpjPagador: ['', this.cpfCnpjValidators],
    participanteDoPagador: [ISPB.CAIXA, this.participanteValidators],
    tipoContaPagador: ['', Validators.required], // 'CACC' | 'SLRY' | 'SVGS' | 'TRAN'
    agenciaPagador: ['', this.agenciaValidators],
    contaPagador: ['', this.contaValidators],
    idContaTransacional: [
      '',
      [
        Validators.maxLength(this.ID_CONTA_MAXLENGTH),
        contaTransacionalValidator
      ],
    ],
    idIdentificadorTransacao: [''],
    cpfCnpjRecebedor: ['', this.cpfCnpjValidators],
    participanteDoRecebedor: ['', this.participanteValidators],
    tipoContaRecebedor: ['', Validators.required], // 'CACC' | 'SLRY' | 'SVGS' | 'TRAN'
    agenciaRecebedor: ['', this.agenciaValidators],
    contaRecebedor: ['', this.contaValidators],
    informacoesEntreUsuarios: [
      '',
      [Validators.maxLength(this.INFORMACOES_MAXLENGTH), alphaNumericValidator],
    ],
    valor: [
      null,
      [Validators.required, Validators.minLength(4), currencyBacenValidator],
    ], // máximo 18 caracteres numéricos (2 casas decimais separados por ponto)
    valorEspecie: [
      null,
      [Validators.minLength(4), currencyBacenValidator],
    ],
    valorCompra: [
      null,
      [Validators.minLength(4), currencyBacenValidator],
    ],
    finalidadeDaTransacao:[null, Validators.required],
    versao: ['3'],

  });

  constructor(private fb: FormBuilder) {
    super();
  }

  get nomePagador() {
    return this.form.get('nomePagador');
  }

  get cpfCnpjPagador() {
    return this.form.get('cpfCnpjPagador');
  }

  get participanteDoPagador() {
    return this.form.get('participanteDoPagador');
  }

  get agenciaPagador() {
    return this.form.get('agenciaPagador');
  }

  get contaPagador() {
    return this.form.get('contaPagador');
  }

  get idContaTransacional() {
    return this.form.get('idContaTransacional');
  }

  get cpfCnpjRecebedor() {
    return this.form.get('cpfCnpjRecebedor');
  }

  get participanteDoRecebedor() {
    return this.form.get('participanteDoRecebedor');
  }

  get tipoContaRecebedor() {
    return this.form.get('tipoContaRecebedor');
  }

  get agenciaRecebedor() {
    return this.form.get('agenciaRecebedor');
  }

  get contaRecebedor() {
    return this.form.get('contaRecebedor');
  }

  get informacoesEntreUsuarios() {
    return this.form.get('informacoesEntreUsuarios');
  }

  get valor() {
    return this.form.get('valor');
  }

  verificarTipoTransacao(){
    if(this.form.get('finalidadeDaTransacao').value && this.form.get('finalidadeDaTransacao').value !== 'IPAY'){
      this.form.controls["valorEspecie"].setValidators(Validators.required);
      this.form.controls["valorEspecie"].updateValueAndValidity();

    } else if(this.form.get('finalidadeDaTransacao').value && this.form.get('finalidadeDaTransacao').value === 'GSCB'){
      this.form.controls["valorCompra"].setValidators(Validators.required);
      this.form.controls["valorCompra"].updateValueAndValidity();
    } else {
      this.form.controls["valorEspecie"].clearValidators();
      this.form.controls["valorEspecie"].setValidators([Validators.minLength(4), currencyBacenValidator]);
      this.form.controls["valorEspecie"].setValue(null);
      this.form.controls["valorEspecie"].updateValueAndValidity();

      this.form.controls["valorCompra"].clearValidators();
      this.form.controls["valorCompra"].setValidators([Validators.minLength(4), currencyBacenValidator]);
      this.form.controls["valorCompra"].setValue(null);
      this.form.controls["valorCompra"].updateValueAndValidity();

    }
  }

  getInscricaoMask(formControlName: string): string {
    const length = this.form.get(formControlName).value.length;
    return length <= 11 ? '000.000.000-009' : '00.000.000/0000-00';
  }
}
