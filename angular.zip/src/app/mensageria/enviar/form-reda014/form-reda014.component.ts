import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { EnviarFormBaseComponent } from '../enviar-form-base.component';
import { ISPB } from '@app/mensageria/mensageria.model';
import {
  inscricaoValidator,
  numericValidator,
} from '@core/validators';

@Component({
  selector: 'app-form-reda014',
  templateUrl: './form-reda014.component.html'
})
export class FormReda014Component extends EnviarFormBaseComponent{

  readonly CNPJ_LENGTH = 14;
  readonly PARTICIPANTE_LENGTH = 8;

  readonly cpfCnpjValidators = [
    Validators.required,
    Validators.minLength(this.CNPJ_LENGTH),
    Validators.maxLength(this.CNPJ_LENGTH),
    numericValidator,
    inscricaoValidator,
  ];

  readonly participanteDiretroValidators = [
    Validators.required,
    Validators.minLength(this.PARTICIPANTE_LENGTH),
    Validators.maxLength(this.PARTICIPANTE_LENGTH),
  ];

  constructor(private fb: FormBuilder) { 
    super();
  }

  readonly form = this.fb.group({
    cnpjParticipanteIndireto: ['', this.cpfCnpjValidators],
    idParticipanteDireto: [ISPB.CAIXA, this.participanteDiretroValidators]
  });

  get cnpjParticipanteIndireto() {
    return this.form.get('cnpjParticipanteIndireto');
  }

  get idParticipanteDireto() {
    return this.form.get('idParticipanteDireto');
  }

  getCpfMask(): string {
    return '00.000.000/0000-00'
  }

}
