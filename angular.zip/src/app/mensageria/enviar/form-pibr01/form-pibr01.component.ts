import { ChangeDetectionStrategy, Component } from '@angular/core';
import { Validators, FormBuilder } from '@angular/forms';
import { EnviarFormBaseComponent } from '../enviar-form-base.component';

@Component({
  selector: 'app-form-pibr01',
  templateUrl: './form-pibr01.component.html',
  styleUrls: ['./form-pibr01.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FormPibr01Component extends EnviarFormBaseComponent {

  readonly form = this.fb.group({
    canal:['1',Validators.required ],
  });

  constructor(private fb: FormBuilder) {
    super();
  }

   get canal() {
    return this.form.get('canal');
  }

}
