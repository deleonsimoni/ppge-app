import {
  Component,
  EventEmitter,
  OnDestroy,
  OnInit,
  Output,
} from '@angular/core';
import { FormGroup } from '@angular/forms';

@Component({
  template: '',
})
export class EnviarFormBaseComponent implements OnInit, OnDestroy {
  @Output() setControl = new EventEmitter<FormGroup>();
  readonly form: FormGroup;

  ngOnInit() {
    this.setControl.emit(this.form);
  }

  ngOnDestroy() {
    this.setControl.emit(new FormGroup({}));
  }
}
