import { ChangeDetectionStrategy, Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import {
  alphaNumericValidator,
  inscricaoValidator,
  numericValidator,
} from '@core/validators';
import { EnviarFormBaseComponent } from '../enviar-form-base.component';

@Component({
  selector: 'app-form-reda022',
  templateUrl: './form-reda022.component.html',
  styleUrls: ['./form-reda022.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FormReda022Component extends EnviarFormBaseComponent {
  readonly PARTICIPANTE_LENGTH = 8;
  readonly TELEFONE_LENGTH = 30;
  readonly EMAIL_LENGTH = 77;
  readonly CPF_LENGTH = 11;
  readonly NOME_DIRETOR_LENGTH = 140;
  readonly PALAVRA_CHAVE_LENGTH = 8;

  readonly cpfCnpjValidators = [
    Validators.required,
    Validators.minLength(this.CPF_LENGTH),
    Validators.maxLength(this.CPF_LENGTH),
    numericValidator,
    inscricaoValidator,
  ];
  readonly participanteValidators = [
    Validators.required,
    Validators.minLength(this.PARTICIPANTE_LENGTH),
    Validators.maxLength(this.PARTICIPANTE_LENGTH),
    numericValidator,
  ];
  readonly form = this.fb.group({
    palavraChave: [
      '',
      [
        Validators.required,
        Validators.minLength(this.PALAVRA_CHAVE_LENGTH),
        Validators.maxLength(this.PALAVRA_CHAVE_LENGTH),
        alphaNumericValidator,
      ]
    ],
    emailDiretor: [
      '',
      [
        Validators.required,
        Validators.email,
        Validators.maxLength(this.EMAIL_LENGTH),
      ]
    ],
    telefone01Diretor: [
      '',
      [
        Validators.required,
        Validators.maxLength(this.TELEFONE_LENGTH),
      ]
    ],
    telefone02Diretor: [
      '',
      [
        Validators.maxLength(this.TELEFONE_LENGTH),
      ]
    ],
    telefone01Responsavel: [
      '',
      [
        Validators.required,
        Validators.maxLength(this.TELEFONE_LENGTH),
      ]
    ],
    telefone02Responsavel: [
      '',
      [
        Validators.maxLength(this.TELEFONE_LENGTH),
      ]
    ],
    telefone03Responsavel: [
      '',
      [
        Validators.maxLength(this.TELEFONE_LENGTH),
      ]
    ],
    emailParaInformeSPI: [
      '',
      [
        Validators.required,
        Validators.maxLength(this.EMAIL_LENGTH),
        Validators.email,
      ]
    ],
    nomeDiretor: [
      '',
      [
        Validators.required,
        Validators.maxLength(this.NOME_DIRETOR_LENGTH),
        alphaNumericValidator,
      ],
    ],
      cpfDiretor: ['', this.cpfCnpjValidators],
  });

  constructor(private fb: FormBuilder) {
    super();
  }

  get telefone01Responsavel() {
    return this.form.get('telefone01Responsavel');
  }

  get telefone02Responsavel() {
    return this.form.get('telefone02Responsavel');
  }

  get telefone03Responsavel() {
    return this.form.get('telefone03Responsavel');
  }

  get emailParaInformeSPI() {
    return this.form.get('emailParaInformeSPI');
  }

  get nomeDiretor() {
    return this.form.get('nomeDiretor');
  }

  get telefone01Diretor() {
    return this.form.get('telefone01Diretor');
  }

  get telefone02Diretor() {
    return this.form.get('telefone02Diretor');
  }

  get emailDiretor() {
    return this.form.get('emailDiretor');
  }

  get palavraChave() {
    return this.form.get('palavraChave');
  }

  get cpfDiretor() {
    return this.form.get('cpfDiretor');
  }

  getCpfMask(): string {
    return '000.000.000-00'
  }

  getTelephoneMobileMask(): string {
    return '+00-0000000000*'
  }
  getTelephoneMask(): string {
    return '+00-000000000*'
  }
}
