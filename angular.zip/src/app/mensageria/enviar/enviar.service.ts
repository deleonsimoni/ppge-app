import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { Observable } from 'rxjs';
import { map, delay, catchError } from 'rxjs/operators';
import { Moment } from 'moment';
import {
  DetalheDevolucao,
  DetalhePagamento,
  Devolucao,
  MetodoLiquidacao,
  ParticipanteTarifado,
  PrioridadePagamento,
  AtualizacaoResponsaveis,
  RegistroDescontinuidade,
  DetalheSolicitacaoRegistro,
  TipoPrioridadePagamento,
} from '../mensageria.model';
import { environment } from '@env/environment';
import { SnackbarService } from '@core/services';

@Injectable({
  providedIn: 'root',
})
export class EnviarService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao/mensagens`;

  private readonly URL_CAMT060 = `${this.URL_PIX_GESTAO}/envio-solicitacao`;
  private readonly URL_REDA022 = `${this.URL_PIX_GESTAO}/atualizacao-responsaveis`;
  private readonly URL_REDA031 = `${this.URL_PIX_GESTAO}/registro-descontinuidade`;
  private readonly URL_REDA014 = `${this.URL_PIX_GESTAO}/envio-solicitacao-registro`;
  private readonly URL_PACS004 = `${this.URL_PIX_GESTAO}/devolucao-pagamento-manual`;
  private readonly URL_PACS008 = `${this.URL_PIX_GESTAO}/envio-pagamento-manual`;
  private readonly URL_PIBR001 = `${this.URL_PIX_GESTAO}/teste-conectividade`;
  private readonly URL_PIBR001_2 = `${this.URL_PIX_GESTAO}/teste-conectividade-secundario`;
  constructor(private http: HttpClient, private datePipe: DatePipe, private snackbarService: SnackbarService) {}

  getIdFimAFim(ispb: string, tipo: string = 'E'): string {
    return `${tipo}${ispb}${this.datePipe.transform(
      new Date(),
      'yyyyMMddHHmm','UTC'
    )}${this.createUUID()}`;
  }

  camt052(
    tipoArquivo: string,
    dataInicial: Moment,
    horarioInicialResultado: string,
    dataFinal?: Moment,
    horarioFinalResultado?: string
  ): Observable<string> {
    const dataInicialResultado = dataInicial ? dataInicial.format('YYYY-MM-DD'): dataInicial;
    const dataFinalResultado = dataFinal
      ? dataFinal.format('YYYY-MM-DD')
      : dataFinal;
    return this.http
      .post(
        `${this.URL_CAMT060}-lancamento`,
        {
          dataInicialResultado,
          ...(horarioInicialResultado && {
            horarioInicialResultado: `${horarioInicialResultado}.001Z`,
          }),
          ...(dataFinalResultado && { dataFinalResultado }),
          ...(horarioFinalResultado && {
            horarioFinalResultado: `${horarioFinalResultado}.999Z`,
          }),
          tipoArquivo
        },
        { observe: 'response', responseType: 'text' },
      )
      .pipe(
        delay(3000),
        map((response) => {
          if (response.status === 201) {
            return response.body;
          }
        }),
        catchError((error) => {
          let errorMsg: string;
          this.snackbarService.open('Erro ao enviar mensagem para o BACEN, tente novamente', 'error');

          if (error.error instanceof ErrorEvent) {
            errorMsg = `Error: ${error.error.message}`;
          } else {
            errorMsg = this.getServerErrorMessage(error);
          }

          throw errorMsg;
        })
      );
  }

  camt053(data: Moment, tipoArquivo: string): Observable<string> {
    const dataInicialResultado = data? data.format('YYYY-MM-DD'): null;
    return this.http
      .post(
        `${this.URL_CAMT060}-saldo`,
        { dataInicialResultado, tipoArquivo},
        { observe: 'response', responseType: 'text' },
      )
      .pipe(
        delay(3000),
        map((response) => {
          if (response.status === 201) {
            return response.body;
          }
        }),
        catchError((error) => {
          let errorMsg: string;
          this.snackbarService.open('Erro ao enviar mensagem para o BACEN, tente novamente', 'error');

          if (error.error instanceof ErrorEvent) {
            errorMsg = `Error: ${error.error.message}`;
          } else {
            errorMsg = this.getServerErrorMessage(error);
          }

          throw errorMsg;
        })
      );
  }

  camt054(idInstrucao: string): Observable<string> {
    return this.http
      .post(
        `${this.URL_CAMT060}-lancamento`,
        { idInstrucao },
        { observe: 'response', responseType: 'text' },
      )
      .pipe(
        delay(3000),
        map((response) => {
          if (response.status === 201) {
            return response.body;
          }
        }),
        catchError((error) => {
          let errorMsg: string;
          this.snackbarService.open('Erro ao enviar mensagem para o BACEN, tente novamente', 'error');

          if (error.error instanceof ErrorEvent) {
            errorMsg = `Error: ${error.error.message}`;
          } else {
            errorMsg = this.getServerErrorMessage(error);
          }

          throw errorMsg;
        })
      );
  }

  reda022(
   atualizacaoResponsavel: AtualizacaoResponsaveis,
  ) : Observable<string> {
    return this.http
    .post(
      this.URL_REDA022,
      atualizacaoResponsavel,
      { observe: 'response', responseType: 'text'},
    )
    .pipe(
      delay(3000),
      map((response) => {
        if (response.status === 201) {
          return response.body;
        }
      }),
      catchError((error) => {
        let errorMsg: string;
        this.snackbarService.open('Erro ao enviar mensagem para o BACEN, tente novamente', 'error');

        if (error.error instanceof ErrorEvent) {
          errorMsg = `Error: ${error.error.message}`;
        } else {
          errorMsg = this.getServerErrorMessage(error);
        }

        throw errorMsg;
      })
    );
  }

  reda014(
    detalheSolicitacaoRegistro: DetalheSolicitacaoRegistro,
  ): Observable<string> {
    return this.http
      .post(
        this.URL_REDA014, detalheSolicitacaoRegistro,
        { observe: 'response', responseType: 'text'},
      )
      .pipe(
        delay(3000),
        map((response) => {
          if (response.status === 201) {
            return response.body;
          }
        }),
        catchError((error) => {
          let errorMsg: string;
          this.snackbarService.open('Erro ao enviar mensagem para o BACEN, tente novamente', 'error');

          if (error.error instanceof ErrorEvent) {
            errorMsg = `Error: ${error.error.message}`;
          } else {
            errorMsg = this.getServerErrorMessage(error);
          }

          throw errorMsg;
        })
      );
  }

  reda031(
    registroDescontinuidade: RegistroDescontinuidade,
   ) : Observable<string> {
     return this.http
     .post(
       this.URL_REDA031,
       registroDescontinuidade,
       { observe: 'response', responseType: 'text'},
     )
     .pipe(
      delay(3000),
       map((response) => {
         if (response.status === 201) {
           return response.body;
         }
       }),
       catchError((error) => {
         let errorMsg: string;
         this.snackbarService.open('Erro ao enviar mensagem para o BACEN, tente novamente', 'error');

         if (error.error instanceof ErrorEvent) {
           errorMsg = `Error: ${error.error.message}`;
         } else {
           errorMsg = this.getServerErrorMessage(error);
         }

         throw errorMsg;
       })
     );
   }

  pacs004(
    idFimAFimOriginal: string,
    idFimAFim: string,
    valor: string,
    codigo: Devolucao,
    motivo: string,
    ispbPagador: string,
    ispbRecebedor: string,
    informacoesEntreUsuarios: string,
    metodoLiquidacao: MetodoLiquidacao = 'CLRG',
    participanteTarifado: ParticipanteTarifado = 'SLEV',
    prioridadePagamento: PrioridadePagamento = 'HIGH',
    versao: number = 2
  ): Observable<string> {
    const detalhesDevolucoes: DetalheDevolucao[] = [
      {
        originalEndToEnd: idFimAFimOriginal,
        participanteTarifado,
        idDevolucao: idFimAFim,
        prioridadePagamento,
        valorDevolucao: valor,
        codigoDevolucao: codigo,
        motivoDevolucao: motivo,
        ispbPagador,
        ispbRecebedor,
        informacoesEntreUsuarios

      },
    ];

    return this.http
      .post<string>(
        this.URL_PACS004,
        {
          metodoLiquidacao,
          detalhesDevolucoes,
          versao
        },
        { observe: 'response' },
      )
      .pipe(
        delay(3000),
        map((response) => {
          if (response.status === 201) {
            return response.body;
          }
        }),
        catchError((error) => {
          let errorMsg: string;
          this.snackbarService.open('Erro ao enviar mensagem para o BACEN, tente novamente', 'error');

          if (error.error instanceof ErrorEvent) {
            errorMsg = `Error: ${error.error.message}`;
          } else {
            errorMsg = this.getServerErrorMessage(error);
          }

          throw errorMsg;
        })
      );
  }

  pacs008(
    detalhePagamento: DetalhePagamento,
    prioridadePagamento: PrioridadePagamento = 'HIGH',
    tipoPrioridadePagamento: TipoPrioridadePagamento
    ,versao: string
  ): Observable<string> {
    return this.http
      .post<string>(
        this.URL_PACS008,
        {
          prioridadePagamento,
          tipoPrioridadePagamento,
          versao,
          detalhesPagamentos: [detalhePagamento],
        },
        { observe: 'response' },
      )
      .pipe(
        delay(3000),
        map((response) => {
          if (response.status === 201) {
            return response.body;
          }
        }),
        catchError((error) => {
          let errorMsg: string;
          this.snackbarService.open('Erro ao enviar mensagem para o BACEN, tente novamente', 'error');

          if (error.error instanceof ErrorEvent) {
            errorMsg = `Error: ${error.error.message}`;
          } else {
            errorMsg = this.getServerErrorMessage(error);
          }

          throw errorMsg;
        })
      );
  }

  pibr001(canal: number): Observable<string> {
    let url = canal == 1 ? this.URL_PIBR001 : this.URL_PIBR001_2;
    return this.http.get(url, { responseType: 'text' })
    .pipe(
      delay(3000),
      catchError((error) => {
        let errorMsg: string;
        this.snackbarService.open('Erro ao enviar mensagem para o BACEN, tente novamente', 'error');

        if (error.error instanceof ErrorEvent) {
          errorMsg = `Error: ${error.error.message}`;
        } else {
          errorMsg = this.getServerErrorMessage(error);
        }

        throw errorMsg;
      })
    );
  }

  private createUUID(): string {
    let date = new Date().getTime();
    const uuid = 'xxxxxxxxxxx'.replace(/[xy]/g, (c) => {
      // tslint:disable-next-line:no-bitwise
      const r = (date + Math.random() * 16) % 16 | 0;
      date = Math.floor(date / 16);
      // tslint:disable-next-line:no-bitwise
      return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
    });
    return uuid;
  }

  private getServerErrorMessage(error: HttpErrorResponse): string {
    switch (error.status) {
        case 404: {
            return `Not Found: ${error.message}`;
        }
        case 403: {
            return `Access Denied: ${error.message}`;
        }
        case 500: {
            return `Internal Server Error: ${error.message}`;
        }
        default: {
            return `Unknown Server Error: ${error.message}`;
        }

    }
  }
}
