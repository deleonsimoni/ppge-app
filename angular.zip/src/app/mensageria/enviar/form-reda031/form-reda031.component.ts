import { ChangeDetectionStrategy, Component } from '@angular/core';
import { Validators, FormBuilder } from '@angular/forms';
import {
  numericValidator,
} from '@core/validators';
import { EnviarFormBaseComponent } from '../enviar-form-base.component';

@Component({
  selector: 'app-form-reda031',
  templateUrl: './form-reda031.component.html',
  styleUrls: ['./form-reda031.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FormReda031Component extends EnviarFormBaseComponent {
  readonly PARTICIPANTE_LENGTH = 8;

  readonly participanteValidators = [
    Validators.required,
    Validators.minLength(this.PARTICIPANTE_LENGTH),
    Validators.maxLength(this.PARTICIPANTE_LENGTH),
    numericValidator,
  ];

  readonly form = this.fb.group({
    participanteIndireto:[
      '',
      this.participanteValidators,
    ],
  });

  constructor(private fb: FormBuilder) {
    super();
  }

   get participanteIndireto() {
    return this.form.get('participanteIndireto');
  } 
  
}
