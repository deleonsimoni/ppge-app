import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgxCurrencyModule } from 'ngx-currency';
import { NgxMaskModule } from 'ngx-mask';
import { MensagensModule } from '@app/mensagens/mensagens.module';
import { EnviarComponent } from './enviar.component';
import { FormCamt060Component } from './form-camt060/form-camt060.component';
import { FormPacs004Component } from './form-pacs004/form-pacs004.component';
import { FormPacs008Component } from './form-pacs008/form-pacs008.component';
import { FormReda022Component } from './form-reda022/form-reda022.component';
import { FormReda031Component } from './form-reda031/form-reda031.component';
import { FormReda014Component } from './form-reda014/form-reda014.component';
import { FormPibr01Component } from './form-pibr01/form-pibr01.component';

@NgModule({
  declarations: [
    EnviarComponent,
    FormCamt060Component,
    FormPacs004Component,
    FormPacs008Component,
    FormReda022Component,
    FormReda031Component,
    FormReda014Component,
    FormPibr01Component
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatInputModule,
    MatSelectModule,
    MatTooltipModule,
    NgxCurrencyModule,
    NgxMaskModule.forRoot(),
    MensagensModule,
  ],
})
export class EnviarModule {}
