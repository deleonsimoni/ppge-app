import { ChangeDetectionStrategy, Component } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { Observable, of, Subject } from 'rxjs';
import { ISPB } from '../mensageria.model';
import { EnviarService } from './enviar.service';
import { environment } from '@env/environment';
import { catchError, map } from 'rxjs/operators';
import { SnackbarService } from '@core/services';
import { LoginService } from '@store/login';

@Component({
  selector: 'app-enviar',
  templateUrl: './enviar.component.html',
  styleUrls: ['./enviar.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class EnviarComponent {
  readonly production = environment.production;
  readonly ambiente = environment.ambiente;
  readonly form = this.fb.group({
    mensagem: ['PIBR.001', Validators.required],
    data: this.fb.group({}),
  });
  idMensagem$: Observable<string>;
  loading$ = new Subject<boolean>();

  constructor(private fb: FormBuilder, private enviarService: EnviarService,
    private snackbarService: SnackbarService, public loginService: LoginService) {}

  get mensagem() {
    return this.form.get('mensagem');
  }

  get data() {
    return this.form.get('data');
  }

  mostrarOpcao(): boolean {
    return this.ambiente.toUpperCase() !== 'PRD';
  }

  onSubmit(): void {
    this.loading$.next(true);
    switch (this.mensagem.value) {
      case 'CAMT.060': {
        switch (this.data.get('tipoConsulta').value) {
          case 'CAMT.052': {
            const tipoArquivo = this.data.get('data').get('tipoArquivo').value;
            const dataInicial = this.data.get('data').get('dataInicialResultado').value;
            const horaInicial = tipoArquivo === 'REL'? this.data.get('data').get('horarioInicialResultado').value: null;
            const dataFinal = tipoArquivo === 'REL'? this.data.get('data').get('dataFinalResultado').value: null;
            const horaFinal = tipoArquivo === 'REL'? this.data.get('data').get('horarioFinalResultado').value: null;
            console.log(dataInicial);
            this.idMensagem$ = this.enviarService.camt052(tipoArquivo, dataInicial, horaInicial, dataFinal, horaFinal).pipe(
              map((response) => {
                this.loading$.next(false);
                return response;
              }),
              catchError(error => {
                console.log(error);
                this.loading$.next(false);
                return of('');
              })
            );
            break;
          }
          case 'CAMT.053': {
            const dataInicial = this.data.get('data').get('tipoArquivo').value === 'CSA'? this.data.get('data').get('dataInicialCsa').value: this.data.get('data').get('dataInicialResultado').value;
            this.idMensagem$ = this.enviarService.camt053(
              dataInicial, this.data.get('data').get('tipoArquivo').value
              ).pipe(
              map((response) => {
                this.loading$.next(false);
                return response;
              }),
              catchError(error => {
                console.log(error);
                this.loading$.next(false);
                return of('');
              })
            );
            break;
          }
          case 'CAMT.054': {
            this.idMensagem$ = this.enviarService.camt054(
              this.data.get('data').get('idInstrucao').value
            ).pipe(
              map((response) => {
                this.loading$.next(false);
                return response;
              }),
              catchError(error => {
                console.log(error);
                this.loading$.next(false);
                return of('');
              })
            );
            break;
          }
        }
        break;
      }
      case 'PACS.004': {
        this.idMensagem$ = this.enviarService.pacs004(
          this.data.get('idFimAFim').value,
          this.enviarService.getIdFimAFim(ISPB.CAIXA, 'D'),
          this.data.get('valor').value,
          this.data.get('codigoDevolucao').value,
          this.data.get('motivoDevolucao').value,
          this.data.get('participanteOrigem').value,
          this.data.get('participanteDestino').value,
          this.data.get('informacoesEntreUsuarios').value,
        ).pipe(
          map((response) => {
            this.loading$.next(false);
            return response;
          }),
          catchError(error => {
            console.log(error);
            this.loading$.next(false);
            return of('');
          })
        );
        break;
      }

      case 'REDA.022': {
        this.idMensagem$ = this.enviarService.reda022({
          tipoModificacao: 'INSE',
          telefone01Responsavel: this.data.get('telefone01Responsavel').value,
          telefone02Responsavel: this.data.get('telefone02Responsavel').value,
          telefone03Responsavel: this.data.get('telefone03Responsavel').value,
          emailParaInformeSPI: this.data.get('emailParaInformeSPI').value,
          tipoResponsavel: 'CONTATOPSP',
          nomeDiretor: this.data.get('nomeDiretor').value,
          telefone01Diretor: this.data.get('telefone01Diretor').value,
          telefone02Diretor: this.data.get('telefone02Diretor').value,
          tipoResponsavelDiretor: 'DIRETORPSP',
          emailDiretor: this.data.get('emailDiretor').value,
          palavraChave: this.data.get('palavraChave').value,
          nomeAtributo: 'CPFDIRETOR',
          cpfDiretor: this.data.get('cpfDiretor').value,
        }).pipe(
          map((response) => {
            this.loading$.next(false);
            return response;
          }),
          catchError(error => {
            console.log(error);
            this.loading$.next(false);
            return of('');
          })
        );
        break;
      }
      case 'REDA.031': {
        this.idMensagem$ = this.enviarService.reda031({
          participanteIndireto: this.data.get('participanteIndireto').value,
        }).pipe(
          map((response) => {
            this.loading$.next(false);
            return response;
          }),
          catchError(error => {
            console.log(error);
            this.loading$.next(false);
            return of('');
          })
        );
        break;
      }

      case 'REDA.014': {
        this.idMensagem$ = this.enviarService.reda014({
          cnpjParticipanteIndireto: this.data.get('cnpjParticipanteIndireto').value,
          idParticipanteDireto: this.data.get('idParticipanteDireto').value,
        }).pipe(
          map((response) => {
            this.loading$.next(false);
            return response;
          }),
          catchError(error => {
            console.log(error);
            this.loading$.next(false);
            return of('');
          })
        );
        break;
      }

      case 'PACS.008': {
        let dadosAjustes = [];
        if (this.data.get('finalidadeDaTransacao').value === 'OTHR'){
          dadosAjustes.push({"valor": this.data.get('valorEspecie').value, "tipo" : "VLDN" });
        }else if (this.data.get('finalidadeDaTransacao').value === 'GSCB') {
          dadosAjustes.push({"valor": this.data.get('valorEspecie').value, "tipo" : "VLDN" });
          dadosAjustes.push({"valor": this.data.get('valorCompra').value, "tipo" : "VLCP" });
        }

        this.idMensagem$ = this.enviarService.pacs008({
          idFimAFim: this.enviarService.getIdFimAFim(ISPB.CAIXA),
          participanteTarifado: 'SLEV',
          formaDeIniciacao:'MANU',
          dataHoraRecebimentoPagador: new Date().toJSON(),
          usuarioPagador: {
            nome: this.data.get('nomePagador').value,
            agencia: this.data.get('agenciaPagador').value,
            tipoConta: this.data.get('tipoContaPagador').value,
            conta: this.data.get('contaPagador').value,
            ispbParticipante: this.data.get('participanteDoPagador').value,
            cpfCnpj: this.data.get('cpfCnpjPagador').value,
          },
          usuarioRecebedor: {
            agencia: this.data.get('agenciaRecebedor').value,
            tipoConta: this.data.get('tipoContaRecebedor').value,
            conta: this.data.get('contaRecebedor').value,
            ispbParticipante: this.data.get('participanteDoRecebedor').value,
            cpfCnpj: this.data.get('cpfCnpjRecebedor').value,
            idContaTransacional: this.data.get('idContaTransacional').value,
          },
          informacoesEntreUsuarios: this.data.get('informacoesEntreUsuarios')
            .value,
          idIdentificadorTransacao: this.data.get('idIdentificadorTransacao').value,
          valor: this.data.get('valor').value,
          finalidadeDaTransacao: this.data.get('finalidadeDaTransacao').value,
          dadosValoresAjustes: dadosAjustes
        }, this.data.get('prioridadePagamento').value,
         this.data.get('tipoPrioridadePagamento').value
         ,this.data.get('versao').value
         )
        .pipe(
          map((response) => {
            this.loading$.next(false);
            return response;
          }),
          catchError(error => {
            console.log(error);
            this.loading$.next(false);
            return of('');
          })
        );
        break;
      }
      case 'PIBR.001': {
        this.idMensagem$ = this.enviarService.pibr001(this.data.get('canal').value).pipe(
          map((response) => {
            this.loading$.next(false);
            return response;
          }),
          catchError(error => {
            console.log(error);
            this.loading$.next(false);
            return of('');
          })
        );
        break;
      }
    }
    this.snackbarService.open('Enviando Mensagem', 'success');
  }

  onSetControl(event: FormGroup): void {
    this.form.setControl('data', event);
  }
}
