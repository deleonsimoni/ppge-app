import { ChangeDetectionStrategy, Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { startWith, tap } from 'rxjs/operators';
import * as moment from 'moment';
import { alphaNumericValidator, intervaloDataValidator } from '@core/validators';
import { EnviarFormBaseComponent } from '../enviar-form-base.component';

@Component({
  selector: 'app-form-camt060',
  templateUrl: './form-camt060.component.html',
  styleUrls: ['./form-camt060.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FormCamt060Component extends EnviarFormBaseComponent {
  readonly date = new Date();
  readonly dateFim = new Date(new Date().setDate(new Date().getDate() + 1));
  readonly ID_INSTRUCAO_LENGTH_MAX = 32;
  readonly ID_INSTRUCAO_LENGTH_MIM = 20;
  readonly TIPO_CONSULTA_LENGTH = 8;
  readonly formCamt052 = this.fb.group({
    tipoArquivo: ['REL', [Validators.required]], // 'REL' | 'TRD' | 'TRT' | 'CSA' | 'CRE'
    dataInicialResultado: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      [Validators.required],
    ],
    dataFinalResultado: [
      moment([
        this.dateFim.getFullYear(),
        this.dateFim.getMonth(),
        this.dateFim.getDate().valueOf(),
      ]),
      [Validators.required,]
    ],
    horarioInicialResultado: ['', [Validators.required, Validators.minLength(8)]], // hh:mm:ss
    horarioFinalResultado: ['', [Validators.required, Validators.minLength(8)]], // hh:mm:ss
  }
    , {
      validators: [intervaloDataValidator]
    }
  );

  readonly formCamt052Trd = this.fb.group({
    tipoArquivo: ['TRD', [Validators.required]], // 'REL' | 'TRD' | 'TRT' | 'CSA' | 'CRE'
    dataInicialResultado: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      [Validators.required],
    ],
  });
  readonly formCamt052Trt = this.fb.group({
    tipoArquivo: ['TRT', [Validators.required]], // 'REL' | 'TRD' | 'TRT' | 'CSA' | 'CRE'
    dataInicialResultado: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      [Validators.required],
    ],
  });
  readonly formCamt053Csa = this.fb.group({
    tipoArquivo: ['CSA', [Validators.required]], // 'REL' | 'TRD' | 'TRT' | 'CSA' | 'CRE'
    dataInicialCsa: [null],
  });
  readonly formCamt053Cre = this.fb.group({
    tipoArquivo: ['CRE', [Validators.required]], // 'REL' | 'TRD' | 'TRT' | 'CSA' | 'CRE'
    dataInicialResultado: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      [Validators.required],
    ],
  });
  readonly formCamt053 = this.fb.group({
    tipoArquivo: ['CSA'],
    dataInicialResultado: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      [Validators.required],
    ],
    dataInicialCsa: [null],
  });
  readonly formCamt054 = this.fb.group({
    idInstrucao: [
      '',
      [
        Validators.required,
        Validators.minLength(this.ID_INSTRUCAO_LENGTH_MIM),
        Validators.maxLength(this.ID_INSTRUCAO_LENGTH_MAX),
        alphaNumericValidator,
      ],
    ],
  });
  readonly form = this.fb.group({
    tipoConsulta: ['CAMT.052', [Validators.required]], // camt.052 | camt.053 | camt.054
    data: this.formCamt052,
  });
  readonly tipoConsulta$ = this.form.get('tipoConsulta').valueChanges.pipe(
    startWith(this.form.get('tipoConsulta').value),
    tap((tipoConsulta) => {
      switch (tipoConsulta) {
        case 'CAMT.052': {
          this.form.setControl('data', this.formCamt052);
          break;
        }
        case 'CAMT.053': {
          this.form.setControl('data', this.formCamt053);
          break;
        }
        case 'CAMT.054': {
          this.form.setControl('data', this.formCamt054);
          break;
        }
      }
    }),

  );

  public tipArc = 'REL';
  public tipArc053 = 'CSA';

  constructor(private fb: FormBuilder) {
    super();
  }

  get idInstrucao() {
    return this.form.get('data').get('idInstrucao');
  }

  changeForm(select: string) {
    this.tipArc = select;
    let tipo = {
      'REL': this.formCamt052,
      'TRD': this.formCamt052Trd,
      'TRT': this.formCamt052Trt
    };
    this.form.setControl('data', tipo[select]);
  }

  changeForm053(select: string) {
    this.tipArc053 = select;
    let tipo = {
      'CSA': this.formCamt053Csa,
      'CRE': this.formCamt053Cre
    };
    this.form.setControl('data', tipo[select]);
  }
}
