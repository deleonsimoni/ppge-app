import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { map, catchError } from 'rxjs/operators';
import { ProcessamentoContabil } from '@app/valida-movimento/valida-movimento.model';

@Injectable({
  providedIn: 'root',
})
export class ControleProcessamentoService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_PROCESSAMENTO_CONTABIL = `${this.URL_PIX_GESTAO}/contabil/processamento-contabil`;

  constructor(private http: HttpClient, public datepipe: DatePipe) {}

  public putControleProcessamento(
    params: ProcessamentoContabil,
  ): Observable<boolean> {
    return this.http
      .put<boolean>(`${this.URL_PROCESSAMENTO_CONTABIL}/${params.id}`, params, {
        observe: 'response',
      })
      .pipe(
        map((response) => response.status === 200),
        catchError((err) => {
          throw err.error.errorMessage;
        }),
      );
  }

  /* 
  public postRoteiroContabil(roteiroContabil: RoteiroContabil):Observable<boolean> {
    return this.http.post<boolean>(this.URL_CONTABIL, roteiroContabil, { observe: 'response'}).pipe(map((response) => response.status === 201));
  } */
}
