import { ChangeDetectionStrategy, Component, Inject, ViewChild } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Validators, FormBuilder, NgForm } from '@angular/forms';

@Component({
  selector: 'app-processamento-dialog',
  templateUrl: './processamento-dialog.component.html',
  styleUrls: ['./processamento-dialog.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProcessamentoDialogComponent {
  constructor(private fb: FormBuilder,
    @Inject(MAT_DIALOG_DATA) public data,
  ) {
    data = data.dados;
    console.log(data);
  }

  readonly form = this.fb.group({
    id: [this.data.dados.id],
    situacaoAprovacao: [this.data.dados.situacaoAprovacao , Validators.required],
    situacaoProcessamento: [this.data.dados.situacaoProcessamento , Validators.required],
  });
}
