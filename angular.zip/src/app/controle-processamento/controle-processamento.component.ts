import { Component, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { Processamento, Aprovacao } from '@app/valida-movimento/valida-movimento.model';
import { BehaviorSubject } from 'rxjs';
import { Validators, FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ValidaMovimentoService } from '@app/valida-movimento/valida-movimento.service';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';
import { ProcessamentoDialogComponent } from './processamento-dialog/processamento-dialog.component';
import { PageEvent } from '@angular/material/paginator';
import { ControleProcessamentoService } from './controle-processamento.service';
import { SnackbarService } from '@core/services';
import { take } from 'rxjs/operators';
import { LoginService } from '@store/login';

@Component({
  selector: 'app-controle-processamento',
  templateUrl: './controle-processamento.component.html',
  styleUrls: ['./controle-processamento.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ControleProcessamentoComponent {
  readonly processamento = Processamento;
  readonly aprovacao = Aprovacao;
  readonly date = new Date(new Date().setDate(new Date().getDate() - 1));
  readonly data$ = new BehaviorSubject<any>(null);

  readonly form = this.fb.group({
    data: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
  });

  header = ['data', 'aprovacao', 'processamento', 'acao'];

  constructor(
    public dialog: MatDialog,
    private fb: FormBuilder,
    private validaMovimentoService: ValidaMovimentoService,
    private controleProcessamentoService: ControleProcessamentoService,
    public datepipe: DatePipe,
    private snackbarService: SnackbarService,
    public loginService: LoginService
  ) {}

  getData(date: Date) {
    return this.datepipe.transform(date, 'dd/MM/yyyy');
  }

  onSubmit(): void {
    this.validaMovimentoService
      .getProcessamentoContabil(
        this.getData(this.form.value.data),
        this.getData(this.form.value.data),
      )
      .subscribe((consulta) => {
        this.data$.next(consulta);
      });
  }

  onOpenDialog(dados): void {
    const dialogRef = this.dialog.open(ProcessamentoDialogComponent, {
      data: { dados },
    });

    dialogRef.afterClosed().pipe(take(1)).subscribe((result) => {
      this.controleProcessamentoService.putControleProcessamento(result).pipe(take(1)).subscribe(
        (response) => {
          if (response) {
            this.snackbarService.open('Processamento gravado com sucesso!', 'success');
            this.onSubmit();
          }
        },
        (error) => {
          this.snackbarService.open('Erro ao gravar o processamento: ' + error, 'error');
        },
      );
    });

  }
}
