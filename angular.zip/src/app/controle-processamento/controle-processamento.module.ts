import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ControleProcessamentoRoutingModule } from './controle-processamento-routing.module';
import { ProcessamentoDialogComponent } from './processamento-dialog/processamento-dialog.component';
import { ControleProcessamentoComponent } from './controle-processamento.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgxCurrencyModule } from 'ngx-currency';
import { NgxMaskModule } from 'ngx-mask';
import { MatButtonModule } from '@angular/material/button';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatTableModule } from '@angular/material/table';


@NgModule({
  declarations: [ControleProcessamentoComponent, ProcessamentoDialogComponent],
  imports: [
    CommonModule,
    ControleProcessamentoRoutingModule,
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatDatepickerModule,
    MatDialogModule,
    MatGridListModule,
    MatInputModule,
    MatListModule,
    MatRadioModule,
    MatSelectModule,
    MatSnackBarModule,
    MatTooltipModule,
    NgxCurrencyModule,
    NgxMaskModule.forRoot(),
    MatButtonModule,
    MatPaginatorModule,
    MatTableModule
  ]
})
export class ControleProcessamentoModule { }
