import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ControleProcessamentoComponent } from './controle-processamento.component';


const routes: Routes = [
  {
    path: '',
    component: ControleProcessamentoComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ControleProcessamentoRoutingModule { }
