import {
  ChangeDetectionStrategy,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  Output,
} from '@angular/core';
import {
  Camt054Status,
  ISPB,
  ISPBInstituicao,
  Pacs002Status,
  Pacs002ReasonCode,
  Reda016ErrorCode,
  Reda016Status,
  Pacs004Devolucao,
  DetalheMensagemUnion,
  Reda014Status,
} from '@app/mensageria/mensageria.model';
import { Mensagem, DetalhePibr001, DetalheAdmi002, DetalheCamt052, DetalheCamt053, DetalheCamt054, DetalheCamt060, DetalhePacs002, DetalhePacs004, DetalhePacs008, DetalhePibr002, DetalheReda022, DetalheReda016, DetalheReda014, DetalheReda031 } from '@app/consulta/por-servico/por-servico.model';
import { PorServicoService } from '@app/consulta/por-servico/por-servico.service';
import { tap } from 'rxjs/operators';
import { SnackbarService } from '@core/services';

@Component({
  selector: 'app-mensagem',
  templateUrl: './mensagem.component.html',
  styleUrls: ['./mensagem.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MensagemComponent implements OnChanges {

  constructor(
    private porServicoService: PorServicoService,
    private snackbarService: SnackbarService,
  ) {}

  @Input() mensagem: Mensagem;
  @Output() openDialog = new EventEmitter<Mensagem>();
  error = false;
  readonly ispbEnum = ISPB;
  readonly reasonCodeEnum = Pacs002ReasonCode;
  readonly statusEnum = Pacs002Status;
  readonly statusCamt054Enum = Camt054Status;
  readonly devolucaoEnum = Pacs004Devolucao;
  readonly statusReda016Enum = Reda016Status;
  readonly errorReda016Enum = Reda016ErrorCode;
  readonly errorReda014Enum = Reda014Status;
  readonly ispbs = ISPBInstituicao;

  ngOnChanges() {
    this.error = this.isError();
  }

  private isError() {
    return (
      this.mensagem.codMensagem === 'ADMI.002' ||
      (this.mensagem.codMensagem === 'PACS.002' &&
        (this.mensagem.detalhe as DetalhePacs002).situacaoTransacao === 'RJCT')
    );
  }

  onDownloadArquivo(nomeArquivo: string, idMensagemOriginal: string){
    this.porServicoService
      .getDownloadArquivo(nomeArquivo, idMensagemOriginal)
      .pipe(
        tap(blob => {
          const a = document.createElement('a')
          const objectUrl = URL.createObjectURL(blob)
          a.href = objectUrl
          a.download = nomeArquivo + '.zip';
          a.click();
          URL.revokeObjectURL(objectUrl);
        },
        (error) => {
          this.snackbarService.open('Erro ao realizar download do arquivo!', 'error');
        },
        ),
      )
      .subscribe();
  }

  asAdmi002(mensagem: Mensagem): DetalheAdmi002 {
    return mensagem.detalhe as DetalheAdmi002;
  }

  asCamt052(mensagem: Mensagem): DetalheCamt052 {
    return mensagem.detalhe as DetalheCamt052;
  }

  asCamt053(mensagem: Mensagem): DetalheCamt053 {
    return mensagem.detalhe as DetalheCamt053;
  }

  asCamt054(mensagem: Mensagem): DetalheCamt054 {
    return mensagem.detalhe as DetalheCamt054;
  }

  asCamt060(mensagem: Mensagem): DetalheCamt060 {
    return mensagem.detalhe as DetalheCamt060;
  }

  asPacs002(mensagem: Mensagem): DetalhePacs002 {
    return mensagem.detalhe as DetalhePacs002;
  }

  asPacs004(mensagem: Mensagem): DetalhePacs004 {
    return mensagem.detalhe as DetalhePacs004;
  }

  asPacs008(mensagem: Mensagem): DetalhePacs008 {
    return mensagem.detalhe as DetalhePacs008;
  }

  asPibr001(mensagem: Mensagem): DetalhePibr001 {
    return mensagem.detalhe as DetalhePibr001;
  }

  asPibr002(mensagem: Mensagem): DetalhePibr002 {
    return mensagem.detalhe as DetalhePibr002;
  }

  asReda022(mensagem: Mensagem): DetalheReda022 {
    return mensagem.detalhe as DetalheReda022;
  }
  
  asReda031(mensagem: Mensagem): DetalheReda031 {
    return mensagem.detalhe as DetalheReda031;
  }

  asReda016(mensagem: Mensagem): DetalheReda016 {
    return mensagem.detalhe as DetalheReda016;
  }

  asReda014(mensagem: Mensagem): DetalheReda014 {
    return mensagem.detalhe as DetalheReda014;
  }

  onClick(): void {
    this.openDialog.emit(this.mensagem);
  }
}
