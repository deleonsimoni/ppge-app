import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, from } from 'rxjs';
import { combineAll, map, switchMap } from 'rxjs/operators';
import {
  Devolucao,
  LancamentoCamt054,
  MensagemResponse,
  TipoConta,
  XmlAdmi002,
  XmlCamt052,
  XmlCamt053,
  XmlCamt054,
  XmlCamt060,
  XmlPacs002,
  XmlPacs008,
  XmlPibr001,
  XmlPibr002,
  XmlPacs004,
  DetalheMensagemUnion,
} from '@app/mensageria/mensageria.model';
import { environment } from '@env/environment';
import { Mensagem } from '@app/consulta/por-servico/por-servico.model';
import { PorServicoService } from '@app/consulta/por-servico/por-servico.service';

@Injectable({
  providedIn: 'root',
})
export class MensagensService {
  private readonly URL = `${environment.urlPixGestao}/simpi-pix-gestao/mensagens`;

  constructor(
    private http: HttpClient,
    private detalheService: PorServicoService,
  ) {}

  getMensagens(idMensagem: string): Observable<Mensagem[]> {
    return this.http
      .get<Mensagem[]>(
        `${this.URL}/${idMensagem}/mensagens-relacionadas?retorna-detalhe=true&retorna-original=true`,
      );
  }

  private getParametroTipoMensagem(idFimAFim: string): string {
    switch (idFimAFim.charAt(0)) {
      case 'D':
      case 'M':
        return 'mensagem-original';
      case 'P':
        return 'texto-original';
      case 'E':
      default:
        return 'endToEndId';
    }
  }
}
