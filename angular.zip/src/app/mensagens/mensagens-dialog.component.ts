import { ChangeDetectionStrategy, Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Mensagem } from '@app/consulta/por-servico/por-servico.model';


@Component({
  selector: 'app-mensagens-dialog',
  templateUrl: 'mensagens-dialog.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MensagensDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<MensagensDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public mensagem: Mensagem,
  ) {}
/*
  asPacs002(mensagem: Mensagem): MensagemPacs002 {
    return mensagem as MensagemPacs002;
  }

  asPacs008(mensagem: Mensagem): MensagemPacs008 {
    return mensagem as MensagemPacs008;
  }

  asPibr001(mensagem: Mensagem): MensagemPibr001 {
    return mensagem as MensagemPibr001;
  }

  asPibr002(mensagem: Mensagem): MensagemPibr002 {
    return mensagem as MensagemPibr002;
  } */
}
