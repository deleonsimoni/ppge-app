import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { BehaviorSubject, EMPTY } from 'rxjs';
import { delay, expand, filter, switchMap, take } from 'rxjs/operators';
import { MensagensService } from './mensagens.service';
import { MensagensDialogComponent } from './mensagens-dialog.component';
import { Mensagem } from '@app/consulta/por-servico/por-servico.model';

@Component({
  selector: 'app-mensagens',
  templateUrl: './mensagens.component.html',
  styleUrls: ['./mensagens.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MensagensComponent {
  @Input() set idMensagem(idMensagem: string) {
    this.idMensagem$.next(idMensagem);
  }
  readonly idMensagem$: BehaviorSubject<string> = new BehaviorSubject(null);
  readonly mensagens$ = this.idMensagem$.pipe(
    filter((idMensagem) => idMensagem !== null),
    switchMap((idMensagem) =>
      this.mensagensService.getMensagens(idMensagem).pipe(
        expand((mensagens) => {
          if (mensagens.length <= 1) {
            return this.mensagensService
              .getMensagens(idMensagem)
              .pipe(delay(1500));
          }
          return EMPTY;
        }),
      ),
    ),
  );
  private dialogRef: MatDialogRef<MensagensDialogComponent>;

  constructor(
    public dialog: MatDialog,
    private mensagensService: MensagensService,
  ) {}

  onOpenDialog(mensagem: Mensagem): void {
    if (!this.dialogRef) {
      this.dialogRef = this.dialog.open(MensagensDialogComponent, {
        data: mensagem,
      });
      this.dialogRef.afterClosed().pipe(take(1)).subscribe(() => (this.dialogRef = null));
    }
  }
}
