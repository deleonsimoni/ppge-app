import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatDialogModule } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { HighlightModule } from 'ngx-highlightjs';
import { PrettyXMLPipeModule } from '@core/pipes/pretty-xml/pretty-xml.module';
import { MensagensComponent } from './mensagens.component';
import { MensagensDialogComponent } from './mensagens-dialog.component';
import { MensagemComponent } from './mensagem/mensagem.component';
import { MatButtonModule } from '@angular/material/button';
import { TipoSaldoPipeModule } from '@core/pipes/tipo-saldo/tipo-saldo-pipe.module';

@NgModule({
  declarations: [
    MensagensComponent,
    MensagensDialogComponent,
    MensagemComponent
  ],
  imports: [
    CommonModule,
    MatDialogModule,
    MatTooltipModule,
    HighlightModule,
    PrettyXMLPipeModule,
    MatButtonModule,
    TipoSaldoPipeModule
  ],
  exports: [MensagensComponent],
})
export class MensagensModule {}
