import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import {
  SnackbarComponent,
  SnackbarTemplateComponent,
} from './snackbar.component';

@NgModule({
  imports: [CommonModule, MatSnackBarModule],
  declarations: [SnackbarComponent, SnackbarTemplateComponent],
  exports: [SnackbarComponent],
})
export class SnackbarModule {}
