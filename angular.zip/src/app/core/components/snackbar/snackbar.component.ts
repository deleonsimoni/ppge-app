import { ChangeDetectionStrategy, Component, Inject } from '@angular/core';
import { filter, tap } from 'rxjs/operators';
import { MAT_SNACK_BAR_DATA, MatSnackBar } from '@angular/material/snack-bar';
import { Snackbar } from '@typings/snackbar';
import { SnackbarService } from '@core/services';

@Component({
  selector: 'app-snackbar-template',
  template: '<span [class]="snackbar.type">{{ snackbar.message }}</span>',
  styleUrls: ['./snackbar-template.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SnackbarTemplateComponent {
  constructor(@Inject(MAT_SNACK_BAR_DATA) public snackbar: Snackbar) {}
}

@Component({
  selector: 'app-snackbar',
  template: '<ng-container *ngIf="snackbar$ | async"></ng-container>',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SnackbarComponent {
  readonly snackbar$ = this.snackbarService.getSnackbar().pipe(
    filter((snackbar) => snackbar !== null),
    tap((snackbar) => {
      this.snackbar.openFromComponent(SnackbarTemplateComponent, {
        data: snackbar,
        duration: 5000,
        horizontalPosition: 'right',
        verticalPosition: 'top',
        panelClass: [`snack-${snackbar.type}`],
      });
    }),
  );

  constructor(
    private snackbar: MatSnackBar,
    private snackbarService: SnackbarService,
  ) {}
}
