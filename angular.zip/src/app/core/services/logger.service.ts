import { Injectable } from '@angular/core';
import { environment } from '@env/environment';

// tslint:disable:no-console
@Injectable({
  providedIn: 'root',
})
export class LoggerService {
  debug(...args: any[]): void {
    if (environment.ambiente !== 'PRD') {
      console.debug(...args);
    }
  }
  error(...args: any[]): void {
    if (environment.ambiente !== 'PRD') {
      console.error(...args);
    }
  }

  info(...args: any[]): void {
    if (environment.ambiente !== 'PRD') {
      console.info(...args);
    }
  }

  log(...args: any[]): void {
    if (environment.ambiente !== 'PRD') {
      console.log(...args);
    }
  }

  warn(...args: any[]): void {
    if (environment.ambiente !== 'PRD') {
      console.warn(...args);
    }
  }
}
