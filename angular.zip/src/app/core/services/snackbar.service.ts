import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { Snackbar } from '@typings/snackbar';

@Injectable({
  providedIn: 'root',
})
export class SnackbarService {
  private snackbar = new BehaviorSubject<Snackbar>(null);

  open(message: string, type: 'error' | 'info' | 'success' = 'info'): void {
    this.snackbar.next({ message, type });
  }

  getSnackbar(): Observable<Snackbar> {
    return this.snackbar.asObservable();
  }
}
