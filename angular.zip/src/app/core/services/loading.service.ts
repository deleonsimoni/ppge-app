import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class LoadingService {
  private loadingSubject = new Subject<boolean>();
  private count = 0;

  addRequestCount() {
    this.count += 1;
    this.updateLoading();
  }

  addResponseCount() {
    this.count -= 1;
    this.updateLoading();
  }

  isLoading(): Observable<boolean> {
    return this.loadingSubject.asObservable();
  }

  private updateLoading() {
    this.loadingSubject.next(this.count !== 0);
  }
}
