import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import * as xml2js from 'xml2js';

@Injectable({
  providedIn: 'root',
})
export class XmlToJsService {
  private xml2js = new xml2js.Parser({
    explicitArray: false,
    ignoreAttrs: true,
  });

  parse(xml: string): Observable<object> {
    return new Observable<object>((observer) => {
      this.xml2js
        .parseStringPromise(xml)
        .then((result) => {
          observer.next(result);
          observer.complete();
        })
        .catch((error) => observer.error(error));
    });
  }
}
