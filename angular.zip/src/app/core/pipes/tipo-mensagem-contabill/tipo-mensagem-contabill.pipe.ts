import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'tipoMensagemContabil'})
export class TipoMensagemContabilPipe implements PipeTransform {
  transform(value: string): string {
    let tipo = {
      '1': 'PACS008',
      '2': 'PACS004',
      '3': 'LPI',
      '4': 'LPI'
    };

    return tipo[value];
  }
}