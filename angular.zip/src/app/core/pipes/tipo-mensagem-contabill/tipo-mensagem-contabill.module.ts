import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TipoMensagemContabilPipe } from './tipo-mensagem-contabill.pipe';

@NgModule({
  imports: [CommonModule],
  declarations: [TipoMensagemContabilPipe],
  exports: [TipoMensagemContabilPipe],
})
export class TipoMensagemContabilModule {}