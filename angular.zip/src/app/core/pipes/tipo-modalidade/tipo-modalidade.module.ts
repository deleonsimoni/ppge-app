import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TipoModalidadePipe } from './tipo-modalidade.pipe';

@NgModule({
  declarations: [
    TipoModalidadePipe
  ],
  exports:[TipoModalidadePipe],
  imports: [
    CommonModule
  ]
})
export class TipoModalidadeModule { }
