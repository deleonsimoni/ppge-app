import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'tipoModalidade'
})
export class TipoModalidadePipe implements PipeTransform {

  transform(value: string): string {
    let tipo = {
      '0': 'SEM MODALIDADE',
      '1': 'PDCT (Provedor de Conta Transacional)',
      '2': 'LESP (Liquidante Especial)',
      '3': 'GOVE (Ente Governamental)'
    };

    return tipo[value];
  }

}
