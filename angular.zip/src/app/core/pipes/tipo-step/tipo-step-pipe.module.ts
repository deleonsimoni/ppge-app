import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TipoStepPipe } from './tipo-step.pipe';

@NgModule({
  imports: [CommonModule],
  declarations: [TipoStepPipe],
  exports: [TipoStepPipe],
})
export class TipoStepPipeModule {}
