import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'tipoStep'})
export class TipoStepPipe implements PipeTransform {
  transform(value: string): string {
    let tipo = {
      'solicitacaoCamt60AndCamt052Step': 'SOLICITAÇÃO CAMT60/CAMT52',
      'downloadFileStep': 'DOWNLOAD DO ARQUIVO',
      'uncompressStep': 'UNZIP DO ARQUIVO',
      'leituraArquivoRelacaoLancamentoStep': 'LEITURA DO ARQUIVO',
      'atualizarSaldoStep': 'ATUALIZAÇÃO SALDO',
      'deletedFileStep': 'EXCLUSÃO DO ARQUIVO',
      'reprocessarStep': 'EXECUÇÃO REPROCESSAR'
    };

    return tipo[value];
  }
}