import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TipoSaldoPipe } from './tipo-saldo.pipe';

@NgModule({
  imports: [CommonModule],
  declarations: [TipoSaldoPipe],
  exports: [TipoSaldoPipe],
})
export class TipoSaldoPipeModule {}
