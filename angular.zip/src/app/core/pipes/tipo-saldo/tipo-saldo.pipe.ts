import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'tipoSaldo'})
export class TipoSaldoPipe implements PipeTransform {
  transform(value: string): string {
    let tipo = {
      'SADP': 'Saldo Disponível',
      'SABK': 'Saldo Bloqueado',
      'REMN': 'Valor Efetivo da Remuneração',
      'PSSR': 'Parcela do Saldo Sujeito à Remuneração',
      'VSME': 'Valor do Percentual dos Saldos de Moedas Eletrônicas',
      'VVSR': 'Valor do Percentual da Média do VSR'
    };

    return tipo[value];
  }
}