import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PrettyXMLPipe } from './pretty-xml.pipe';

@NgModule({
  imports: [CommonModule],
  declarations: [PrettyXMLPipe],
  exports: [PrettyXMLPipe],
})
export class PrettyXMLPipeModule {}
