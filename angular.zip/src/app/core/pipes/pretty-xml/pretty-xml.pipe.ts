import { Pipe, PipeTransform } from '@angular/core';

@Pipe({ name: 'prettyXML' })
export class PrettyXMLPipe implements PipeTransform {
  static createShiftArr(step: number | string) {
    let space = '';
    if (typeof step === 'number') {
      // argument is integer
      for (let i = 0; i < step; i++) {
        space += ' ';
      }
    } else {
      // argument is string
      space = step;
    }

    const shift = ['\n']; // array of shifts

    for (let ix = 0; ix < 100; ix++) {
      shift.push(shift[ix] + space);
    }

    return shift;
  }

  transform(xml: string, indent: number = 2) {
    const arr = xml
      .replace(/>\s*</gm, '><')
      .replace(/</g, '~::~<')
      .replace(/\s*xmlns([=:])/g, '~::~xmlns$1')
      .split('~::~');

    const len = arr.length;
    let inComment = false;
    let depth = 0;
    let str = '';
    const shift = PrettyXMLPipe.createShiftArr(indent);

    for (let i = 0; i < len; i++) {
      // start comment or <![CDATA[...]]> or <!DOCTYPE //
      if (arr[i].indexOf('<!') !== -1) {
        str += shift[depth] + arr[i];
        inComment = true;

        // end comment or <![CDATA[...]]> //
        if (
          arr[i].indexOf('-->') !== -1 ||
          arr[i].indexOf(']>') !== -1 ||
          arr[i].indexOf('!DOCTYPE') !== -1
        ) {
          inComment = false;
        }
      } else if (arr[i].indexOf('-->') !== -1 || arr[i].indexOf(']>') !== -1) {
        // end comment  or <![CDATA[...]]> //
        str += arr[i];
        inComment = false;
      } else if (
        /^<\w/.test(arr[i - 1]) &&
        /^<\/\w/.test(arr[i]) && // <elm></elm> //
        /^<[\w:\-.,]+/.exec(arr[i - 1])[0] ===
          /^<\/[\w:\-.,]+/.exec(arr[i])[0].replace('/', '')
      ) {
        str += arr[i];
        if (!inComment) {
          depth--;
        }
      } else if (
        arr[i].search(/<\w/) !== -1 &&
        arr[i].indexOf('</') === -1 &&
        arr[i].indexOf('/>') === -1
      ) {
        // <elm> //
        str += !inComment ? shift[depth++] + arr[i] : arr[i];
      } else if (arr[i].search(/<\w/) !== -1 && arr[i].indexOf('</') !== -1) {
        // <elm>...</elm> //
        str += !inComment ? shift[depth] + arr[i] : arr[i];
      } else if (arr[i].search(/<\//) > -1) {
        // </elm> //
        str += !inComment ? shift[--depth] + arr[i] : arr[i];
      } else if (arr[i].indexOf('/>') !== -1) {
        // <elm/> //
        str += !inComment ? shift[depth] + arr[i] : arr[i];
      } else if (arr[i].indexOf('<?') !== -1) {
        // <? xml ... ?> //
        str += shift[depth] + arr[i];
      } else if (
        arr[i].indexOf('xmlns:') !== -1 ||
        arr[i].indexOf('xmlns=') !== -1
      ) {
        // xmlns //
        str += shift[depth] + arr[i];
      } else {
        str += arr[i];
      }
    }

    return str.trim();
  }
}
