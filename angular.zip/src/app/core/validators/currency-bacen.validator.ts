import { AbstractControl } from '@angular/forms';

export const currencyBacenValidator = (
  control: AbstractControl,
): { [key: string]: boolean } | null => {
  const input = control.value;

  if (input) {
    const invalid = !isCurrencyBacenValid(input);
    return invalid ? { currencyBacen: true } : null;
  }
};

export const isCurrencyBacenValid = (value: number): boolean => {
  const MAX_CURRENCY_LENGTH_BACEN = 18;
  return (
    value.toLocaleString('pt-br', {
      minimumFractionDigits: 2,
      useGrouping: false,
    }).length <= MAX_CURRENCY_LENGTH_BACEN
  );
};
