import { AbstractControl } from '@angular/forms';

export const alphaNumericValidator = (
  control: AbstractControl,
): { [key: string]: boolean } | null => {
  const input = control.value;

  if (input) {
    const regexp = /^[a-zA-Z0-9 ]*$/;
    const invalid = !regexp.test(control.value);
    return invalid ? { alphaNumeric: true } : null;
  }
};
