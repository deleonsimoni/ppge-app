import { AbstractControl } from '@angular/forms';

export const numericValidator = (
  control: AbstractControl,
): { [key: string]: boolean } | null => {
  const input = control.value;

  if (input) {
    const regexp = /^[0-9]+$/;
    const invalid = !regexp.test(control.value);
    return invalid ? { numeric: true } : null;
  }
};
