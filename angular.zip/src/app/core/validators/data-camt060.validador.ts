import { AbstractControl, ValidationErrors } from '@angular/forms';
import * as moment from 'moment';


export const intervaloDataValidator =
    (formGroup: AbstractControl): ValidationErrors | null => {
        const dataInicialResultado = moment(formGroup.get('dataInicialResultado').value).format('YYYY-MM-DD');
        const dataFinalResultado = moment(formGroup.get('dataFinalResultado').value).format('YYYY-MM-DD');
        
        const horarioInicialResultado = formGroup.get('horarioInicialResultado').value;
        const horarioFinalResultado = formGroup.get('horarioFinalResultado').value;

        const dataInicial = horarioInicialResultado && horarioInicialResultado.length == 8? new Date(`${dataInicialResultado}T${horarioInicialResultado}Z`): new Date(dataInicialResultado);

        const dataFinal = horarioFinalResultado && horarioFinalResultado.length == 8 ? new Date(`${dataFinalResultado}T${horarioFinalResultado}Z`): new Date(dataFinalResultado);

        const diferencaEmHoras =
            (dataFinal.getTime() - dataInicial.getTime())
            / (1000 * 60 * 60 );
        

        return diferencaEmHoras > 24
            ? {
                intervaloData: {
                    atual: diferencaEmHoras,
                    max: 24
                }
            }
            : null;
    };