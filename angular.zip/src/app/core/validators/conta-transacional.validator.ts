import { AbstractControl } from '@angular/forms';
import { isInscricaoValida } from './inscricao.validator';

export const contaTransacionalValidator = (
  control: AbstractControl,
): { [key: string]: boolean } | null => {
  const input = control.value;

  if (input) {
    const isTelephone = /^\+?[1-9]\d{1,14}$/.test(input);
    const isEmail =
      input.length <= 77 &&
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(input);
    const isEVP = /^[0-9A-Fa-f]{32}$/.test(input);

    const invalid = !(
      isTelephone ||
      isEmail ||
      isInscricaoValida(input) ||
      isEVP
    );
    return invalid ? { contaTransacional: true } : null;
  }
};
