import { AbstractControl } from '@angular/forms';

export const inscricaoValidator = (
  control: AbstractControl,
): { [key: string]: boolean } | null => {
  const input = control.value;

  if (input) {
    const invalid = !isInscricaoValida(input);
    return invalid ? { inscricao: true } : null;
  }
};

export const isInscricaoValida = (valor: string): boolean => {
  const inscricao = valor.replace(/[^0-9]/g, '');

  // inscrições inválidas como 111.111.111-11
  if (inscricao.match(/^([0-9])\1{10,10}$|^([0-9])\2{13,13}$/g) !== null) {
    return false;
  }

  if (inscricao.length !== 11 && inscricao.length !== 14) {
    return false;
  }

  const inscricaoSemDV = inscricao.slice(0, -2);
  return calculaInscricao(inscricaoSemDV) === inscricao;
};

export const calculaInscricao = (digitos: string): string => {
  if (digitos.length === 11 || digitos.length === 14) {
    return digitos;
  }

  let soma = 0;
  let posicao = {
    9: 10,
    10: 11,
    12: 5,
    13: 6,
  }[digitos.length];

  // Faz a soma dos dígitos com a posição
  for (const digito of digitos) {
    soma = soma + parseInt(digito, 10) * posicao;
    posicao -= 1;

    // Parte específica para CNPJ
    // Ex.: 5-4-3-2-9-8-7-6-5-4-3-2
    if (posicao < 2) {
      posicao = 9;
    }
  }

  soma = soma % 11;

  if (soma < 2) {
    soma = 0;
  } else {
    // Se for maior que 2, o resultado é 11 menos soma
    // Ex.: 11 - 9 = 2
    // Nosso dígito procurado é 2
    soma = 11 - soma;
  }

  return calculaInscricao(digitos + soma);
};
