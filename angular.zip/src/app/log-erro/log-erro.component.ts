import { Component, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { PageEvent } from '@angular/material/paginator';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import { LogErroService } from './log-erro.service';

@Component({
  selector: 'app-log-erro',
  templateUrl: './log-erro.component.html',
  styleUrls: ['./log-erro.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LogErroComponent {
  readonly date = new Date(new Date().setDate(new Date().getDate()));
  readonly data$ = new BehaviorSubject<any>(null);
  readonly modulos$ = new BehaviorSubject<any>(null);

  readonly form = this.fb.group({
    dataInicio: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
    ],
    dataFim: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
    ],
    horaInicio: ['00:00:00', [Validators.required, Validators.minLength(8)]],
    horaFim: ['23:59:59', [Validators.required, Validators.minLength(8)]],
    projeto: [''],
    modulo: [1],
  });

  header = ['data', 'hora', 'funcionalidade', 'status', 'erro'];

  getData(date: Date) {
    return this.datepipe.transform(date, 'dd/MM/yyyy');
  }
  paginaAtual: number = 1;
  tamanhoPagina: number;

  constructor(
    private fb: FormBuilder,
    private logErroService: LogErroService,
    public datepipe: DatePipe,
  ) {
    this.logErroService.getModulos().subscribe((dados) => {
      this.modulos$.next(dados);
    });
  }
  onSubmit() {
    this.logErroService
      .getLogErros(
        this.de(),
        this.ate(),
        this.form.get('modulo').value,
        this.paginaAtual,
        this.tamanhoPagina,
      )
      .pipe(take(1))
      .subscribe((consulta) => {
        this.data$.next(consulta);
      });
  }

  get horaInicio() {
    return this.form.get('horaInicio');
  }

  get horaFim() {
    return this.form.get('horaFim');
  }

  private de(): string {
    if (this.form.get('dataInicio').value && this.horaInicio.value) {
      const date: moment.Moment = this.form.get('dataInicio').value;
      const horario = this.horaInicio.value.split(':');
      return new Date(
        date.year(),
        date.month(),
        date.date(),
        horario[0],
        horario[1],
        horario[2],
      ).toString();
    } else {
      return '';
    }
  }

  private ate(): string {
    if (this.form.get('dataFim').value && this.horaFim.value) {
      const date: moment.Moment = this.form.get('dataFim').value;
      const horario = this.horaFim.value.split(':');
      return new Date(
        date.year(),
        date.month(),
        date.date(),
        horario[0],
        horario[1],
        horario[2],
      ).toString();
    } else {
      return '';
    }
  }

  onPagination(event: PageEvent): void {
    this.logErroService
      .getLogErros(
        this.de(),
        this.ate(),
        this.form.get('modulo').value,
        event.pageIndex + 1,
        event.pageSize,
      )
      .pipe(take(1))
      .subscribe((consulta) => {
        this.data$.next(consulta);
      });
  }
}
