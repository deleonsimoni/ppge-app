export interface Modulo {
  id: number;
  nome: string;
  indice: string;
}
