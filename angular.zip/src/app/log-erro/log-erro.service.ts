import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { Observable } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { map, catchError } from 'rxjs/operators';
import { Erro } from './log-erro.module';
import { Modulo } from './log-erro.model';

@Injectable({
  providedIn: 'root',
})
export class LogErroService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;

  private readonly URL_CONSULTA_ERRO_MENSAGERIA = `${this.URL_PIX_GESTAO}/log-erro/consultar-erro`;
  private readonly URL_CONSULTA_ERRO_CONTABIL = `${this.URL_PIX_GESTAO}/contabil/log-erro/consultar-erro`;

  private readonly URL_MODULOS = `${this.URL_PIX_GESTAO}/log-usuario/modulos`;
  
  constructor(private http: HttpClient, public datepipe: DatePipe) {}




  getModulos(): Observable<Modulo> {
      return this.http.get<Modulo>(
        `${this.URL_MODULOS}`,
      );
    }

  public getLogErros(
    dataInicio: string,
    dataFim: string,
    modulo: number,
    page: number = 1,
    tamanhoPagina: number = 15,
  ): Observable<any> {
    if(modulo === 1){
      return this.http.get<Erro>(
        this.URL_CONSULTA_ERRO_MENSAGERIA,
        {
          params: {
            dataInicio: dataInicio,
            dataFim: dataFim,
            modulo: modulo.toString(),
            pagina: page.toString(),
            tamanhoPagina: tamanhoPagina.toString(),
          },
        },
        );
    } else {
    return this.http.get<Erro>(
      this.URL_CONSULTA_ERRO_CONTABIL,
      {
        params: {
          dataInicio: dataInicio,
          dataFim: dataFim,
          modulo: modulo.toString(),
          pagina: page.toString(),
          tamanhoPagina: tamanhoPagina.toString(),
        },
      },
      );
    }
  }
}
