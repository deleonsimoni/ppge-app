import { Component } from '@angular/core';
import { Input } from '@angular/core';
import { ChangeDetectionStrategy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';
import { disableDebugTools } from '@angular/platform-browser';
import { BehaviorSubject } from 'rxjs';
import { ValidaMovimentoService } from './valida-movimento.service';
import { PageEvent } from '@angular/material/paginator';
import { Aprovacao, Processamento } from './valida-movimento.model';
import { DatePipe } from '@angular/common';
import { take, tap } from 'rxjs/operators';
import { ValidaMovimentoDialogComponent } from './valida-movimento-dialog.component';
import { ClassificacaoManualComponent } from './classificacao-manual/classificacao-manual.component';

@Component({
  selector: 'app-valida-movimento',
  templateUrl: './valida-movimento.component.html',
  styleUrls: ['./valida-movimento.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ValidaMovimentoComponent {
  readonly processamento = Processamento;
  readonly aprovacao = Aprovacao;
  readonly date = new Date(new Date().setDate(new Date().getDate() - 1));
  readonly data$ = new BehaviorSubject<any>(null);

  readonly form = this.fb.group({
    dataInicial: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
    dataFinal: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
  });

  header = ['data', 'aprovacao', 'processamento', 'acao'];

  constructor(
    public dialog: MatDialog,
    private fb: FormBuilder,
    private validaMovimentoService: ValidaMovimentoService,
    public datepipe: DatePipe,
  ) {}

  getData(date: Date) {
    return this.datepipe.transform(date, 'dd/MM/yyyy');
  }

  onSubmit(): void {
    this.validaMovimentoService
      .getProcessamentoContabil(
        this.getData(this.form.value.dataInicial),
        this.getData(this.form.value.dataFinal),
        "true"
      )
      .pipe(take(1))
      .subscribe((consulta) => {
        this.data$.next(consulta);
      });
  }

  onOpenDialog(data: string, dados): void {
    this.validaMovimentoService
      .getProcessamentoContabilMovimento(data)
      .pipe(take(1))
      .subscribe((detalhe) => {
        const dialog = this.dialog.open(ValidaMovimentoDialogComponent, {
          data: { detalhe, dados },
          maxHeight: '800px',
          width: '1400px',
        });
        dialog.afterClosed().subscribe(() => {
          this.onSubmit();
        });
      });
  }

  onPagination(event: PageEvent): void {
    this.validaMovimentoService
      .getProcessamentoContabil(
        this.getData(this.form.value.dataInicial),
        this.getData(this.form.value.dataFinal),
        "true",
        event.pageIndex + 1,
        event.pageSize,
      )
      .pipe(take(1))
      .subscribe((dados) => {
        this.data$.next(dados);
      });
  }
}
