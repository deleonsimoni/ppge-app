import { Injectable } from '@angular/core';
import { environment } from '@env/environment';
import { Observable } from 'rxjs';
import { ValidaMovimento, ConsultaProcessamento, ParametroPesquisa, ProcessamentoPendente, ClassificacaoManual } from './valida-movimento.model';
import { HttpClient } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class ValidaMovimentoService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_PROCESSAMENTO_CONTABIL = `${this.URL_PIX_GESTAO}/contabil/processamento-contabil`;
  private readonly URL_PROCESSAMENTO_CONTABIL_MOVIMENTO = `${this.URL_PIX_GESTAO}/contabil/processamento-contabil/movimento`;
  private readonly URL_CLASSIFICACAO_MANUAL = `${this.URL_PIX_GESTAO}/contabil/classificacao-manual`;

  constructor(private http: HttpClient, public datepipe: DatePipe) {}

  public getProcessamentoContabil(
    dataInicio: string,
    dataFim: string,
    isConsultaDiasContabeis = "false",
    page: number = 1,
    tamanhoPagina: number = 15,
  ): Observable<ConsultaProcessamento> {
    return this.http.get<ConsultaProcessamento>(
      this.URL_PROCESSAMENTO_CONTABIL,
      {
        params: {
          dataInicio,
          dataFim,
          pagina: page.toString(),
          tamanhoPagina: tamanhoPagina.toString(),
          isConsultaDiasContabeis: isConsultaDiasContabeis
        },
      },
    );
  }

  public getProcessamentoContabilMovimento(
    data: string,
  ): Observable<ValidaMovimento[]> {
    return this.http.get<ValidaMovimento[]>(
      this.URL_PROCESSAMENTO_CONTABIL_MOVIMENTO,
      {
        params: { data },
      },
    );
  }

  public getClassificacaoManual(
    params: ParametroPesquisa,
    page: number = 1,
    tamanhoPagina: number = 5,
  ): Observable<ProcessamentoPendente> {
    return this.http.get<ProcessamentoPendente>(this.URL_CLASSIFICACAO_MANUAL, {
      params: {
        dataInicio: params.dataInicio,
        dataFim: params.dataFim,
        tipoMensagem: params.tipoMensagem,
        situacaoProcessamento: params.situacaoProcessamento,
        tipoLancamento: params.tipoLancamento,
        pagina: page.toString(),
        tamanhoPagina: tamanhoPagina.toString(),
      },
    });
  }

  public getClassificacaoManualFiltro(
    params: ParametroPesquisa,
    page: number = 1,
    tamanhoPagina: number = 15,
  ): Observable<ProcessamentoPendente> {
    return this.http.get<ProcessamentoPendente>(this.URL_CLASSIFICACAO_MANUAL, {
      params: {
        dataInicio: this.datepipe.transform(params.dataInicio, 'dd/MM/yyyy'),
        dataFim: this.datepipe.transform(params.dataFim, 'dd/MM/yyyy'),
        valorInicio: params.valorInicio.toString(),
        valorFim: params.valorFim.toString(),
        tipoMensagem: params.tipoMensagem,
        pagina: page.toString(),
        tamanhoPagina: tamanhoPagina.toString(),
      },
    });
  }

  public postClassificacaoManual(
    classificacao: ClassificacaoManual,
    idLancamento: string
  ): Observable<boolean> {
    return this.http
      .post(
        `${this.URL_CLASSIFICACAO_MANUAL}/${idLancamento}`,
        classificacao,
        { observe: 'response' },
      )
      .pipe(
        map((response) => response.status === 200),
        catchError((err) => {
          throw err.error.errorMessage;
        }),
      );
  }
}
