import { ChangeDetectionStrategy, Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from '@angular/material/dialog';
import {
  ParametroPesquisa,
  ProcessamentoPendente,
} from './valida-movimento.model';
import { ValidaMovimentoService } from './valida-movimento.service';
import { BehaviorSubject } from 'rxjs';
import { SnackbarService } from '@core/services';
import { ProcessamentoContabil } from '@app/valida-movimento/valida-movimento.model';
import { ControleProcessamentoService } from '@app/controle-processamento/controle-processamento.service';
import { LoginService } from '@store/login';

@Component({
  selector: 'app-valida-movimento-dialog',
  templateUrl: 'valida-movimento-dialog.component.html',
  styleUrls: ['./valida-movimento.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ValidaMovimentoDialogComponent {
  constructor(
    @Inject(MAT_DIALOG_DATA) public data,
    public dialog: MatDialogRef<ValidaMovimentoDialogComponent>,
    private validaMovimentoService: ValidaMovimentoService,
    private controleProcessamentoService: ControleProcessamentoService,
    private snackbarService: SnackbarService,
    public loginService: LoginService
  ) {}

  mostraClassificacao = false;
  readonly msgPendente$ = new BehaviorSubject<ProcessamentoPendente>(null);
  msgPendente: ProcessamentoPendente;
  params: ParametroPesquisa;

  abrirClassificacaoManual(dados, situacaoProcessamento: string): void {
    this.params = {
      dataInicio: this.data.detalhe.dataMovimento,
      dataFim: this.data.detalhe.dataMovimento,
      tipoMensagem: dados.tipoMensagem,
      situacaoProcessamento,
      tipoLancamento: dados.tipoLancamento,
    };
    this.validaMovimentoService
      .getClassificacaoManual(this.params)
      .subscribe((dados) => {
        this.msgPendente$.next(dados);
      });
    this.mostraClassificacao = true;
  }

  controleProcessamento(situacao: string) {
    const params: ProcessamentoContabil = {
      id: Number(this.data.dados.id),
      situacaoAprovacao: situacao,
    };
    this.controleProcessamentoService
      .putControleProcessamento(params)
      .subscribe(
        (response) => {
          if (response) {
            if(situacao === '2'){
              this.snackbarService.open(
                'Aprovado com sucesso!',
                'success',
              );
            } else {
              this.snackbarService.open(
                'Recusado com sucesso!',
                'success',
              );
            }
            this.dialog.close();
          }
        },
        (error) => {
          this.snackbarService.open('Erro ao processar: ' + error, 'error');
      },
    );
  }
}
