import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ValidaMovimentoComponent } from './valida-movimento.component';



const routes: Routes = [
  {
    path: '',
    component: ValidaMovimentoComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ValidaParametroRoutingModule { }
