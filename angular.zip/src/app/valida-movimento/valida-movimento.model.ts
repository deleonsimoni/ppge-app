export interface ValidaMovimento {
  dados: {
    movimentos: Movimento;
    dataMovimento: string;
    totalMovimento: number;
  };
}

export interface Movimento {
  tipoMensagem: string;
  tipoLancamento: string;
  totalSimpi: number;
  totalContabil: number;
  totalPendente: number;
  totalNaoProcessado: number;
}
export interface ProcessamentoContabil {
  id: number;
  data?: string;
  situacaoAprovacao: string;
  situacaoProcessamento?: string;
}

export interface ConsultaProcessamento {
  dados: ProcessamentoContabil[];
  pagina: number;
  paginas: number;
  tamanhoPagina: number;
  totalRegistros: number;
}

export interface ProcessamentoPendente extends Paginacao {
  lancamentos: Array<LancamentoPendente>;
}

export interface LancamentoPendente {
  idMensagem: number;
  idLancamento: number;
  situacaoProcessamento: string;
  codInstrucaoOriginal: string;
  valorLancamento: number;
  tipoMensagem: string;
}

export interface ParametroPesquisa {
  dataInicio: string;
  dataFim: string;
  situacaoProcessamento: string;
  tipoLancamento: string;
  tipoMensagem: string;
  valorInicio?: number;
  valorFim?: number;
}

export interface Paginacao {
  pagina: number;
  paginas: number;
  tamanhoPagina: number;
  totalRegistros: number;
}

export interface ClassificacaoManual {
  idLancamento: number;
  codigoEventoContabil: string;
  situacaoLancamento: string;
}

export const Aprovacao = {
  null: 'Nulo',
  1: 'Parar',
  2: 'Seguir',
};

export const Processamento = {
  null: 'Nulo',
  1: 'Concluído',
  2: 'Processar',
  3: 'Reprocessar',
  4: 'Suspenso'
};
