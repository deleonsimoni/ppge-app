import { Component, OnInit, ViewChild, ChangeDetectionStrategy, Input } from '@angular/core';
import { MatStepper } from '@angular/material/stepper';
import { PorServicoService } from '@app/consulta/por-servico/por-servico.service';
import { SnackbarService } from '@core/services';
import { take } from 'rxjs/operators';
import { ParametroPesquisa, ProcessamentoPendente} from '../valida-movimento.model';
import { PageEvent } from '@angular/material/paginator';
import { FormBuilder, Validators, NgForm } from '@angular/forms';
import { SaldoService } from '@app/saldo/saldo.service';
import { DetalheAporteSaque } from '@typings/saldo/saldo.model';
import { ValidaMovimentoService } from '../valida-movimento.service';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-classificacao-manual',
  templateUrl: './classificacao-manual.component.html',
  styleUrls: ['./classificacao-manual.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ClassificacaoManualComponent {

  @Input() filtroPesquisa: ParametroPesquisa;
  @Input() msgPendente$: BehaviorSubject<ProcessamentoPendente>;

  @ViewChild('stepper') stepper: MatStepper;
  @ViewChild('myForm') myForm: NgForm;

  detalhe: object;
  detalheAporteSaque: DetalheAporteSaque;
  codInstrucaoOriginal: string;
  idLancamento: string;
  header = ['tipoMensagem', 'codInstrucaoOriginal', 'situacaoProcessamento', 'valorLancamento', 'acao'];

  readonly form = this.fb.group({
    situacaoLancamento: ['', Validators.required],
    codigoEventoContabil: ['', Validators.required],
  });

  constructor(private porServicoService: PorServicoService,
    private snackbarService: SnackbarService,
    private saldoService: SaldoService,
    private validaMovimentoService: ValidaMovimentoService,
    private fb: FormBuilder) {
  }

  avancarDetalheMensagem(id: string, codInstrucaoOriginal: string, idLancamento: string){
    this.idLancamento = idLancamento;
    if(this.getTipoMensagemBusca(codInstrucaoOriginal) === 'APORTE'){
      this.saldoService.getDetalheAporteSaque(id).pipe(take(1))
        .subscribe(
          (detalhe) => {
            this.detalheAporteSaque = detalhe;
            this.codInstrucaoOriginal = codInstrucaoOriginal;
            this.stepper.next();
          }
        );

    }else{

      this.porServicoService
      .getDetalheMensagem(id, 'false', 'false', 'false')
      .pipe(take(1))
        .subscribe(
          (detalhe) => {
            this.detalhe = detalhe;
            this.codInstrucaoOriginal = codInstrucaoOriginal;
            this.stepper.next();
          }
        );
    }
  }

  getTipoMensagemBusca(codInstrucaoOriginal: string){
    return codInstrucaoOriginal.startsWith('E') ? 'PACS008' : codInstrucaoOriginal.startsWith('D') ? 'PACS004' : 'APORTE';
  }

  getTipoMensagem(){
    if(this.codInstrucaoOriginal) {
      return this.codInstrucaoOriginal.startsWith('E') ? 'PACS008' : this.codInstrucaoOriginal.startsWith('D') ? 'PACS004' : 'APORTE';
    } else {
      return null;
    }
  }

  avancarClassificacaoMensagem(){
    this.stepper.next();
  }

  retornar(){
    this.stepper.previous();
  }

  onPagination(event: PageEvent): void {
    this.validaMovimentoService.getClassificacaoManual(this.filtroPesquisa, event.pageIndex + 1, event.pageSize)
    .pipe(take(1))
    .subscribe((dados) => {
      this.msgPendente$.next(dados);
    });
  }

  pesquisaClassificacaoManual(): void {
    this.validaMovimentoService.getClassificacaoManual(this.filtroPesquisa)
    .pipe(take(1))
    .subscribe((dados) => {
      this.msgPendente$.next(dados);
    });
  }

  salvarClassificacaoManual(){
    this.validaMovimentoService.postClassificacaoManual(this.form.getRawValue(), this.idLancamento).subscribe(
      (response) => {
        if (response) {
          this.snackbarService.open('Salvo com sucesso', 'success');
          this.pesquisaClassificacaoManual();
          this.stepper.reset();
          this.form.reset();
        }
      },
      (error) => {
        this.snackbarService.open('Erro ao salvar: ' + error, 'error');
      },
    );
  }

  resetForm(){
    this.myForm.resetForm();
    this.stepper.reset();
  }

  getData(timestamp: number){
    return new Date(timestamp);
  }
}
