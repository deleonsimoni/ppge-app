import { Component, Inject } from '@angular/core';
import { tap } from 'rxjs/operators';
import { SnackbarService } from '../../core/services/snackbar.service';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConsultarDiferencaSaldoService } from '../consultar-diferenca-saldo.service';

@Component({
  selector: 'app-extrato-diario-dialog',
  templateUrl: './extrato-diario-dialog.component.html',
  styleUrls: ['./extrato-diario-dialog.component.scss']
})
export class ExtratoDiarioDialogComponent {

  constructor(
    private getDownload: ConsultarDiferencaSaldoService,
    private snackbarService: SnackbarService,
    @Inject(MAT_DIALOG_DATA) public data,
    ) { }

  solicitarDownload(nomeArquivo: string, idMensagemOriginal: string){
    this.getDownload.getDownloadArquivoNfs(nomeArquivo)
        .pipe(
          tap((blob: any) => {
            const a = document.createElement('a')
            const objectUrl = URL.createObjectURL(blob)
            if(blob.size == 0) {
              this.snackbarService.open('Arquivo Vazio', 'error');
            } else {
              a.href = objectUrl
              a.download = 'Relacao de lancamentos '+ this.data.dataSelecionada + ".zip";
              a.click();
              URL.revokeObjectURL(objectUrl);
            }
          },
          (error) => {
            this.snackbarService.open('Erro ao realizar download do arquivo!', 'error');
          },
          ),
        )
        .subscribe();
    }
}
