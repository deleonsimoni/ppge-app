import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { ConsultarDiferencaSaldoComponent } from './consultar-diferenca-saldo.component';
const routes: Routes = [
  {
    path: '',
    component: ConsultarDiferencaSaldoComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class ConsultarDiferencaSaldoRoutingModule {}