export class MensagemResponse {
  dados: ControleSaldo[];
  pagina: number;
  paginas: number;
  tamanhoPagina: number;
  totalRegistros: number;
}

export class ControleSaldo {
  data: string;
  temDiferenca: boolean;

  valorCxInicial: number;
  valorCxEntrada: number;
  valorCxSaida: number;
  valorCxFinal: number;

  valorBcConsolidado: number;
  valorBcBloqueado: number;

  valorDifAcumulado: number;
  valorDifDiario: number;
}

export interface DetalheCamt052{
  idMensagemOriginal: string;
  nomeArquivo: string;
}
