import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, Validators } from '@angular/forms';
import { SnackbarService } from '@core/services';
import * as moment from 'moment';
import { MAT_DATE_FORMATS } from '@angular/material/core';
import { BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import { MensagemResponse, DetalheCamt052 } from './consultar-diferenca-saldo.model';
import { ConsultarDiferencaSaldoService } from './consultar-diferenca-saldo.service';
import { PageEvent } from '@angular/material/paginator';
import { DatePipe } from '@angular/common';
import { CargaBacenService } from '@app/carga-bacen/carga-bacen.service';
import { HistoricoCargaBacenDialogComponent } from '@app/carga-bacen/historico/historico-carga-bacen-dialog.component';
import { ExtratoDiarioDialogComponent } from './extrato-diario-dialog/extrato-diario-dialog.component';

export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-consultar-diferenca-saldo',
  templateUrl: './consultar-diferenca-saldo.component.html',
  styleUrls: ['./consultar-diferenca-saldo.component.scss'],
  providers: [
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS}
  ]
})
export class ConsultarDiferencaSaldoComponent {

  date = new Date();
  dataConsultada = '';
  paginaAtual = 1;
  tamanhoPagina: number;
  detalheMensagem: DetalheCamt052;

  header = [
    'data',
    'valorBcConsolidado',
    'valorBcBloqueado',
    'valorCxInicial',
    'valorCxEntrada',
    'valorCxSaida',
    'valorCxFinal',
    'valorDifAcumulado',
    'valorDifDiario',
    'acao',
  ];

  constructor(
    public dialog: MatDialog,
    private fb: FormBuilder,
    private snackbarService: SnackbarService,
    private service: ConsultarDiferencaSaldoService,
    public datepipe: DatePipe,
    private cargaBacenService: CargaBacenService
  ) { }


  readonly form = this.fb.group({
    dataMes: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
      ]),
      Validators.required,
    ],
  });
  readonly data$ = new BehaviorSubject<MensagemResponse>(null);

  public getMaxTimeSelected() {
    return moment(new Date());
  }

  public closeDatePicker(eventData: any, dp?:any) {
    this.form.get('dataMes').setValue(eventData);
    dp.close();
  }

  onSubmit(): void {
    if(this.form.valid) {
      this.paginaAtual = 1;
      let dataFormatada = this.datepipe.transform(this.form.value.dataMes, 'MM/yyyy')

      this.service.getMensagens(dataFormatada)
        .subscribe(data => {
          this.data$.next(data);
          this.dataConsultada = dataFormatada;
        })
    }
  }

  onPagination(event: PageEvent) {
    if(this.form.valid) {
      this.paginaAtual = event.pageIndex + 1;
      this.tamanhoPagina = event.pageSize;

      this.service.getMensagens(this.dataConsultada, this.paginaAtual, this.tamanhoPagina)
        .subscribe(data => {
          this.data$.next(data);
        })
    }

  }

  onOpenDialogHistoricoSolucao(data) {
    const dataSelecionada: string = this.datepipe.transform(data, 'dd/MM/yyyy');
    this.cargaBacenService.getHistorico(dataSelecionada)
    .pipe().subscribe(
      (detalhe) => {
        if (detalhe.length > 0) {
          this.dialog.open(HistoricoCargaBacenDialogComponent, {
            data: {
              dados: detalhe,
              dataSelecionada
            },
            maxHeight: '800px',
            width: '1200px',
          })
        } else {
          this.snackbarService.open('Histórico sem dados disponíveis para esta data.', 'error');
        }

      }
    )

  }

  onOpenDialogExtratoDiario(data, endToEndCamt, nomeArquivo) {
    const dataSelecionada = this.datepipe.transform(data, 'dd/MM/yyyy');

    if(nomeArquivo != null) {
      this.dialog.open(ExtratoDiarioDialogComponent, {
        data: {
          endToEndCamt: endToEndCamt,
          nomeArquivo:nomeArquivo,
          dataSelecionada,
          isNew: false
        },
        width: '600px',
      })
    } else {
      this.snackbarService.open('Não foi possivel gerar extrato para essa data', 'error');
    }
  }

  chamarJobDiferencaSaldo(dataContabil, tentativa) {
    const data: string = moment(dataContabil).format('DD-MM-YYYY');
    this.cargaBacenService
      .iniciarJobDiferencaSaldo(data, ++tentativa)
      .pipe(take(1))
      .subscribe();
  }
}
