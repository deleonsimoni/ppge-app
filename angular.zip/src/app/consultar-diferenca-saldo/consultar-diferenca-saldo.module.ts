import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConsultarDiferencaSaldoComponent } from './consultar-diferenca-saldo.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgxCurrencyModule } from 'ngx-currency';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { HighlightModule } from 'ngx-highlightjs';
import { ConsultarDiferencaSaldoRoutingModule } from './consultar-diferenca-saldo-rounting.module';
import { ExtratoDiarioDialogModule } from './extrato-diario-dialog/extrato-diario-dialog.module';



@NgModule({
  declarations: [ConsultarDiferencaSaldoComponent],
  imports: [
    CommonModule,
    ConsultarDiferencaSaldoRoutingModule,
    ReactiveFormsModule,
    MatDatepickerModule,
    MatInputModule,
    MatPaginatorModule,
    MatSelectModule,
    MatTableModule,
    MatDialogModule,
    MatButtonModule,
    MatListModule,
    MatTooltipModule,
    NgxCurrencyModule,
    HighlightModule,
    ExtratoDiarioDialogModule
  ]
})
export class ConsultarDiferencaSaldoModule { }
