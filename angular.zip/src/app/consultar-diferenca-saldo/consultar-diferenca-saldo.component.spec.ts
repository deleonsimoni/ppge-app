import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsultarDiferencaSaldoComponent } from './consultar-diferenca-saldo.component';

describe('ConsultarDiferencaSaldoComponent', () => {
  let component: ConsultarDiferencaSaldoComponent;
  let fixture: ComponentFixture<ConsultarDiferencaSaldoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ConsultarDiferencaSaldoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultarDiferencaSaldoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
