import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { SnackbarService } from '@core/services';
import { MensagemResponse } from './consultar-diferenca-saldo.model';
import { Observable } from 'rxjs';
import { environment } from '@env/environment';
import { map, catchError } from 'rxjs/operators';
import { getServerErrorMessage } from '@app/shared/functions-utils';
import { Mensagem } from '../consulta/por-servico/por-servico.model';

@Injectable({
  providedIn: 'root',
})
export class ConsultarDiferencaSaldoService {


  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_PIX_CARGA_BACEN = `${environment.urlPixCargaBacen}/simpi-carga-bacen`;

  private URL_DOWNLOAD = `${this.URL_PIX_CARGA_BACEN}/api/download-arquivo`;

  private idMensagem$: Observable<string>;
  private mensagens$:  Observable<Mensagem[]>;


  constructor(
    private http: HttpClient,
    private snackbarService: SnackbarService,
  ) {}

  getMensagens(
    dataMonth: string,
    page: number = 1,
    tamanhoPagina: number = 15,
  ): Observable<MensagemResponse> {
    let params = new HttpParams()
      .set('dataMesAno', dataMonth)
      .set('pagina', page.toString())
      .set('tamanhoPagina', tamanhoPagina.toString());

    return this.http.get<MensagemResponse>(`${this.URL_PIX_GESTAO}/controle-saldos/consulta-controle-diferenca`, {params})
      .pipe(
        map((response) => {
          if (response.totalRegistros <= 0) {
            this.snackbarService.open("Nenhum Registro Encontrado.",'error');
          } else {
            return response;
          }
        }),
        catchError((error) => {
          let errorMsg: string;
          errorMsg = getServerErrorMessage(error);
          this.snackbarService.open(errorMsg,'error');
          throw errorMsg;
        })
      );
  }

  getDownloadArquivoNfs(nomeArquivo: string):Observable<ArrayBuffer> {
    let params = new HttpParams();
    if (nomeArquivo) {
      params = params.set('nomeArquivo', nomeArquivo);
    }
    return this.http.get<ArrayBuffer>(this.URL_DOWNLOAD, { params, responseType: 'blob' as 'json'});

    }
}
