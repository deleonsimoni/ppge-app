import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: 'consulta',
    loadChildren: () =>
      import('./consulta/consulta.module').then((m) => m.ConsultaModule),
  },
  {
    path: 'mensageria',
    loadChildren: () =>
      import('./mensageria/mensageria.module').then((m) => m.MensageriaModule),
  },
  {
    path: 'saldo',
    loadChildren: () =>
      import('./saldo/saldo.module').then((m) => m.SaldoModule),
  },
  {
    path: 'diferencas-saldo',
    loadChildren: () =>
      import('./consultar-diferenca-saldo/consultar-diferenca-saldo.module').then((m) => m.ConsultarDiferencaSaldoModule),
  },
  {
    path: 'roteiro-contabil',
    loadChildren: () =>
      import('./roteiro-contabil/roteiro-contabil.module').then((m) => m.RoteiroContabilModule),
  },
  {
    path: 'valida-movimento',
    loadChildren: () =>
      import('./valida-movimento/valida-movimento.module').then((m) => m.ValidaMovimentoModule),
  },
  {
    path: 'controle-processamento',
    loadChildren: () =>
      import('./controle-processamento/controle-processamento.module').then((m) => m.ControleProcessamentoModule),
  },
  {
    path: 'lotes-enviados',
    loadChildren: () =>
      import('./lotes-enviados/lotes-enviados.module').then((m) => m.LotesEnviadosModule),
  },
  {
    path: 'extrato',
    loadChildren: () =>
      import('./extrato/extrato.module').then((m) => m.ExtratoModule),
  },
  {
    path: 'classificacao-manual',
    loadChildren: () =>
      import('./classificacao-manual/classificacao-manual.module').then((m) => m.ClassificacaoManualModule),
  },
  {
    path: 'log-usuario',
    loadChildren: () =>
      import('./log-usuario/log-usuario.module').then((m) => m.LogUsuarioModule),
  },
  {
    path: 'tarifas-consulta',
    loadChildren: () =>
      import('./tarifas-consulta/tarifas-consulta.module').then((m) => m.TarifasConsultaModule),
  },
  {
    path: 'log-erro',
    loadChildren: () =>
      import('./log-erro/log-erro.module').then((m) => m.LogErroModule),
  },
  {
    path: 'solucao-diferencas',
    loadChildren: () =>
      import('./carga-bacen/carga-bacen.module').then((m) => m.CargaBacenModule),
  },
  {
    path: 'chaves-consulta',
    loadChildren: () =>
      import('./chave-sinaf/chave-sinaf.module').then((m) => m.ChaveSinafModule),
  },
  {
    path: 'pendencia-contabil',
    loadChildren: () => import('./pendencia-contabil/pendencia-contabil.module').then((m) => m.PendenciaContabilModule),
  },
  {
    path: 'relatorios',
    loadChildren: () => import('./relatorios/relatorios.module').then((m) => m.RelatoriosModule),
  },
  {
    path: 'certificado-info',
    loadChildren: () => import('./certificado-info/certificado-info.module').then((m) => m.CertificadoInfoModule),
  },
  {
    path: 'lotes=canal-secundario',
    loadChildren: () => import('./lotes/lotes.module').then((m) => m.LotesModule),
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
