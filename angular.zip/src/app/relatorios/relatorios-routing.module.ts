import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CompiladoComponent } from './compilado/compilado.component';
import { EnvioParaOutrasIfsComponent } from './envio-para-outras-ifs/envio-para-outras-ifs.component';
import { RecebimentoOutrasIfsComponent } from './recebimento-outras-ifs/recebimento-outras-ifs.component';
import { TipoMensagemComponent } from './tipo-mensagem/tipo-mensagem.component';

const routes: Routes = [
  {
    path: 'compilado',
    component: CompiladoComponent,
  },
  {
    path: 'tipo-mensagem',
    component: TipoMensagemComponent,
  },
  {
    path: 'recebimento-outras-ifs',
    component: RecebimentoOutrasIfsComponent,
  },
  {
    path: 'envio-para-outras-ifs',
    component: EnvioParaOutrasIfsComponent,
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RelatoriosRoutingModule { }
