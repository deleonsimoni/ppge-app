import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EnvioParaOutrasIfsComponent } from './envio-para-outras-ifs.component';

describe('EnvioParaOutrasIfsComponent', () => {
  let component: EnvioParaOutrasIfsComponent;
  let fixture: ComponentFixture<EnvioParaOutrasIfsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EnvioParaOutrasIfsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EnvioParaOutrasIfsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
