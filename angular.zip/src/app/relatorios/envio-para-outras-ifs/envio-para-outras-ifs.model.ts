export interface RelatorioResponse {
	dados: RelatorioPosicaoIfEnviam[];
	pagina: number;
	paginas: number;
	tamanhoPagina: number;
	totalRegistros: number;
}
export interface RelatorioPosicaoIfEnviam {
    numeroControlePosicaoIf: number;
	dataTransacaoBacen: Date;
	situacaoMensagem: string;
	tipoMensagem: string;
	ispbEnviada: string;
	ispbRecebida: string;
	totalMensagem: number;
	valorMensagem: number;
	posicaoRank: number;
}