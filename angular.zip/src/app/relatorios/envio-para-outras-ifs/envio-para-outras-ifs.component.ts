import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { PageEvent } from '@angular/material/paginator';
import { ISPBInstituicao } from '@app/mensageria/mensageria.model';
import DataUtils from '@app/shared/data-utils';
import { SnackbarService } from '@core/services';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import { RelatorioResponse } from './envio-para-outras-ifs.model';
import { EnvioParaOutrasIfsService } from './envio-para-outras-ifs.service';
import { MatDialog } from '@angular/material/dialog';
import { LoginService } from '@store/login';
import { SolicitarReprocessarRankingEnvioDialogComponent } from './solicitar-reprocessar-ranking-envio-dialog/solicitar-reprocessar-ranking-envio-dialog.component';

@Component({
  selector: 'app-envio-para-outras-ifs',
  templateUrl: './envio-para-outras-ifs.component.html',
  styleUrls: ['./envio-para-outras-ifs.component.scss']
})
export class EnvioParaOutrasIfsComponent {

  paginaAtual = 1;
  tamanhoPagina: number = 15;
  campoOrdenacao: string = 'V';
  header = [
    "posicaoRank",
    "tipoMensagem",
    "situacaoMensagem",
    "ispbRecebida",
    "totalMensagem",
    "valorMensagem",
  ]
  footer = ['total'];

  readonly ispbs = ISPBInstituicao;
  readonly data$ = new BehaviorSubject<RelatorioResponse>(null);

  readonly date = new Date(new Date().setDate(new Date().getDate() -1));

  readonly form = this.fb.group({
    dataFim: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
    dataInicio: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],

    status: ['E', Validators.nullValidator],
  });

  constructor(
    private fb: FormBuilder,
    public datepipe: DatePipe,
    private snackbarService: SnackbarService,
    private envioParaOutrasIfsService: EnvioParaOutrasIfsService,
    public dialog: MatDialog,
    public loginService: LoginService,
  ) { }

  onSubmit() {
    if(this.form.valid) {
      this.envioParaOutrasIfsService
        .getListRelatorioIfMaisEnviam(
          this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT),
          this.datepipe.transform(this.form.value.dataFim, DataUtils.DATE_FORMAT),
          this.form.value.status,
        ).pipe(take(1))
        .subscribe((listRelatorioRanking) => {
          this.data$.next(listRelatorioRanking);
        })
    } else {
      this.snackbarService.open("Formulário inválido!", "error");
    }
  }
  onPagination(event: PageEvent): void {
    this.paginaAtual = event.pageIndex + 1;
    this.tamanhoPagina = event.pageSize;

    this.envioParaOutrasIfsService
      .getListRelatorioIfMaisEnviam(
        this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT),
        this.datepipe.transform(this.form.value.dataFim, DataUtils.DATE_FORMAT),
        this.form.value.status,
        this.tamanhoPagina,
        this.paginaAtual,
        this.campoOrdenacao,
      ).pipe(take(1))
      .subscribe((listRelatorioRankingRecebem) => {
        this.data$.next(listRelatorioRankingRecebem);
      })

  }


  consultaOrdenada(campo: string) {
    this.campoOrdenacao = campo;

    this.envioParaOutrasIfsService
      .getListRelatorioIfMaisEnviam(
        this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT),
        this.datepipe.transform(this.form.value.dataFim, DataUtils.DATE_FORMAT),
        this.form.value.status,
        this.tamanhoPagina,
        this.paginaAtual,
        this.campoOrdenacao,
      ).pipe(take(1))
      .subscribe((listRelatorioRankingRecebem) => {
        this.data$.next(listRelatorioRankingRecebem);
      })
  }

  solicitarDownloadCsv(){
    if(this.form.valid) {
      this.envioParaOutrasIfsService
        .downloadRelatorioIfMaisEnviamCSV(
          this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT),
          this.datepipe.transform(this.form.value.dataFim, DataUtils.DATE_FORMAT),
          this.form.value.status,
          this.paginaAtual,
        this.tamanhoPagina,
        this.campoOrdenacao,
        ).subscribe(blob => {
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = 'Relatório - Envio Pix Para Outras IFs ' + this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT) + ' a ' + this.datepipe.transform(this.form.value.dataFim, DataUtils.DATE_FORMAT) + '.csv';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        })
    } else {
      this.snackbarService.open("Formulário inválido!", "error");
  }}

  openSolicitarReprocessarRelatorioEnvio(){
    this.dialog.open(SolicitarReprocessarRankingEnvioDialogComponent);
  }
}
