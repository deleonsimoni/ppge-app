import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EnvioParaOutrasIfsComponent } from './envio-para-outras-ifs.component';
import { MatInputModule } from '@angular/material/input';
import { ReactiveFormsModule } from '@angular/forms';
import { MatRadioModule } from '@angular/material/radio';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ClipboardModule } from '@angular/cdk/clipboard';
import { SolicitarReprocessarRankingEnvioDialogComponent } from './solicitar-reprocessar-ranking-envio-dialog/solicitar-reprocessar-ranking-envio-dialog.component';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { ConfirmationDialogModule } from '../../shared/components/confirmation-dialog/confirmation-dialog.module';



@NgModule({
  declarations: [EnvioParaOutrasIfsComponent, SolicitarReprocessarRankingEnvioDialogComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatDialogModule,
    MatInputModule,
    MatRadioModule,
    MatDatepickerModule,
    MatTableModule,
    MatPaginatorModule,
    MatSelectModule,
    MatTooltipModule,
    ClipboardModule,
    ConfirmationDialogModule,
  ]
})
export class EnvioParaOutrasIfsModule { }
