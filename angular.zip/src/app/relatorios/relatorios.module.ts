import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RelatoriosRoutingModule } from './relatorios-routing.module';
import { CompiladoModule } from './compilado/compilado.module';
import { TipoMensagemModule } from './tipo-mensagem/tipo-mensagem.module';
import { EnvioParaOutrasIfsModule } from './envio-para-outras-ifs/envio-para-outras-ifs.module';
import { RecebimentoOutrasIfsModule } from './recebimento-outras-ifs/recebimento-outras-ifs.module';

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RelatoriosRoutingModule,
    CompiladoModule,
    TipoMensagemModule,
    EnvioParaOutrasIfsModule,
    RecebimentoOutrasIfsModule
  ]
})
export class RelatoriosModule { }
