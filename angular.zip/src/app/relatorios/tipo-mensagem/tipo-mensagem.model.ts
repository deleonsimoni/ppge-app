export interface RelatorioControleDiario {
	numeroControleDiario: number;
	mensagem: TipoMensagem;
	dataTransacaoBacen: Date;
	valorMensagem: number;
	situacaoMensagem: string;
	tipoMensagem: string;
	totalMensagem: number;
}

export interface TipoMensagem {
    nuTipoMensagemBacen: number;
	sgMensagemBacen: string;
}