import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import DataUtils from '@app/shared/data-utils';
import { SnackbarService } from '@core/services';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';
import { take, startWith, tap } from 'rxjs/operators';
import { RelatorioControleDiario } from './tipo-mensagem.model';
import { TipoMensagemService } from './tipo-mensagem.service';
import { LoginService } from '@store/login';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmaChamadaComponent } from '@app/saldo/confirma-chamada/confirma-chamada.component';

@Component({
  selector: 'app-tipo-mensagem',
  templateUrl: './tipo-mensagem.component.html',
  styleUrls: ['./tipo-mensagem.component.scss']
})
export class TipoMensagemComponent {

  header = [
    "sgMensagemBacem",
    "situacaoMensagem",
    "totalMensagem",
    "valorMensagem",
    "tipoMensagem",
  ]
  footer = ['total'];

  readonly data$ = new BehaviorSubject<RelatorioControleDiario[]>(null);

  readonly date = new Date(new Date().setDate(new Date().getDate() -1));

  readonly form = this.fb.group({
    servico: ['', Validators.nullValidator], // ADMI, CAMT, PACS, PIBR
    tipo: [''], // 002, 004, 008...
    dataInicio: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
  });


  readonly servicoSelecionado$ = this.form.get('servico').valueChanges.pipe(
    startWith(this.form.get('servico').value),
    tap(() => {
      this.form.get('tipo').setValue('');
    }),
  );

  constructor(
    private fb: FormBuilder,
    public datepipe: DatePipe,
    private snackbarService: SnackbarService,
    private tipoMensagemService: TipoMensagemService,
    public loginService: LoginService,
    public dialog: MatDialog,
  ) { }

  onSubmit() {
    if(this.form.valid) {
      this.tipoMensagemService
        .getListRelatorioTipoMensagem(
          this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT),
          `${this.form.value.servico}${this.form.value.tipo}`
        ).pipe(take(1))
        .subscribe((listRelatorio) => {

          this.data$.next(listRelatorio);
        })
    } else {
      this.snackbarService.open("Formulário inválido!", "error");
    }
  }

  getSituacaoMensagemText(situacaoMensagem, tipoMensagem) {
    let textoSituacaoMensagem = '';
    if(tipoMensagem == 1 || tipoMensagem == 6) {
      textoSituacaoMensagem = situacaoMensagem === 'E' ? 'Efetivado' : 'Rejeitado';
    } else if(tipoMensagem == 3 || tipoMensagem == 10 || tipoMensagem == 11 || tipoMensagem == 16 || tipoMensagem == 18) {
      textoSituacaoMensagem = 'Enviada';
    } else {
      textoSituacaoMensagem = 'Recebida';
    }
    return textoSituacaoMensagem;
  }

  solicitarDownloadCsv(){
    if(this.form.valid) {
      const dataSelecionada = this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT);
      this.tipoMensagemService.getRelatorioTipoMensagemCsv(dataSelecionada, `${this.form.value.servico}${this.form.value.tipo}`)
        .subscribe(
          blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'Relatorio Tipo de Mensagem ' + dataSelecionada + '.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        })
    }
  }

  solicitarReprocessarRelatorio() {
    const dataGeracaoFormatada = this.form.get('dataInicio').value.format('DD/MM/YYYY');
    const dialogRef = this.dialog.open(ConfirmaChamadaComponent, {
      width: '600px',
      data: {
        title: "Atenção!",
        listtext: [
          `Ao prosseguir será solicitado o reprocessamento do relatório para o dia ${dataGeracaoFormatada}.`,
          'Verifique se já não houve atualização recente!',
          'Tem certeza que deseja prosseguir?'
        ]
      }
    });

    dialogRef.afterClosed().subscribe(flagAccept => {
      if (flagAccept) {
        this.tipoMensagemService
        .reprocessarRelatorio(dataGeracaoFormatada)
        .subscribe(() => {
          this.snackbarService.open('Procedure iniciada com sucesso', 'success');
        });
      }
    });
  }
}
