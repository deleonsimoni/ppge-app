import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TipoMensagemComponent } from './tipo-mensagem.component';

describe('TipoMensagemComponent', () => {
  let component: TipoMensagemComponent;
  let fixture: ComponentFixture<TipoMensagemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TipoMensagemComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TipoMensagemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
