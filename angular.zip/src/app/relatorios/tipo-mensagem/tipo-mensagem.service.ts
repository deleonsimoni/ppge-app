import { DatePipe } from "@angular/common";
import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { SnackbarService } from "@core/services";
import { environment } from "@env/environment";
import { catchError, map, take } from "rxjs/operators";
import { RelatorioControleDiario } from "./tipo-mensagem.model";
import { getServerErrorMessage } from '@app/shared/functions-utils';

@Injectable({
  providedIn: 'root',
})
export class TipoMensagemService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_PIX_RELATORIO = `${environment.urlPixRelatorio}/v1/relatorios`;

  constructor(private http: HttpClient, private datePipe: DatePipe, private snackbarService: SnackbarService) { }

  getListRelatorioTipoMensagem(dataInicio: string, tipoPagamento: string) {

    let params = new HttpParams()
      .set("data", dataInicio);

      if(tipoPagamento) {
        params = params.set('tipoPagamento', tipoPagamento);
      }

    return this.http.get<RelatorioControleDiario[]>(`${this.URL_PIX_GESTAO}/relatorio/tipo-mensagem`, {params})
      .pipe(
        map((response) => {
          if (response.length <= 0) {
            this.snackbarService.open("Nenhum Registro Encontrado.",'error');
          } else {
            return response;
          }
        }),
        catchError((error) => {
          const statusErrors = {
            404: `Not Found.`,
            403: `Access Denied.`,
            500: `Internal Server Error.`,
          }
          let errorMsg: string;
          errorMsg = statusErrors[error.status] ? statusErrors[error.status] : `Unknown Server Error.`;
          this.snackbarService.open(errorMsg,'error');
          throw errorMsg;
        })
      )
  }

  getRelatorioTipoMensagemCsv(data: string, tipoPagamento: string){
    let params = new HttpParams()
      .set("data", data);
      if(tipoPagamento) {
        params = params.set('tipoPagamento', tipoPagamento);
      }
    return this.http.get(`${this.URL_PIX_GESTAO}/relatorio/tipo-mensagem/download/arquivo`, {responseType: 'blob', params })
  }

  reprocessarRelatorio(data: string) {
    let params = new HttpParams()
      .set("data", data);
    return this.http.post(`${this.URL_PIX_RELATORIO}/gerar-relatorio-credito`, null ,{ params })
      .pipe(
        take(1),
        catchError((error) => {
          let errorMsg: string;
          errorMsg = getServerErrorMessage(error);
          this.snackbarService.open(errorMsg,'error');
          throw errorMsg;
        })
      );
  }

}
