import { environment } from '@env/environment';
import { Injectable } from '@angular/core';
import { HttpParams, HttpClient } from '@angular/common/http';
import { getServerErrorMessage } from '@app/shared/functions-utils';
import { catchError, take } from 'rxjs/operators';
import { SnackbarService } from '../../../core/services/snackbar.service';

@Injectable({
  providedIn: 'root'
})
export class SolicitarReprocessarDialogService {

  private readonly URL_PIX_RELATORIO = `${environment.urlPixRelatorio}/v1/relatorios`;

  constructor(private http: HttpClient,
    private snackbarService: SnackbarService) { }

  reprocessarRelatorio(dataReprocessar: string) {

    const params = new HttpParams()
    .set("data", dataReprocessar)

    return this.http.post(`${this.URL_PIX_RELATORIO}/gerar-relatorio-ifs-pix`, null ,{ params })
    .pipe(
      take(1),
      catchError((error) => {
        let errorMsg: string;
        errorMsg = getServerErrorMessage(error);
        this.snackbarService.open(errorMsg,'error');
        throw errorMsg;
      })
    );
  }
}
