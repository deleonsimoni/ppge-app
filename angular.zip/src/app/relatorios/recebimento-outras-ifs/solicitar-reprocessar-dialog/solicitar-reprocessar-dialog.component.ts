import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { SnackbarService } from '../../../core/services/snackbar.service';
import * as moment from 'moment';
import { SolicitarReprocessarDialogService } from './solicitar-reprocessar-dialog.service';
import { ConfirmaChamadaComponent } from '../../../saldo/confirma-chamada/confirma-chamada.component';

@Component({
  selector: 'app-solicitar-reprocessar-dialog',
  templateUrl: './solicitar-reprocessar-dialog.component.html',
  styleUrls: ['./solicitar-reprocessar-dialog.component.scss']
})
export class SolicitarReprocessarDialogComponent {

  readonly date = new Date(new Date().setDate(new Date().getDate() - 1));

  readonly formSettings = this.fb.group({
    dataReprocessar: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
  })

  constructor(
    private fb: FormBuilder,
    public datepipe: DatePipe,
    public dialog: MatDialog,
    private snackbarService: SnackbarService,
    private solicitarReprocessarDialogService: SolicitarReprocessarDialogService,
    private dialogRef: MatDialogRef<SolicitarReprocessarDialogComponent>
  ) { }

  onSubmit() {
    const dataGeracaoFormatada = this.formSettings.get('dataReprocessar').value.format('DD/MM/YYYY');
    const dialogRef = this.dialog.open(ConfirmaChamadaComponent, {
      width: '600px',
      data: {
        title: "Atenção!",
        listtext: [
          `Ao prosseguir será solicitado o reprocessamento do relatório para o dia ${dataGeracaoFormatada}.`,
          'Verifique se já não houve atualização recente!',
          'Tem certeza que deseja prosseguir?'
        ]
      }
    })

    dialogRef.afterClosed().subscribe(flagAccept => {
      if (flagAccept) {
        this.solicitarReprocessarDialogService
        .reprocessarRelatorio(dataGeracaoFormatada)
        .subscribe(() => {
          this.snackbarService.open('Procedure iniciada com sucesso', 'success');
          this.dialogRef.close();
        });
      }
    })
  }

}
