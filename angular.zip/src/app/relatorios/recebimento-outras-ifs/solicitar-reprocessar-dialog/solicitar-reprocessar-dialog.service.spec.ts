import { TestBed } from '@angular/core/testing';

import { SolicitarReprocessarDialogService } from './solicitar-reprocessar-dialog.service';

describe('SolicitarReprocessarDialogService', () => {
  let service: SolicitarReprocessarDialogService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SolicitarReprocessarDialogService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
