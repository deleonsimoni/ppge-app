import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { SnackbarService } from "@core/services";
import { environment } from "@env/environment";
import { catchError, map } from "rxjs/operators";
import { RelatorioResponse } from "./recebimento-outras-ifs.model";


@Injectable({
  providedIn: 'root',
})
export class RecebimentoOutrasIfsService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly TIPO_CREDITO = 'C';
  private statusErrors = {
    404: `Not Found.`,
    403: `Access Denied.`,
    500: `Internal Server Error.`,
  }

  constructor(
    private http: HttpClient,
    private snackbarService: SnackbarService) { }

  getListRelatorioIfMaisRecebem(
    dataInicio: string,
    dataFim: string,
    statusMensagem: string,
    page: number = 1,
    tamanhoPagina: number = 15,
    campoOrdenacao: string = 'V',
  ) {
    const params = new HttpParams()
      .set("dataInicio", dataInicio)
      .set("dataFim", dataFim)
      .set("tipoMensagem", this.TIPO_CREDITO)
      .set("situacaoMensagem", statusMensagem)
      .set('pagina', page.toString())
      .set('tamanhoPagina', tamanhoPagina.toString())
      .set('ordenacao', campoOrdenacao);

    return this.http.get<RelatorioResponse>(`${this.URL_PIX_GESTAO}/relatorio/rankings`, {params})
      .pipe(
        map((response) => {
          if (response.dados.length <= 0) {
            this.snackbarService.open("Nenhum Registro Encontrado.",'error');
          } else {
            return response;
          }
        }),
        catchError((error) => {
          let errorMsg: string = this.statusErrors[error.status] ? this.statusErrors[error.status] : `Unknown Server Error.`;
          this.snackbarService.open(errorMsg,'error');
          throw errorMsg;
        })
      )
  }

  downloadRelatorioIfMaisRecebemCSV(
    dataInicio: string,
    dataFim: string,
    statusMensagem: string,
    page: number = 1,
    tamanhoPagina: number = 15,
    campoOrdenacao: string = 'V',
  ){
    const params = new HttpParams()
      .set("dataInicio", dataInicio)
      .set("dataFim", dataFim)
      .set("tipoMensagem", this.TIPO_CREDITO)
      .set("situacaoMensagem", statusMensagem)
      .set('pagina', page.toString())
      .set('tamanhoPagina', tamanhoPagina.toString())
      .set('ordenacao', campoOrdenacao);

    return this.http.get(`${this.URL_PIX_GESTAO}/relatorio/rankings/download/arquivo`, {responseType: 'blob', params });
  }
}
