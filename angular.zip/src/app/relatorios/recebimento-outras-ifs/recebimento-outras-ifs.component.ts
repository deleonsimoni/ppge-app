import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { PageEvent } from '@angular/material/paginator';
import { ISPBInstituicao } from '@app/mensageria/mensageria.model';
import { LoginService } from '@store/login';
import DataUtils from '@app/shared/data-utils';
import { SnackbarService } from '@core/services';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import { RelatorioResponse } from './recebimento-outras-ifs.model';
import { RecebimentoOutrasIfsService } from './recebimento-outras-ifs.service';
import { MatDialog } from '@angular/material/dialog';
import { SolicitarReprocessarDialogComponent } from './solicitar-reprocessar-dialog/solicitar-reprocessar-dialog.component';

@Component({
  selector: 'app-recebimento-outras-ifs',
  templateUrl: './recebimento-outras-ifs.component.html',
  styleUrls: ['./recebimento-outras-ifs.component.scss']
})
export class RecebimentoOutrasIfsComponent {

  campoOrdenacao: string = 'V';

  header = [
    "posicaoRank",
    "tipoMensagem",
    "situacaoMensagem",
    "ispbEnviada",
    "totalMensagem",
    "valorMensagem",
  ]
  footer = ['total'];
  paginaAtual = 1;
  tamanhoPagina: number = 15;

  readonly ispbs = ISPBInstituicao;
  readonly data$ = new BehaviorSubject<RelatorioResponse>(null);

  readonly date = new Date(new Date().setDate(new Date().getDate() -1));

  readonly form = this.fb.group({
    dataInicio: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
    dataFim: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
    status: ['E', Validators.nullValidator],
  });

  constructor(
    private fb: FormBuilder,
    public datepipe: DatePipe,
    private snackbarService: SnackbarService,
    private recebimentoOutrasIfsService: RecebimentoOutrasIfsService,
    public dialog: MatDialog,
    public loginService: LoginService,
  ) { }


  onPagination(event: PageEvent): void {
    this.paginaAtual = event.pageIndex + 1;
    this.tamanhoPagina = event.pageSize;

    this.recebimentoOutrasIfsService
      .getListRelatorioIfMaisRecebem(
        this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT),
        this.datepipe.transform(this.form.value.dataFim, DataUtils.DATE_FORMAT),
        this.form.value.status,
        this.paginaAtual,
        this.tamanhoPagina,
        this.campoOrdenacao,
      ).pipe(take(1))
      .subscribe((listRelatorioRankingRecebem) => {
        this.data$.next(listRelatorioRankingRecebem);
      })
  }

  consultaOrdenada(campo: string) {
    this.campoOrdenacao = campo;
    this.recebimentoOutrasIfsService
      .getListRelatorioIfMaisRecebem(
        this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT),
        this.datepipe.transform(this.form.value.dataFim, DataUtils.DATE_FORMAT),
        this.form.value.status,
        this.paginaAtual,
        this.tamanhoPagina,
        this.campoOrdenacao,
      ).pipe(take(1))
      .subscribe((listRelatorioRankingRecebem) => {
        this.data$.next(listRelatorioRankingRecebem);
      })
  }

  onSubmit() {
    if(this.form.valid) {
      this.recebimentoOutrasIfsService
        .getListRelatorioIfMaisRecebem(
          this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT),
          this.datepipe.transform(this.form.value.dataFim, DataUtils.DATE_FORMAT),
          this.form.value.status,
        ).pipe(take(1))
        .subscribe((listRelatorioRankingRecebem) => {

          this.data$.next(listRelatorioRankingRecebem);
        })
    } else {
      this.snackbarService.open("Formulário inválido!", "error");
    }
  }

  solicitarDownloadCsv(){
    if(this.form.valid) {
      this.recebimentoOutrasIfsService
        .downloadRelatorioIfMaisRecebemCSV(
          this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT),
          this.datepipe.transform(this.form.value.dataFim, DataUtils.DATE_FORMAT),
          this.form.value.status,
          this.paginaAtual,
        this.tamanhoPagina,
        this.campoOrdenacao,
        ).subscribe(blob => {
          const url = window.URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = 'Relatório - Recebimento Pix de Outras IFs ' + this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT) + ' a ' + this.datepipe.transform(this.form.value.dataFim, DataUtils.DATE_FORMAT) + '.csv';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        })
    } else {
      this.snackbarService.open("Formulário inválido!", "error");
  }}

  openSolicitarReprocessarRelatorio(){
    this.dialog.open(SolicitarReprocessarDialogComponent);
  }
}
