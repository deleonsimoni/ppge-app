import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RecebimentoOutrasIfsComponent } from './recebimento-outras-ifs.component';
import { ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { ClipboardModule } from '@angular/cdk/clipboard';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { SolicitarReprocessarDialogComponent } from './solicitar-reprocessar-dialog/solicitar-reprocessar-dialog.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { ConfirmationDialogModule } from '../../shared/components/confirmation-dialog/confirmation-dialog.module';



@NgModule({
  declarations: [RecebimentoOutrasIfsComponent, SolicitarReprocessarDialogComponent],
  imports: [
    CommonModule,
    MatButtonModule,
    ReactiveFormsModule,
    MatInputModule,
    MatDialogModule,
    MatRadioModule,
    MatDatepickerModule,
    MatTableModule,
    MatPaginatorModule,
    MatSelectModule,
    MatTooltipModule,
    ClipboardModule,
    MatSlideToggleModule,
    ConfirmationDialogModule,
  ]
})
export class RecebimentoOutrasIfsModule { }
