export interface RelatorioResponse {
	dados: RelatorioPosicaoIfRecebem[];
	pagina: number;
	paginas: number;
	tamanhoPagina: number;
	totalRegistros: number;
}

export interface RelatorioPosicaoIfRecebem {
	numeroControlePosicaoIf: number;
	dataTransacaoBacen: Date;
	situacaoMensagem: string;
	tipoMensagem: string;
	ispbEnviada: string;
	ispbRecebida: string;
	totalMensagem: number;
	valorMensagem: number;
	posicaoRank: number;
}