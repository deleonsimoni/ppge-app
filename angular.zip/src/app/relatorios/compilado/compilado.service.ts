import { DatePipe } from "@angular/common";
import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { SnackbarService } from "@core/services";
import { environment } from "@env/environment";
import { catchError, map, take } from "rxjs/operators";
import { getServerErrorMessage } from '@app/shared/functions-utils';
import { RelatorioTotalTrafegado } from "./compilado.model";

@Injectable({
  providedIn: 'root',
})
export class CompiladoService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_PIX_RELATORIO = `${environment.urlPixRelatorio}/v1/relatorios`;


  constructor(private http: HttpClient, private datePipe: DatePipe, private snackbarService: SnackbarService) { }

  getListRelatorioTotalTrafegado(data: string) {
    const params = new HttpParams()
      .set("data", data);

    return this.http.get<RelatorioTotalTrafegado[]>(`${this.URL_PIX_GESTAO}/relatorio/compilado`, {params})
      .pipe(
        map((response) => {
          if (response.length <= 0) {
            this.snackbarService.open("Nenhum Registro Encontrado.",'error');
          } else {
            return response;
          }
        }),
        catchError((error) => {
          const statusErrors = {
            404: `Not Found.`,
            403: `Access Denied.`,
            500: `Internal Server Error.`,
          }
          let errorMsg: string;
          errorMsg = statusErrors[error.status] ? statusErrors[error.status] : `Unknown Server Error.`;
          this.snackbarService.open(errorMsg,'error');
          throw errorMsg;
        })
      )
  }

  getRelatorioCsv(data: string){
    const params = new HttpParams()
      .set("data", data);
    return this.http.get(`${this.URL_PIX_GESTAO}/relatorio/compilado/download/arquivo`, {responseType: 'blob', params })
  }

  reprocessarRelatorioCompilado(data: string) {
    let params = new HttpParams()
      .set("data", data);
    return this.http.post(`${this.URL_PIX_RELATORIO}/gerar-relatorio-total-trafegado`, null ,{ params })
      .pipe(
        take(1),
        catchError((error) => {
          let errorMsg: string;
          errorMsg = getServerErrorMessage(error);
          this.snackbarService.open(errorMsg,'error');
          throw errorMsg;
        })
      );
  }
}
