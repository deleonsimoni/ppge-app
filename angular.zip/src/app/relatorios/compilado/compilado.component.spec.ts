import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CompiladoComponent } from './compilado.component';

describe('CompiladoComponent', () => {
  let component: CompiladoComponent;
  let fixture: ComponentFixture<CompiladoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CompiladoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CompiladoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
