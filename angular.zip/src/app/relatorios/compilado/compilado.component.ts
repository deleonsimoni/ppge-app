import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import DataUtils from '@app/shared/data-utils';
import { SnackbarService } from '@core/services';
import * as moment from 'moment';
import { BehaviorSubject } from 'rxjs';
import { take } from 'rxjs/operators';
import { RelatorioTotalTrafegado } from './compilado.model';
import { CompiladoService } from './compilado.service';
import { LoginService } from '@store/login';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmaChamadaComponent } from '@app/saldo/confirma-chamada/confirma-chamada.component';

@Component({
  selector: 'app-compilado',
  templateUrl: './compilado.component.html',
  styleUrls: ['./compilado.component.scss']
})
export class CompiladoComponent {

  header = [
    "tipoMensagem",
    "situacaoMensagem",
    "totalMensagem",
    "valorMensagem",
  ]
  footer = ['total'];

  readonly data$ = new BehaviorSubject<RelatorioTotalTrafegado[]>(null);

  readonly date = new Date(new Date().setDate(new Date().getDate() -1));

  readonly form = this.fb.group({
    dataInicio: [
      moment([
        this.date.getFullYear(),
        this.date.getMonth(),
        this.date.getDate(),
      ]),
      Validators.required,
    ],
  });

  constructor(
    private fb: FormBuilder,
    public datepipe: DatePipe,
    private snackbarService: SnackbarService,
    private compiladoService: CompiladoService,
    public loginService: LoginService,
    public dialog: MatDialog,
  ) { }

  onSubmit() {
    if(this.form.valid) {
      this.compiladoService
        .getListRelatorioTotalTrafegado(
          this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT),
        ).pipe(take(1))
        .subscribe((listRelatorio) => {
          this.data$.next(listRelatorio);
        })
    } else {
      this.snackbarService.open("Formulário inválido!", "error");
    }
  }

  solicitarDownloadCsv(){
    if(this.form.valid) {
      const dataSelecionada = this.datepipe.transform(this.form.value.dataInicio, DataUtils.DATE_FORMAT);
      this.compiladoService.getRelatorioCsv(dataSelecionada)
        .subscribe(
          blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'Relatorio Compilado ' + dataSelecionada + '.csv';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
        })
    }
  }
  solicitarReprocessarRelatorio() {
    const dataGeracaoFormatada = this.form.get('dataInicio').value.format('DD/MM/YYYY');
    const dialogRef = this.dialog.open(ConfirmaChamadaComponent, {
      width: '600px',
      data: {
        title: "Atenção!",
        listtext: [
          `Ao prosseguir será solicitado o reprocessamento do relatório para o dia ${dataGeracaoFormatada}.`,
          'Verifique se já não houve atualização recente!',
          'Tem certeza que deseja prosseguir?'
        ]
      }
    });

    dialogRef.afterClosed().subscribe(flagAccept => {
      if (flagAccept) {
        this.compiladoService
        .reprocessarRelatorioCompilado(dataGeracaoFormatada)
        .subscribe(() => {
          this.snackbarService.open('Procedure iniciada com sucesso', 'success');
        });
      }
    });
  }
}
