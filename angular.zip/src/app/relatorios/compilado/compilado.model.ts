export interface RelatorioTotalTrafegado {
    dataTransacaoBacen: Date;
    situacaoMensagem: string;
    totalMensagem: string;
    valorMensagem: number;
    tipoMensagem: number;
}