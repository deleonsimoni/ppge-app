import {  Component, Output, EventEmitter } from '@angular/core';
import { LoginService } from '@store/login';

@Component({
  selector: 'app-nav',
  templateUrl: './nav.component.html',
  styleUrls: ['./nav.component.scss'],
})
export class NavComponent {
  @Output() toggleSidenav = new EventEmitter();

  constructor(public loginService: LoginService){}

}
