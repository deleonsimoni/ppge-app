import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { LoginEffects } from './login.effects';
import { reducer } from './login.reducer';

@NgModule({
  imports: [
    CommonModule,
    StoreModule.forFeature('login', reducer),
    EffectsModule.forFeature([LoginEffects]),
  ],
})
export class LoginModule {}
