import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, defer, of } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import * as Keycloak from 'keycloak-js';
import { LoggerService } from '@core/services';
import { environment } from '@env/environment';
import { UserInfo } from './login.model';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  private readonly keycloak: Keycloak.KeycloakInstance;
  private readonly token = new BehaviorSubject<string | null>(null);

  constructor(private loggerService: LoggerService) {
    this.keycloak = Keycloak({
      clientId: environment.sso.clientId,
      realm: environment.sso.realm,
      url: environment.sso.url,
    });
    this.keycloak.onTokenExpired = () => {
      this.loggerService.log('Token expired: ', this.keycloak.token);
      this.keycloak.updateToken(5).then(
        (refreshed) => {
          if (refreshed) {
            this.token.next(this.keycloak.token);
            this.loggerService.log('Token refreshed: ', this.keycloak.token);
          } else {
            this.loggerService.log('Token still valid: ', this.keycloak.token);
          }
        },
        (reason) => {
          this.loggerService.log(
            `Failed to refresh token, or the session has expired: ${reason}`,
          );
        },
      );
    };
  }

  login(): Observable<boolean> {
    return this.isAuthenticated().pipe(
      switchMap((authenticated) =>
        authenticated ? of(true) : this.keycloakLogin(),
      ),
    );
  }

  logout(): Observable<void> {
    return defer(this.keycloak.logout).pipe(tap(() => this.token.next(null)));
  }

  isAuthenticated(): Observable<boolean> {
    return of(!!this.keycloak.authenticated);
  }

  isAuthorized(): Observable<boolean> {
    const AUTHORIZED_ROLES = [
      'MPI_ANALISTA_GEFIN',
      'MPI_ANALISTA',
      'MPI_AUDITOR_EXTERNO',
      'MPI_AUDITOR',
      'MPI_CONTABIL',
      'MPI_MASTER',
      'MPI_MONITORAMENTO',
      'MPI_PILOTO',
      'MPI_TECNOLOGIA',
    ];
    return of(
      AUTHORIZED_ROLES.some((role) => this.keycloak.hasRealmRole(role)),
    );
  }

  containsRole(authorizedRoles): boolean {
    return authorizedRoles.some((role) => this.keycloak.hasRealmRole(role))
  }

  getUsername(): Observable<UserInfo> {
    return of(this.keycloak.idTokenParsed as UserInfo);
  }

  getToken(): Observable<string | null> {
    return this.token.asObservable();
  }

  private keycloakLogin(): Observable<boolean> {
    return this.init().pipe(
      switchMap((authenticated) => {
        if (authenticated) {
          this.token.next(this.keycloak.token);
          return of(true);
        }
        return of(this.keycloak.login()).pipe(map(() => false));
      }),
    );
  }

  private init(): Observable<boolean> {
    return defer(() =>
      this.keycloak.init({
        checkLoginIframe: false,
        redirectUri: environment.sso.redirectUri,
        responseMode: 'query',
      }),
    );
  }
}
