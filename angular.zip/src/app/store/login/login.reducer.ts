import { createReducer, on, Action } from '@ngrx/store';
import * as actions from './login.actions';

export interface State {
  username: string | null;
  error: string | null;
}

export const initialState: State = {
  username: null,
  error: null,
};

const loginReducer = createReducer(
  initialState,
  on(actions.loginSuccess, (state, action) => ({
    ...state,
    username: action.username,
    error: null,
  })),
  on(actions.loginError, (state, action) => ({
    ...state,
    error: action.errorMsg,
  })),
  on(actions.logoutSuccess, () => ({
    ...initialState,
  })),
);

export function reducer(state: State | undefined, action: Action) {
  return loginReducer(state, action);
}
