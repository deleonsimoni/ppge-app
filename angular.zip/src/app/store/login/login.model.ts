export interface UserInfo {
  given_name: string;
}
