import { createAction, props } from '@ngrx/store';

export const login = createAction('[Login] Login');

export const loginSuccess = createAction(
  '[Login] Login Success',
  props<{ username: string }>(),
);

export const loginError = createAction(
  '[Login] Login Error',
  props<{ errorMsg: string }>(),
);

export const logout = createAction('[Login] Logout');

export const logoutSuccess = createAction('[Login] Logout Success');

export const loginAuthorized = createAction('[Login] Login Authorized');
