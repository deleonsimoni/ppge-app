import { select, createFeatureSelector } from '@ngrx/store';
import { State } from './login.reducer';

const getState = createFeatureSelector<State>('login');

export const selectLogin = select(getState);
