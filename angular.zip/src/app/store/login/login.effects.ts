import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { catchError, map, mergeMap, switchMap } from 'rxjs/operators';
import { Action } from '@ngrx/store';
import { Actions, createEffect, ofType, OnInitEffects } from '@ngrx/effects';
import * as actions from './login.actions';
import { LoginService } from './login.service';
import { environment } from '@env/environment';

@Injectable()
export class LoginEffects implements OnInitEffects {
  login$ = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.login),
      switchMap(() =>
        this.loginService.login().pipe(
          mergeMap(() => this.loginService.getUsername()),
          map((user) =>
            actions.loginSuccess({
              username: user.given_name.toLocaleLowerCase(),
            }),
          ),
          catchError((error) => of(actions.loginError({ errorMsg: error }))),
        ),
      ),
    ),
  );

  loginSuccess$ = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.loginSuccess),
      switchMap(() =>
        this.loginService
          .isAuthorized()
          .pipe(
            map((authorized) =>
              authorized ? actions.loginAuthorized() : actions.logout(),
            ),
          ),
      ),
    ),
  );

  logout$ = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.logout),
      switchMap(() =>
        this.loginService.logout().pipe(
          map(() => actions.logoutSuccess()),
          catchError(() => of(actions.logoutSuccess())),
        ),
      ),
    ),
  );

  ngrxOnInitEffects(): Action {
    return environment.ambiente.toUpperCase() !== 'LOCAL'
      ? actions.login()
      : actions.loginSuccess({ username: 'Usuário' });
  }

  constructor(private actions$: Actions, private loginService: LoginService) {}
}
