import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ConsultaSaldo } from '@typings/saldo';
import { environment } from '@env/environment';
import { DatePipe } from '@angular/common';

@Injectable({
  providedIn: 'root',
})
export class SaldoService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;
  private readonly URL_SALDO = `${this.URL_PIX_GESTAO}/controle-saldos/total`;

  constructor(private http: HttpClient, public datepipe: DatePipe) {}

  getSaldo(): Observable<ConsultaSaldo> {
    return this.http.get<ConsultaSaldo>(this.URL_SALDO, {
      params: { data: this.datepipe.transform(new Date(), 'dd/MM/yyyy')},
    });
  }
}
