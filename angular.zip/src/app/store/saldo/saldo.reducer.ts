import { createReducer, on, Action } from '@ngrx/store';
import * as actions from './saldo.actions';
import { ConsultaSaldo } from '@typings/saldo';

// tslint:disable:no-empty-interface
export interface State extends ConsultaSaldo  {}

export const initialState: State = null;

const saldoReducer = createReducer(
  initialState,
  on(actions.saldoSuccess, (state, action) => ({
    ...action.saldo,
  })),
);

export function reducer(state: State | undefined, action: Action) {
  return saldoReducer(state, action);
}
