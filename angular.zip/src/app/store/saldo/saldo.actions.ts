import { createAction, props } from '@ngrx/store';
import { ConsultaSaldo } from '@typings/saldo';

export const saldoInit = createAction('[Saldo] Saldo Init');
export const saldoInterval = createAction('[Saldo] Saldo Interval');
export const saldo = createAction('[Saldo] Saldo');
export const saldoSuccess = createAction(
  '[Saldo] Saldo Success',
  props<{ saldo: ConsultaSaldo }>(),
);
