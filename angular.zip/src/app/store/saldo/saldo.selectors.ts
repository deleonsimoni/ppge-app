import { select, createFeatureSelector } from '@ngrx/store';
import { State } from './saldo.reducer';

const getState = createFeatureSelector<State>('saldo');

export const selectSaldo = select(getState);
