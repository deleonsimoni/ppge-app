import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { EffectsModule } from '@ngrx/effects';
import { StoreModule } from '@ngrx/store';
import { SaldoEffects } from './saldo.effects';
import { reducer } from './saldo.reducer';

@NgModule({
  imports: [
    CommonModule,
    StoreModule.forFeature('saldo', reducer),
    EffectsModule.forFeature([SaldoEffects]),
  ],
})
export class SaldoModule {}
