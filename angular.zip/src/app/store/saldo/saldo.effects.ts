import { Injectable } from '@angular/core';
import { interval } from 'rxjs';
import { map, switchMap, delay } from 'rxjs/operators';
import { Action } from '@ngrx/store';
import { Actions, createEffect, ofType, OnInitEffects } from '@ngrx/effects';
import * as actions from './saldo.actions';
import { SaldoService } from './saldo.service';

@Injectable()
export class SaldoEffects implements OnInitEffects {
  saldoInterval$ = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.saldoInterval),
      switchMap(() => interval(60000).pipe(map(() => actions.saldo()))),
    ),
  );

  saldo$ = createEffect(() =>
    this.actions$.pipe(
      delay(2000),
      ofType(actions.saldo),
      switchMap(() =>
        this.saldoService
          .getSaldo()
          .pipe(map((saldo) => actions.saldoSuccess({ saldo }))),
      ),
    ),
  );

  saldoInit$ = createEffect(() =>
    this.actions$.pipe(
      ofType(actions.saldoInit),
      switchMap(() => [actions.saldo(), actions.saldoInterval()]),
    ),
  );

  ngrxOnInitEffects(): Action {
    return actions.saldoInit();
  }

  constructor(private actions$: Actions, private saldoService: SaldoService) {}
}
