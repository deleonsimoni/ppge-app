import { ChangeDetectionStrategy, Component } from '@angular/core';
import { Store } from '@ngrx/store';
import { selectSaldo } from '@store/saldo';
import { environment } from '@env/environment';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FooterComponent {
  saldo$ = this.store.pipe(selectSaldo);


  date:Date = new Date(); 
  constructor(private store: Store<{}>) {}


  getDate(){
    return new Date();
  }
  
  getInicialAmbiente(): string {
    console.log(environment.ambiente);
    if (environment.ambiente.toUpperCase() == 'DES') {
      return 'D';
    } else if((environment.ambiente.toUpperCase() == 'HMP')){
      return 'H';
    } else {
      return 'P';
    }
  }
}
