import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialogModule } from '@angular/material/dialog';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { NgxCurrencyModule } from 'ngx-currency';
import { NgxMaskModule } from 'ngx-mask';
import { SaldoRoutingModule } from './saldo-routing.module';
import { SaldoComponent } from './saldo.component';
import { CadastroAporteSaqueComponent } from './cadastro-aporte-saque/cadastro-aporte-saque.component';
import {MatButtonModule} from '@angular/material/button';
import {MatTableModule} from '@angular/material/table';
import { DetalheSubcontaComponent } from './detalhe-subconta/detalhe-subconta.component';
import { ConfirmaChamadaComponent } from './confirma-chamada/confirma-chamada.component';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

@NgModule({
  declarations: [SaldoComponent, CadastroAporteSaqueComponent, DetalheSubcontaComponent, ConfirmaChamadaComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatCardModule,
    MatDatepickerModule,
    MatDialogModule,
    MatSlideToggleModule,
    MatGridListModule,
    MatInputModule,
    MatListModule,
    MatRadioModule,
    MatSelectModule,
    MatSnackBarModule,
    MatTooltipModule,
    NgxCurrencyModule,
    NgxMaskModule.forRoot(),
    SaldoRoutingModule,
    MatButtonModule,
    MatTableModule,
    MatPaginatorModule
  ],
})
export class SaldoModule {}
