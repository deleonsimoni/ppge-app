import { Component, ChangeDetectionStrategy } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { SaldoService } from './saldo.service';
import { BehaviorSubject } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { ConsultaSaldo, AporteSaqueRecurso } from '@typings/index';
import { CadastroAporteSaqueComponent } from './cadastro-aporte-saque/cadastro-aporte-saque.component';
import { SnackbarService } from '@core/services';
import DataUtils from '@app/shared/data-utils';
import { take } from 'rxjs/operators';
import {
  animate,
  state,
  style,
  transition,
  trigger,
} from '@angular/animations';
import { DetalheSubcontaComponent } from './detalhe-subconta/detalhe-subconta.component';
import { LoginService } from '@store/login';
import { ConfirmaChamadaComponent } from './confirma-chamada/confirma-chamada.component';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';

@Component({
  selector: 'app-saldo',
  templateUrl: './saldo.component.html',
  styleUrls: ['./saldo.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition(
        'expanded <=> collapsed',
        animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)'),
      ),
    ]),
  ],
})
export class SaldoComponent {
  readonly saldo$ = new BehaviorSubject<ConsultaSaldo>(null);
  readonly form = this.fb.group({
    data: [moment(new Date()).format('YYYY-MM-DD')],
    buscaContabil: [true],
  });
  /*readonly displayedColumns = ['descricao', 'entrada', 'saida', 'bloqueado'];
  readonly headerTransferencia = ['descricao', 'entrada', 'saida', 'bloqueado'];*/

  readonly displayedColumns = ['descricao', 'entrada', 'saida'];
  readonly headerTransferencia = ['descricao', 'entrada', 'saida'];

  readonly headerAporteSaque = ['descricao', 'entrada', 'saida'];
  readonly displayedTotalColumns = ['total'];
  readonly date = new Date();
  expandedElementAporteSaque: boolean;
  expandedElementTransferencia: boolean;

  filterNaoUteis = (d: Date | null): boolean => {
    let data;
    if(d) {
      data = moment(d).toDate();
    }
    const day = (data || new Date()).getDay();
    return day !== 0 && day !== 6 && !DataUtils.feriados.includes(moment(d).format('YYYY-MM-DD'));
  };

  constructor(
    private fb: FormBuilder,
    private saldoService: SaldoService,
    public dialog: MatDialog,
    private snackbarService: SnackbarService,
    public loginService: LoginService,
    public datepipe: DatePipe
  ) {
    this.atualizarSaldo();
  }

  mostraDadosAporteSaque = false;
  mostraDadosTransferencia = false;

  apresentaDados(dados) {
    if (dados.descricao === 'Aporte/Saque' && this.mostraDadosAporteSaque) {
      this.mostraDadosAporteSaque = false;
      this.expandedElementAporteSaque = false;
    } else if (
      dados.descricao === 'Aporte/Saque' &&
      !this.mostraDadosAporteSaque
    ) {
      this.mostraDadosAporteSaque = true;
      this.expandedElementAporteSaque = true;
    }

    if (dados.descricao === 'Transferências' && this.mostraDadosTransferencia) {
      this.mostraDadosTransferencia = false;
      this.expandedElementTransferencia = false;
    } else if (
      dados.descricao === 'Transferências' &&
      !this.mostraDadosTransferencia
    ) {
      this.mostraDadosTransferencia = true;
      this.expandedElementTransferencia = true;
    }
  }

  apresentaDadosDetalhados(dados) {
    if (
      dados.descricao === 'Aporte/Saque' &&
      this.expandedElementAporteSaque &&
      this.mostraDadosAporteSaque
    ) {
      return this.mostraDadosAporteSaque;
    } else if (
      dados.descricao === 'Aporte/Saque' &&
      this.expandedElementAporteSaque &&
      !this.mostraDadosAporteSaque
    ) {
      return this.mostraDadosAporteSaque;
    }
    if (
      dados.descricao === 'Transferências' &&
      this.expandedElementTransferencia &&
      this.mostraDadosTransferencia
    ) {
      return this.mostraDadosTransferencia;
    } else if (
      dados.descricao === 'Transferências' &&
      this.expandedElementTransferencia &&
      !this.mostraDadosTransferencia
    ) {
      return this.mostraDadosTransferencia;
    }
  }

  atualizarSaldo(data?: string, buscaContabil?: string) {
    this.saldoService
      .consultaSaldo2(data, buscaContabil)
      .pipe(take(1))
      .subscribe((saldo) => this.saldo$.next(saldo));
  }

  atualizarSaldoHistorico() {
    if(this.form.valid) {
      let dataAtualiza = this.datepipe.transform(this.form.get('data').value, 'dd/MM/yyyy',  'UTC');
      const dialogRef = this.dialog.open(ConfirmaChamadaComponent, {
        width: '600px',
        data: {
          title: 'Atenção!',
          listtext: [
            `Ao prosseguir será solicitado o cálculo para atualização do saldo do dia ${dataAtualiza}.`,
            'Verifique se já não houve atualização recente!',
            'Tem certeza que deseja prosseguir?'
          ]
        }
      });

      dialogRef.afterClosed().pipe(take(1)).subscribe((result) => {
        if (result) {
          this.saldoService.atualizarSaldoHistorico(dataAtualiza)
            .pipe(take(1))
            .subscribe(() => {
              this.snackbarService.open('Procedure iniciada com sucesso', 'success');
            }, (err) => {
              console.log(err);
              this.snackbarService.open('Falha ao iniciar a procedure', 'error');
            });
        }
      });

    } else {
      this.snackbarService.open('Verifique se a "Data" está preenchida corretamente', 'error');

    }
  }

  recalcularSaldoHistorico() {
    if(this.form.valid) {
      if(!moment(this.form.get('data').value).isBefore(moment.now(), 'day')) {
        this.snackbarService.open('O recalculo do saldo histórico somente deve ser iniciado para datas anteriores ao dia de hoje', 'error');
        return;
      }
      let dataAtualiza = this.datepipe.transform(this.form.get('data').value, 'dd/MM/yyyy',  'UTC');
      const dialogRef = this.dialog.open(ConfirmaChamadaComponent, {
        width: '600px',
        data: {
          title: 'Atenção!',
          listtext: [
            `Ao prosseguir será solicitado um novo cálculo do saldo para o dia ${dataAtualiza}.`,
            'Verifique se já não houve atualização recente!',
            'Tem certeza que deseja prosseguir?'
          ]
        }
      });

      dialogRef.afterClosed().pipe(take(1)).subscribe((result) => {
        if (result) {
          this.saldoService.recalcularSaldoHistorico(dataAtualiza)
            .pipe(take(1))
            .subscribe(() => {
              this.snackbarService.open('Procedure iniciada com sucesso', 'success');
            }, (err) => {
              console.log(err);
              this.snackbarService.open('Falha ao iniciar a procedure', 'error');
            });

        }
      });

    } else {
      this.snackbarService.open('Verifique se a "Data" está preenchida corretamente', 'error');

    }

  }

  openDialog() {
    const dialogRef = this.dialog.open(CadastroAporteSaqueComponent, {
      width: '600px',
    });
    dialogRef.afterClosed().pipe(take(1)).subscribe((result) => {
      if (result) {
        this.enviarAporte(result);
      }
    });
  }

  openDialogSubconta(
    descricao: string,
    data: Date,
    tipoLancamento: string,
    tipoMovimentacao?: string,
  ) {
    this.saldoService
      .getLancamentos(data, tipoLancamento, tipoMovimentacao)
      .pipe(take(1))
      .subscribe((lancamentos) => {
        this.dialog.open(DetalheSubcontaComponent, {
          width: '1400px',
          data: { lancamentos, descricao },
        });
      });
  }

  openDialogSubcontaBloqueados(
    descricao: string,
    data: Date,
    tipoLancamento: string,
    tipoMovimentacao?: string,
  ) {
    this.saldoService
      .getLancamentos(data, tipoLancamento, tipoMovimentacao)
      .pipe(take(1))
      .subscribe((lancamentos) => {
        this.dialog.open(DetalheSubcontaComponent, {
          width: '1400px',
          data: { lancamentos, descricao, tipoLancamento },
        });
      });
  }

  onSubmit() {
    debugger;
    this.mostraDadosAporteSaque = false;
    this.mostraDadosTransferencia = false;
    this.atualizarSaldo(this.form.get('data').value, this.form.get('buscaContabil').value);
  }

  enviarAporte(aporteSaque: AporteSaqueRecurso): void {
    aporteSaque.dataOperacaoBacen = DataUtils.stringToDate(
      aporteSaque.dataOperacaoBacen,
    ).toJSON();
    this.saldoService.aportar(aporteSaque)
    .pipe(take(1))
    .subscribe(
      (response) => {
        if (response) {
          this.snackbarService.open('Salvo com sucesso', 'success');
          this.atualizarSaldo();
        }
      },
      (error) => {
        this.snackbarService.open('Erro ao salvar: ' + error, 'error');
      },
    );
  }

  processarReenvioPendentes(data: Date){
    this.saldoService.reenviarPendentes(data)
    .pipe(take(1))
    .subscribe(
      (response) => {
        if (response) {
          this.snackbarService.open('Reenvio em processamento!', 'success');
        }
      },
      (error) => {
        this.snackbarService.open('Erro ao realizar reenvio: ' + error, 'error');
      },
    );
  }
}
