import { Component, OnInit, ViewChild, ChangeDetectionStrategy, Input, AfterViewInit, OnChanges, Inject } from '@angular/core';
import { FormBuilder, Validators, NgForm } from '@angular/forms';
import { AporteSaqueRecurso, TipoMensagem } from '@typings/index';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-cadastro-aporte-saque',
  templateUrl: './cadastro-aporte-saque.component.html',
  styleUrls: ['./cadastro-aporte-saque.component.scss']
})
export class CadastroAporteSaqueComponent implements OnInit {

  @ViewChild('formDirective') private formDirective: NgForm;
  private aporteSaqueRecurso: AporteSaqueRecurso;

  readonly form = this.fb.group({
    tipoOperacao: ['', Validators.required],
    tipoMensagem: ['', Validators.required],
    dataOperacaoBacen: ['', Validators.required],
    numControleStr: ['', [Validators.maxLength(20), Validators.required] ],
    valorOperacao: ['', Validators.required],
  });
  readonly tipoMensagens$ = this.form.get('tipoOperacao').valueChanges;

  ngOnInit(){
  }
 
  constructor(private fb: FormBuilder,
              public dialogRef: MatDialogRef<CadastroAporteSaqueComponent>,
              @Inject(MAT_DIALOG_DATA) public data) { }

}
