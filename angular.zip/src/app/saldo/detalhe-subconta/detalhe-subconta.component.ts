import { Component, OnInit, Inject, ChangeDetectionStrategy, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConsultaLancamento } from '@typings/saldo/saldo.model';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { SaldoService } from '../saldo.service';
import { take } from 'rxjs/operators';
import { SnackbarService } from '@core/services';

@Component({
  selector: 'app-detalhe-subconta',
  templateUrl: './detalhe-subconta.component.html',
  styleUrls: ['./detalhe-subconta.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DetalheSubcontaComponent  {

  displayedColumnsAporte: string[] = ['mensagem','numeroStr', 'dataLancamento', 'tipo', 'valor'];
  displayedColumnnTransferencia: string[] = ['mensagem','numeroStr', 'tipo', 'valor', 'acao'];
  dataSource = new MatTableDataSource<ConsultaLancamento>(this.data.lancamentos);
  constructor( public dialogRef: MatDialogRef<ConsultaLancamento>,
    @Inject(MAT_DIALOG_DATA) public data: { lancamentos: ConsultaLancamento[], descricao: string, tipoLancamento: string}, private saldoService: SaldoService, private snackbarService: SnackbarService) { }

    @ViewChild(MatPaginator) paginator: MatPaginator;

  ngAfterViewInit() {
    console.log(this.data.tipoLancamento);
    this.dataSource.paginator = this.paginator;
  }
  getDate(timeStamp: number){
    return new Date(timeStamp);
  }

  processarReenvioPendentesIndividual(codInstrucaoOriginal: string){
    this.saldoService.reenviarPendentesIndividual(codInstrucaoOriginal)
    .pipe(take(1))
    .subscribe(
      (response) => {
        if (response) {
          this.snackbarService.open('Reenvio processado com sucesso!', 'success');
        }
      },
      (error) => {
        this.snackbarService.open('Erro ao realizar reenvio: ' + error, 'error');
      },
    );
  }

}
