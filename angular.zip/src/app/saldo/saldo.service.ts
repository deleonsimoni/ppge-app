import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import {
  AporteSaqueRecurso,
  ConsultaSaldo,
  TipoMensagem,
} from '@typings/saldo';
import { environment } from '@env/environment';
import { DatePipe } from '@angular/common';
import {
  ConsultaLancamento,
  DetalheAporteSaque,
} from '@typings/saldo/saldo.model';

@Injectable({
  providedIn: 'root',
})
export class SaldoService {
  private readonly URL_PIX_GESTAO = `${environment.urlPixGestao}/simpi-pix-gestao`;

  private readonly URL_APORTAR = `${this.URL_PIX_GESTAO}/aporte-recursos`;
  private readonly URL_SALDO = `${this.URL_PIX_GESTAO}/controle-saldos`;
  private readonly URL_LANCAMENTOS = `${this.URL_PIX_GESTAO}/controle-saldos/lancamentos`;
  private readonly URL_TIPO_MENSAGENS = `${this.URL_PIX_GESTAO}/tipo-mensagens`;
  private readonly URL_REENVIO_MENSAGEM_CONTABIL = `${this.URL_PIX_GESTAO}/saldos-retroativos`;
  private readonly URL_BATCH_CONTABIL = `${this.URL_PIX_GESTAO}/contabil`;

  constructor(private http: HttpClient, public datepipe: DatePipe) {}

  atualizarSaldoHistorico(data: string) {
    let params = new HttpParams().set('data', data);
    return this.http.get(`${this.URL_BATCH_CONTABIL}/processar-saldo`, {params});
  }

  recalcularSaldoHistorico(data: string) {
    let params = new HttpParams().set('data', data);
    return this.http.get(`${this.URL_BATCH_CONTABIL}/processar-saldo-retroativo`, {params});
  }

  aportar(aporte: AporteSaqueRecurso): Observable<boolean> {
    return this.http
      .post(this.URL_APORTAR, aporte, { observe: 'response' })
      .pipe(
        map((response) => response.status === 201),
        catchError((err) => {
          throw err.error.errorMessage;
        }),
      );
  }

  reenviarPendentes(data: Date): Observable<boolean> {
    return this.http
      .post(this.URL_REENVIO_MENSAGEM_CONTABIL, {"dataMensagem": this.datepipe.transform(data, 'dd/MM/yyyy', 'UTC')}, { observe: 'response' })
      .pipe(
        map((response) => response.status === 202),
        catchError((err) => {
          throw err.error.errorMessage;
        }),
      );
  }

  reenviarPendentesIndividual(codInstrucaoOriginal: string): Observable<boolean> {
    return this.http
      .post(`${this.URL_REENVIO_MENSAGEM_CONTABIL}/${codInstrucaoOriginal}`, null , { observe: 'response' })
      .pipe(
        map((response) => response.status === 201),
        catchError((err) => {
          throw err.error.errorMessage;
        }),
      );
  }

  consultaSaldo2(dataSaldo?: string, buscaContabil: string = 'true'): Observable<ConsultaSaldo> {
    if (!dataSaldo) {
      dataSaldo = this.datepipe.transform(new Date(), 'dd/MM/yyyy',);
    } else {
      dataSaldo = this.datepipe.transform(dataSaldo, 'dd/MM/yyyy',  'UTC');
    }
    let params = new HttpParams();
    params = params.set('data', dataSaldo);
    params = params.set('busca-contabil', buscaContabil);

    return this.http.get<ConsultaSaldo>(this.URL_SALDO, { params});
  }

  getLancamentos(
    data: Date,
    tipoLancamento: string,
    tipoMovimentacao?: string,
  ) {
    let params = new HttpParams()
      .set('data', this.datepipe.transform(new Date(data), 'dd/MM/yyyy', 'UTC'))
      .set('tipo-lancamento', tipoLancamento);
    if (tipoMovimentacao) {
      params = params.set('tipo-movimentacao', tipoMovimentacao);
    }
    return this.http.get<ConsultaLancamento>(this.URL_LANCAMENTOS, { params });
  }

  getTipoMensagens(): Observable<TipoMensagem[]> {
    return this.http.get<TipoMensagem[]>(this.URL_TIPO_MENSAGENS);
  }

  getDetalheAporteSaque(id: string): Observable<DetalheAporteSaque> {
    return this.http.get<DetalheAporteSaque>(`${this.URL_APORTAR}/${id}`);
  }
}
