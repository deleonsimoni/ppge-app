export const environment = {
  production: false,
  ambiente: '__AMBIENTE__',
  sso: {
    clientId: 'cli-web-mpi',
    realm: 'intranet',
    redirectUri: '__URL__',
    url: '__SSO_URL__',
  },
  url: '',
  urlPixGestao: '__HTTP_PIX_GESTAO__',
  urlSIMPIMensageria: '__HTTP_SIMPI_MENSAGERIA__',
  urlSIMPIResolvePendencia: '__HTTP_SIMPI_RESOLVE_PENDENCIA__',
  urlPixRelatorio: '__HTTP_PIX_RELATORIO__',
  urlPixCargaBacen: '__HTTP_PIX_CARGA_BACEN__'

};





