const PROXY_CONFIG = [
  {
    context: ['/simpi-mensageria-api'],
    target: 'http://10.116.238.62:8080',
    secure: false,
    logLevel: 'debug',
  },
];

module.exports = PROXY_CONFIG;
